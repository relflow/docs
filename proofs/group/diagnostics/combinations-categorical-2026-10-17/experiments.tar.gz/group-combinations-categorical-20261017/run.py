"""Frozen categorical combination matrix; original P080 tests are never read.

Train every predeclared arm on development splits first. The separate holdout
phase requires all twelve completed fits and then scores a fresh random stream.
Canonical P080 source and production RelFlow source remain unchanged.
"""

# ruff: noqa: E402

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / "snapshot/src"), str(ROOT / "shared")]

import lightning.pytorch as lit
import numpy as np
import torch

import relflow as rf
from relflow.structs.enums import TensorKey, Tokens
from relflow.structs.packages import Parcel
from relflow.tensorfields.extensions import group

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
spec = importlib.util.spec_from_file_location("frozen_p080", ROOT / "proof_source.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def deterministic_forward(self, inputs):
    batch_size, *dims = inputs.state.shape
    state = inputs.state.reshape(-1)
    content = inputs.content.reshape(-1)
    valued = state.eq(Tokens.valued.value)
    if valued.any():
        selected = content.masked_select(valued)
        if ((selected < -1) | (selected >= self.capacity)).any().item():
            raise ValueError(f"Token in address {self.origin} outside [-1, {self.capacity})")
    indices = content.masked_fill(content.eq(-1), self.capacity).masked_fill(~valued, 0)
    logits = self.support(self.embeddings[TensorKey.group.name](indices))
    hard = torch.zeros_like(logits).scatter_(-1, logits.argmax(-1, keepdim=True), 1)
    if self.training:
        soft = logits.softmax(-1)
        assignments = hard - soft.detach() + soft
    else:
        assignments = hard
    assignments = assignments * valued.unsqueeze(-1)
    embeddings = (
        self.embeddings[TensorKey.state.name](state) + self.embeddings[TensorKey.content.name](assignments)
    ).reshape(batch_size, *dims, -1)
    return Parcel(
        payload=embeddings,
        present=torch.ones(batch_size, dtype=torch.bool, device=embeddings.device),
        origin=self.origin,
        destination=self.destination,
        batch_size=batch_size,
    )


def install(case: str) -> None:
    config = PROTOCOL["cases"][case]
    if config["routing"] == "deterministic_ST":
        group.Embedder.forward = deterministic_forward
    if config["assignment_initialization_scale"] == 1.0:
        return
    original_init, original_resize = group.Embedder.__init__, group.Embedder.resize

    def init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        with torch.no_grad():
            self.embeddings["group"].weight.mul_(0.1)

    def resize(self, size, plan):
        previous = self.embeddings["group"].weight
        original_resize(self, size, plan)
        with torch.no_grad():
            for old, new in plan.parameters:
                if old is previous:
                    # Existing rows and the moved sentinel are copied by Resize.
                    # The old sentinel position is the first newly allocated ID.
                    new[old.shape[0] - 1 : -1].mul_(0.1)

    group.Embedder.__init__ = init
    group.Embedder.resize = resize


def intervene(model, train, validate, optimizers, *, margin1: bool):
    started = time.perf_counter()
    embedder = model.nodes["/merchant_id"].embedder
    vocabulary = list(rf.Group.vocabulary(model, "/merchant_id"))
    weight = embedder.embeddings["group"].weight
    original = weight.detach().clone()
    indices = np.asarray([int(token.rsplit("-", 1)[1]) for token in vocabulary])
    current = embedder.support(original[: len(vocabulary)]).argmax(-1).cpu().numpy()
    row_mass = original[: len(vocabulary)].logsumexp(-1, keepdim=True)
    available = (~embedder.retired).nonzero(as_tuple=True)[0].tolist()
    before = float(proof.losses(model, validate)[0].mean())

    def replace(groups, *, soft_proposal=False):
        template = torch.full_like(original[: len(vocabulary)], -1.0 if soft_proposal else math.log(1e-8))
        template[
            torch.arange(len(vocabulary), device=weight.device),
            torch.as_tensor(groups, device=weight.device),
        ] = 0
        if soft_proposal:
            template = template.log_softmax(-1)
        with torch.no_grad():
            weight[: len(vocabulary)].copy_(row_mass + template)

    errors = np.full((proof.ENTITY_COUNT, embedder.size), np.inf)
    entities = np.asarray([int(row["merchant_id"].rsplit("-", 1)[1]) for row in train])
    tick = time.perf_counter()
    try:
        for group_id in available:
            # Counterfactual scoring is hard in every arm, including margin1.
            replace(np.full(len(vocabulary), group_id))
            nll, _ = proof.losses(model, train)
            errors[:, group_id] = np.bincount(entities, weights=nll, minlength=proof.ENTITY_COUNT)
    finally:
        with torch.no_grad():
            weight.copy_(original)
    scoring_seconds = time.perf_counter() - tick
    proposed = errors.argmin(-1)[indices]
    replace(proposed, soft_proposal=margin1)
    after = float(proof.losses(model, validate)[0].mean())
    accepted = after < before
    mass_drift = float((weight[: len(vocabulary)].logsumexp(-1, keepdim=True) - row_mass).abs().max())
    if accepted:
        proof.reset_rows(weight, len(vocabulary), optimizers)
    else:
        with torch.no_grad():
            weight.copy_(original)
    return {
        "accepted": accepted,
        "before_validation_nll": before,
        "proposed_validation_nll": after,
        "changed_ids": int(np.sum(proposed != current)),
        "proposal_margin": 1.0 if margin1 else -math.log(1e-8),
        "proposal_row_logmass_drift": mass_drift,
        "candidate_groups": available,
        "train_rows_scored": len(train) * len(available),
        "validation_rows_scored": 2 * len(validate),
        "scoring_seconds": scoring_seconds,
        "event_seconds": time.perf_counter() - started,
    }


class Reassignment(lit.Callback):
    def __init__(self, train, validate, *, margin1):
        self.train = train
        self.validate = validate
        self.margin1 = margin1
        self.events = []

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        step = trainer.global_step
        if step in (200, 400) and not any(event["step"] == step for event in self.events):
            event = intervene(pl_module, self.train, self.validate, trainer.optimizers, margin1=self.margin1)
            self.events.append({"step": step, **event})


def score_gates(metrics):
    return {
        "ARI_at_least_0.8": metrics["adjusted_rand"] >= 0.8,
        "accuracy_at_least_0.9": metrics["accuracy"] >= 0.9,
        "exactly_five_occupied": metrics["occupied_groups"] == 5,
        "all_fifty_IDs": metrics["assigned_ids"] == 50,
        "all_five_target_classes": metrics["known_target_classes"] == 5,
        "finite": bool(np.isfinite([metrics["accuracy"], metrics["nll"], metrics["adjusted_rand"]]).all()),
    }


def train(case, seed):
    install(case)
    lit.seed_everything(seed, workers=True)
    model = proof.build()
    options = {"partition_seed": seed * 100}
    training = list(proof.records(rows=5000, seed=seed * 100 + 1, **options))
    validation = list(proof.records(rows=2000, seed=seed * 100 + 2, **options))
    data = rf.SyntheticDataModule(
        model=model, train=lambda: iter(training), validate=lambda: iter(validation), seed=seed
    )
    callback = Reassignment(training, validation, margin1=case == "deterministic_small_margin1")
    trainer = lit.Trainer(
        accelerator="cpu",
        devices=1,
        max_steps=600,
        max_epochs=-1,
        logger=False,
        enable_checkpointing=False,
        enable_progress_bar=False,
        enable_model_summary=False,
        deterministic=True,
        num_sanity_val_steps=0,
        callbacks=[callback],
    )
    started = time.perf_counter()
    trainer.fit(model, datamodule=data)
    model.eval()
    event = intervene(model, training, validation, trainer.optimizers, margin1=callback.margin1)
    callback.events.append({"step": 600, **event})
    majority = max(
        (f"class-{label}" for label in range(5)),
        key=lambda label: sum(row["outcome"] == label for row in training),
    )
    measured = proof.measure(model, validation, proof.partition(seed * 100), majority)
    checkpoint = ROOT / f"{case}-{seed}.ckpt"
    model.save(checkpoint)
    result = {
        "case": case,
        "seed": seed,
        "optimizer_updates": trainer.global_step,
        "events": callback.events,
        "validation": measured,
        "validation_gates": score_gates(measured),
        "majority_label": majority,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": digest(checkpoint),
        "wall_seconds": time.perf_counter() - started,
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "scope": "Development train/validation only; no original test or fresh holdout generated during training.",
        "protocol_sha256": digest(ROOT / "protocol.json"),
        "harness_sha256": digest(Path(__file__)),
        "proof_source_sha256": digest(ROOT / "proof_source.py"),
        "group_source_sha256": digest(ROOT / "snapshot/src/relflow/tensorfields/extensions/group.py"),
    }
    path = ROOT / f"{case}-{seed}.json"
    path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        "RESULT",
        json.dumps({"case": case, "seed": seed, "validation": measured, "gates": result["validation_gates"]}),
        flush=True,
    )


def holdout():
    # Enforce a sealed phase boundary: every arm/seed must finish before any
    # fresh outcome is inspected. All methods were fixed in protocol.json.
    runs = []
    for case in PROTOCOL["cases"]:
        for seed in PROTOCOL["seeds"]:
            result = json.loads((ROOT / f"{case}-{seed}.json").read_text())
            if result["optimizer_updates"] != 600:
                raise ValueError("All twelve original-budget fits must finish before fresh holdout scoring")
            if result["protocol_sha256"] != digest(ROOT / "protocol.json") or result["harness_sha256"] != digest(
                Path(__file__)
            ):
                raise ValueError("The frozen protocol/harness changed since training")
            runs.append(result)
    for result in runs:
        checkpoint = Path(result["checkpoint"])
        if digest(checkpoint) != result["checkpoint_sha256"]:
            raise ValueError("A trained checkpoint changed after development")
        model = rf.Model.load(checkpoint)
        model.eval()
        seed = result["seed"]
        before = rf.Group.assignments(model, "/merchant_id")
        vocabulary = rf.Group.vocabulary(model, "/merchant_id")
        counts = model.nodes["/merchant_id"].embedder.counters["content"].counts.clone()
        rows = list(proof.records(rows=2500, seed=seed * 100 + 503, partition_seed=seed * 100))
        shuffled = list(proof.records(rows=2500, seed=seed * 100 + 503, partition_seed=seed * 100, no_regime=True))
        measured = proof.measure(model, rows, proof.partition(seed * 100), result["majority_label"])
        corrupted = proof.measure(model, shuffled, proof.partition(seed * 100), result["majority_label"])
        gates = score_gates(measured)
        gates.update(
            {
                "shuffled_accuracy_at_most_0.3": corrupted["accuracy"] <= 0.3,
                "shuffled_accuracy_drop_at_least_0.5": measured["accuracy"] - corrupted["accuracy"] >= 0.5,
                "evaluation_frozen": before == rf.Group.assignments(model, "/merchant_id")
                and vocabulary == rf.Group.vocabulary(model, "/merchant_id")
                and torch.equal(counts, model.nodes["/merchant_id"].embedder.counters["content"].counts),
            }
        )
        result.update(fresh_holdout=measured, fresh_shuffled=corrupted, fresh_gates=gates)
        print(
            "HOLDOUT",
            result["case"],
            seed,
            measured["accuracy"],
            measured["adjusted_rand"],
            measured["occupied_groups"],
            flush=True,
        )
    (ROOT / "matrix-results.json").write_text(
        json.dumps({"protocol": PROTOCOL, "runs": runs}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("train", "holdout"))
    parser.add_argument("--case", choices=tuple(PROTOCOL["cases"]))
    parser.add_argument("--seed", type=int, choices=PROTOCOL["seeds"])
    arguments = parser.parse_args()
    if arguments.phase == "train":
        if arguments.case is None or arguments.seed is None:
            parser.error("Training requires --case and --seed")
        train(arguments.case, arguments.seed)
    else:
        holdout()
