"""Run every fixed development variant for one seed in separate processes."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, required=True)
options = parser.parse_args()
for case in json.loads((root / "protocol.json").read_text())["cases"]:
    with (root / f"{case}-{options.seed}.log").open("w") as log:
        subprocess.run(
            [sys.executable, str(root / "run.py"), "train", "--case", case, "--seed", str(options.seed)],
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
        )
    print(case, options.seed, "development complete", flush=True)
