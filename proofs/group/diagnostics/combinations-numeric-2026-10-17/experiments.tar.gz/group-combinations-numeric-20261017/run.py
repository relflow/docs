"""Frozen validation-only combinations; a separate command audits every frozen checkpoint.

No production file is edited. Original P079 test rows are never generated here.
"""

# ruff: noqa: E402

import __future__

import argparse
import ast
import contextlib
import hashlib
import importlib.util
import inspect
import json
import os
import platform
import sys
import textwrap
import time
import traceback
from functools import partial
from pathlib import Path
from unittest.mock import patch

for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[name] = "1"
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK / "proofs"))
sys.path.insert(0, str(WORK / "snapshot/src"))

import lightning.pytorch as lit
import numpy as np
import torch

from relflow.tensorfields.extensions import group

spec = importlib.util.spec_from_file_location("frozen_p079", WORK / "p079.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
SEEDS = (7901, 7902, 7903)
CASES = ("crossing_four", "imbalanced_four", "separated_six", "separated_four")
ARMS = {
    "predictive": {"deterministic": False, "scale": 1.0, "proposal_margin": None},
    "predictive_st": {"deterministic": True, "scale": 1.0, "proposal_margin": None},
    "predictive_st_small": {"deterministic": True, "scale": 0.1, "proposal_margin": None},
    "predictive_st_small_margin1": {"deterministic": True, "scale": 0.1, "proposal_margin": 1.0},
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprint():
    model = hashlib.sha256()
    package = WORK / "snapshot/src/relflow"
    for path in sorted(package.rglob("*.py")):
        model.update(("src/relflow/" + path.relative_to(package).as_posix()).encode())
        model.update(path.read_bytes())
    return {
        "harness_sha256": digest(__file__),
        "p079_sha256": digest(WORK / "p079.py"),
        "protocol_sha256": digest(WORK / "protocol.json"),
        "source_tree_sha256": model.hexdigest(),
        "group_sha256": digest(group.__file__),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "platform": platform.platform(),
        "torch_threads": torch.get_num_threads(),
        "torch_interop_threads": torch.get_num_interop_threads(),
    }


def deterministic_st(logits, tau=1.0, hard=False, eps=1e-10, dim=-1):
    soft = torch.softmax(logits / tau, dim=dim)
    if not hard:
        return soft
    selected = torch.zeros_like(soft).scatter_(dim, soft.argmax(dim=dim, keepdim=True), 1.0)
    return selected - soft.detach() + soft


def compile_function(function, source, additions):
    tree = ast.parse(textwrap.dedent(source))
    tree.body[0].decorator_list = []
    namespace = dict(vars(group))
    namespace.update(function.__globals__)
    namespace.update(additions)
    exec(
        compile(
            ast.fix_missing_locations(tree),
            "<frozen-numeric-combination>",
            "exec",
            flags=__future__.annotations.compiler_flag,
        ),
        namespace,
    )
    return namespace[function.__name__]


forward_source = inspect.getsource(group.Embedder.forward)
needle = "torch.nn.functional.gumbel_softmax(assign_logits, hard=True, dim=-1)"
assert forward_source.count(needle) == 1
forward = compile_function(
    group.Embedder.forward,
    forward_source.replace(needle, "deterministic_st(assign_logits, hard=True, dim=-1)"),
    {"deterministic_st": deterministic_st},
)
proposal_source = inspect.getsource(proof.reassignment)
needle = "    with torch.no_grad():\n        weight[: len(vocabulary)].copy_(row_mass + forced)\n    after ="
assert proposal_source.count(needle) == 1
proposal_source = proposal_source.replace(needle, "    forced = torch.log_softmax(forced, dim=-1)\n" + needle)
# Only the final proposed logits become soft. Counterfactual predictions remain hard.
needle = "    forced = torch.full_like(saved[: len(vocabulary)], math.log(1e-8))\n    forced["
assert proposal_source.count(needle) == 1
proposal_source = proposal_source.replace(
    needle, "    forced = torch.full_like(saved[: len(vocabulary)], -1.0)\n    forced["
)
soft_proposal = compile_function(proof.reassignment, proposal_source, {})
original_init, original_resize = group.Embedder.__init__, group.Embedder.resize


@contextlib.contextmanager
def changes(arm):
    with contextlib.ExitStack() as stack:
        if arm["deterministic"]:
            stack.enter_context(patch.object(group.Embedder, "forward", forward))
        if arm["scale"] != 1.0:

            def init(self, *args, **kwargs):
                original_init(self, *args, **kwargs)
                with torch.no_grad():
                    self.embeddings["group"].weight.mul_(arm["scale"])

            def resize(self, size, plan):
                old = self.embeddings["group"].weight
                original_resize(self, size, plan)
                for previous, new in plan.parameters:
                    if previous is old:
                        with torch.no_grad():
                            new[old.shape[0] - 1 : -1].mul_(arm["scale"])

            stack.enter_context(patch.object(group.Embedder, "__init__", init))
            stack.enter_context(patch.object(group.Embedder, "resize", resize))
        if arm["proposal_margin"] is not None:
            stack.enter_context(patch.object(proof, "reassignment", soft_proposal))
        yield


def evaluate(model, rows, mean, seed, case):
    assignments = proof.rf.Group.assignments(model, "/entity")
    membership = np.asarray([assignments[f"entity-{i:04d}"]["group"] for i in range(proof.ENTITY_COUNT)])
    measured = proof.measure(proof.predict(model, rows), rows, mean)
    measured.update(
        adjusted_rand=proof.adjusted_rand(proof.partition(seed, case), membership),
        occupied_groups=len(np.unique(membership)),
        generating_groups=len(proof.CASES[case]["populations"]),
        assignments=membership.tolist(),
        status=proof.rf.Group.status(model, "/entity"),
    )
    return measured


def train(seed, arm_name, case):
    lit.seed_everything(seed, workers=True)
    train_rows, _ = proof.generate(seed, case, 1, proof.TRAIN_ROWS)
    validation, _ = proof.generate(seed, case, 2, proof.VALIDATION_ROWS)
    with changes(ARMS[arm_name]):
        model = proof.build()
        callback = proof.PredictiveGrouping(train_rows, validation)
        data = proof.rf.SyntheticDataModule(
            model=model,
            train=partial(proof.records, train_rows),
            validate=partial(proof.records, validation),
            seed=seed,
        )
        trainer = lit.Trainer(
            accelerator="cpu",
            devices=1,
            max_steps=600,
            max_epochs=-1,
            callbacks=[callback],
            logger=False,
            enable_checkpointing=False,
            enable_progress_bar=False,
            enable_model_summary=False,
            deterministic=True,
            num_sanity_val_steps=0,
        )
        started = time.perf_counter()
        trainer.fit(model, datamodule=data)
        model.eval()
        callback.events.append({"step": 600, **proof.reassignment(model, train_rows, validation, trainer.optimizers)})
        training_seconds = time.perf_counter() - started
        assert trainer.global_step == 600
        mean = float(np.mean([row["y"] for row in train_rows]))
        frozen = {name: value.detach().clone() for name, value in (*model.named_parameters(), *model.named_buffers())}
        measured = evaluate(model, validation, mean, seed, case)
        shuffled, _ = proof.generate(seed, case, 2, proof.VALIDATION_ROWS, shuffle=True)
        corrupted = proof.measure(proof.predict(model, shuffled), shuffled, mean)
        assert all(
            torch.equal(value, frozen[name]) for name, value in (*model.named_parameters(), *model.named_buffers())
        )
        checkpoint = WORK / "checkpoints" / f"{seed}-{case}-{arm_name}.ckpt"
        checkpoint.parent.mkdir(exist_ok=True)
        model.save(checkpoint)
    return {
        "optimizer_updates": trainer.global_step,
        "checkpoint": str(checkpoint.relative_to(WORK)),
        "checkpoint_sha256": digest(checkpoint),
        "training_and_intervention_wall_seconds": training_seconds,
        "events": callback.events,
        "validation": measured,
        "shuffled_validation": corrupted,
        "training_mean": mean,
        "evaluation_preserves_parameters_and_buffers": True,
    }


def validation_panel(seed, output):
    if output.exists():
        raise FileExistsError(output)
    report = {
        "phase": "validation only; no original test records generated",
        "seed": seed,
        "provenance": fingerprint(),
        "runs": [],
    }
    for case in CASES:
        for arm in ARMS:
            row = {"seed": seed, "case": case, "arm": arm, "configuration": ARMS[arm]}
            print("START", seed, case, arm, flush=True)
            try:
                row.update(outcome="completed", **train(seed, arm, case))
            except Exception:
                row.update(outcome="error", error=traceback.format_exc())
            report["runs"].append(row)
            output.write_text(json.dumps(report, indent=2) + "\n")
            print(
                "RESULT",
                json.dumps({key: row.get(key) for key in ("seed", "case", "arm", "outcome", "validation", "error")}),
                flush=True,
            )


def audit(output):
    if output.exists():
        raise FileExistsError(output)
    inputs = [WORK / f"validation-{seed}.json" for seed in SEEDS]
    validation = [json.loads(path.read_text()) for path in inputs]
    rows = [row for panel in validation for row in panel["runs"]]
    expected = {(seed, case, arm) for seed in SEEDS for case in CASES for arm in ARMS}
    assert {(row["seed"], row["case"], row["arm"]) for row in rows} == expected
    assert all(panel["provenance"] == validation[0]["provenance"] for panel in validation)
    assert fingerprint() == validation[0]["provenance"]
    result = {
        "phase": "fresh independently generated audit after all arms and validation files frozen",
        "original_test_stream_used": False,
        "audit_split": 10003,
        "audit_rows": 2048,
        "provenance": fingerprint(),
        "validation_sha256": {str(path.name): digest(path) for path in inputs},
        "runs": [],
    }
    for row in rows:
        measured = {key: row[key] for key in ("seed", "case", "arm", "outcome")}
        if row["outcome"] == "completed":
            path = WORK / row["checkpoint"]
            assert digest(path) == row["checkpoint_sha256"]
            model = proof.rf.Model.load(path)
            model.eval()
            frozen = {
                name: value.detach().clone() for name, value in (*model.named_parameters(), *model.named_buffers())
            }
            known = proof.rf.Group.assignments(model, "/entity")
            observations, regimes = proof.generate(row["seed"], row["case"], 10003, 2048)
            measured.update(
                checkpoint_sha256=row["checkpoint_sha256"],
                audit=evaluate(model, observations, row["training_mean"], row["seed"], row["case"]),
            )
            predictions = proof.predict(model, observations)
            measured["per_regime_rmse"] = {
                str(group_id): float(
                    np.mean(
                        (
                            predictions[regimes == group_id]
                            - np.asarray([item["y"] for item in observations])[regimes == group_id]
                        )
                        ** 2
                    )
                    ** 0.5
                )
                for group_id in range(len(proof.CASES[row["case"]]["populations"]))
            }
            shuffled, _ = proof.generate(row["seed"], row["case"], 10003, 2048, shuffle=True)
            measured["shuffled"] = proof.measure(proof.predict(model, shuffled), shuffled, row["training_mean"])
            measured["relabeling"] = proof.relabel(model, observations[:256], row["seed"])
            assert all(
                torch.equal(value, frozen[name]) for name, value in (*model.named_parameters(), *model.named_buffers())
            )
            assert known == proof.rf.Group.assignments(model, "/entity")
            measured["evaluation_preserves_parameters_buffers_and_assignments"] = True
        else:
            measured["error"] = row["error"]
        result["runs"].append(measured)
        output.write_text(json.dumps(result, indent=2) + "\n")
        print("AUDIT", json.dumps(measured), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("train", "audit"))
    parser.add_argument("--seed", type=int, choices=SEEDS)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.phase == "train":
        if args.seed is None:
            parser.error("--seed is required for train")
        validation_panel(args.seed, args.output)
    else:
        audit(args.output)


if __name__ == "__main__":
    main()
