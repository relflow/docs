Frozen numeric Group combination diagnostic, 2026-10-17

This is a research harness, not a production change or canonical proof update.
It imports its unchanged P079 copy and local immutable package source snapshot.
The protocol was written and hashed before the first fit. All 48 fits are run:
3 seeds x 4 numeric processes x 4 additive training variants. Every arm uses
600 optimizer updates and conditional training-residual interventions at
200/400/600. Only validation MSE accepts a proposal; original test split3 is
never generated. Validation is tuning evidence, not an unbiased benchmark.

The baseline exactly preserves canonical P079. Other arms add deterministic
hard straight-through routing, then initialization scale0.1, then proposal
margin1.0 in that order. Only the last arm softens the applied proposal; all
counterfactual trials retain hard routing. The margin1 proposal preserves each
row's previous logsumexp exactly. The other arms preserve P079's original
0/log1e-8 convention, including its tiny numerical mass deviation. Initialization
scales the initial matrix once and only newly allocated identity rows on growth;
learned rows and the sentinel are preserved during growth.

The separate audit command requires all48 validation rows to exist, verifies
code/checkpoint/input hashes, and evaluates every completed arm, including
quality failures, on new known-identity observations using RNG seed*100+10003.
The full 3-seed matrix is fixed before this holdout is visited. No fit resumes,
no failure-based filtering, no test-based variant selection, no new production
SDK knob, and no claim that these numeric root-only residuals generalize to
all extensions, nested geometries, or distributed training.

Reproduce using a Python environment with the recorded installed dependencies:
  python run.py train --seed 7901 --output validation-7901.json
  python run.py train --seed 7902 --output validation-7902.json
  python run.py train --seed 7903 --output validation-7903.json
  python run.py audit --output fresh-holdout-audit.json
The run.py file prepends its own snapshot/src and shared reporting support.
Each training seed command rejects an existing output file; use a fresh copy
for reproduction. Seeds may run concurrently; CPU thread count is1 per process.
Wall times under shared load are descriptive, not an isolated speed benchmark.
The separate P081 timing experiment supplies that comparison.

RNG interpretation: replacing Gumbel sampling with deterministic straight-through
routing removes random draws. Even at the same seed, later masking/dropout draws
therefore differ between baseline and deterministic recipes. Those comparisons
are complete training recipes, not a perfectly mask/RNG-matched causal estimate
of routing alone. The ST, ST+small-init, and ST+small-init+margin1 arms retain the
same draw protocol relative to each other. This caveat was identified while
runs were active; neither the frozen code nor the protocol was altered.
