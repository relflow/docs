"""Package the completed fixed matrix with verified payload hashes, excluding checkpoint binaries."""

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PUBLICATION = ROOT / "publication-artifacts"
SOURCE_ARCHIVE = Path(
    "/Users/grantham/Desktop/docs-0.3.3/proofs/group/diagnostics/expansion-2026-10-17/experiments.tar.gz"
)
SOURCE_ARCHIVE_SHA = "adab27f329b5909aa39a2390fd683b7b9d72b287ac871a87c99a3459a6f4c6fe"
PREFIX = "group-combinations-numeric-20261017"


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    PUBLICATION.mkdir(exist_ok=True)
    assert digest(SOURCE_ARCHIVE.read_bytes()) == SOURCE_ARCHIVE_SHA
    summary = json.loads((ROOT / "summary.json").read_text())
    frozen = json.loads((ROOT / "frozen-source.json").read_text())
    for name, checksum in frozen["files"].items():
        assert digest((ROOT / name).read_bytes()) == checksum
    panels = [json.loads((ROOT / f"validation-{seed}.json").read_text()) for seed in (7901, 7902, 7903)]
    rows = [row for panel in panels for row in panel["runs"]]
    assert len(rows) == 48 and all(row["outcome"] == "completed" for row in rows)
    audit = json.loads((ROOT / "fresh-holdout-audit.json").read_text())
    assert len(audit["runs"]) == 48
    for name, checksum in audit["validation_sha256"].items():
        assert digest((ROOT / name).read_bytes()) == checksum
    checkpoints = {row["checkpoint"]: row["checkpoint_sha256"] for row in rows}
    for name, checksum in checkpoints.items():
        assert digest((ROOT / name).read_bytes()) == checksum
    (ROOT / "checkpoint-sha256.json").write_text(json.dumps(checkpoints, indent=2) + "\n")
    names = {
        "predictive": "Predictive baseline",
        "predictive_st": "+ deterministic ST",
        "predictive_st_small": "+ initialization scale 0.1",
        "predictive_st_small_margin1": "+ proposal margin 1",
    }
    table = [
        "| Recipe | Validation full gates | Fresh audit full gates | Fresh audit quality |",
        "| --- | ---: | ---: | ---: |",
    ]
    for arm, label in names.items():
        result = summary["by_arm"][arm]
        quality = sum(case["audit"]["quality_passes"] for case in result["per_case"].values())
        table.append(
            f"| {label} | {result['validation_all_five_gates_met']}/12 | {result['audit_all_five_gates_met']}/12 | {quality}/12 |"
        )
    cases = [
        "| Recipe | Crossing four Q/C | Imbalanced four Q/C | Six groups Q/C | Separated four Q/C |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for arm, label in names.items():
        rates = summary["by_arm"][arm]["per_case"]
        cells = [
            f"{rates[case]['audit']['quality_passes']}/3; {rates[case]['audit']['count_passes']}/3"
            for case in ("crossing_four", "imbalanced_four", "separated_six", "separated_four")
        ]
        cases.append("| " + " | ".join([label, *cells]) + " |")
    readme = (
        """# Numeric predictive-grouping combination evidence

All 48 predefined fits completed: four recipes, four numeric processes, three
seeds (7901–7903), 600 optimizer updates each. The unchanged P079 baseline is
followed by deterministic hard straight-through routing, assignment initialization
scale 0.1, and proposal margin 1. Each row adds the named change to the previous
recipe. The frozen `protocol.json` and harness identify the exact methods.
Production code and canonical proof results were not changed by this matrix.

"""
        + "\n".join(table)
        + """

Full gates require ARI at least 0.8, normalized RMSE at most 0.35, exact occupied
group count, shuffled error at least 0.85, and shuffling error increase at least
0.4. Quality means the first two gates. Error is divided by the training-mean
constant predictor's error: 1 is constant-guess performance, lower is better.
ARI 1 means the same partition after allowing arbitrary group label names.

The fresh-audit quality/count rates below each use all three seeds. Q/C cells
show quality passes followed by exact-count passes; neither denominator drops
failures.

"""
        + "\n".join(cases)
        + """

The strongest stack improves six-group recovery to ARI 1 and six occupied groups
in every seed, with fresh error ratios 0.0327–0.0391 (baseline 0.2286–0.2628).
It also passes all crossing-curve and separated-four seeds. Imbalance remains a
failure: only one of three seeds recovers the exact count; seed 7901 has ARI
0.535 despite an acceptable global error ratio 0.223. Smaller initialization
without margin 1 also solves all six-group seeds but splits a crossing group in
seed 7901 and merges groups in two imbalanced seeds. No recipe solves this
entire bounded matrix.

## Validation and interpretation boundaries

Cases, seeds, methods and thresholds were frozen before the first fit. A proposal
uses only per-identity conditional training errors and is accepted only if
validation MSE improves. Validation is reused for development and is tuning data.
After all validation files finished, a separate command froze their hashes and
audited every checkpoint on 2,048 independently generated known-identity rows
using stream `seed*100+10003`, retaining the same generating partition. Original
P079 test stream 3 is never generated by this harness. Every arm, including
quality failures, received that audit; there was no audit-based retraining or
variant filtering. All parameter/buffer/assignment preservation assertions passed.
Group-label permutation diagnostics and shuffled-control measurements are in the
raw audit JSON. Existing baseline assignment arrays and intervention acceptance
flags reproduce canonical P079 exactly in all 12 matched cases.

Removing Gumbel draws changes later masking/dropout RNG draws even at the same
seed. Baseline-versus-ST comparisons therefore compare complete training recipes,
not a perfectly RNG-matched routing-only causal intervention. The three ST recipes
share the same RNG draw protocol relative to one another. This matrix excludes
no-regime fits and is not a complete canonical proof panel or a universal capacity
recovery claim. It remains a root-only numeric residual diagnostic; integrating
it generically requires extension-owned losses and identity/geometry attribution.
Recorded wall times use concurrent CPU load and are not an isolated benchmark.
The separate P081 +28.60% result concerns the original predictive recipe, not a
measured cost for these combinations.

## Contents and reproduction

The archive preserves all validation/audit JSON, per-seed logs, summary and
summary source, frozen harness/protocol/P079/helper sources, environment metadata,
the exact Group source for reference, and every checkpoint SHA-256. It excludes
trained checkpoint binaries, caches, lock files and duplicate full package
snapshots. `FILE_SHA256.json` records payload integrity; sibling `manifest.json`
records the archive digest and every member digest/size. Tar metadata and gzip
mtime are normalized. Every archived member was read back and verified.

The package source dependency is the separate docs archive
`proofs/group/diagnostics/expansion-2026-10-17/experiments.tar.gz`, SHA-256
`adab27f329b5909aa39a2390fd683b7b9d72b287ac871a87c99a3459a6f4c6fe`.
It contains `group-expansion-20261017/snapshot`, with source-tree digest
`4f900097c5f12eb6eef07e88b7abba5c61089f52696d52ee8c08d105894a5b58`.
Unpack both archives into an empty directory, then link that snapshot into the
combination directory:

```bash
ln -s ../group-expansion-20261017/snapshot group-combinations-numeric-20261017/snapshot
cd group-combinations-numeric-20261017
```

Use an environment matching `environment.json`; install the archived snapshot
package, including its pyproject metadata. Work in a fresh copy and preserve
recorded outputs by renaming the three `validation-790*.json` and
`fresh-holdout-audit.json` files before rerunning. Then execute:

```bash
python run.py train --seed 7901 --output validation-7901.json
python run.py train --seed 7902 --output validation-7902.json
python run.py train --seed 7903 --output validation-7903.json
python run.py audit --output fresh-holdout-audit.json
python summarize.py
```

Each seed receives exactly 16 fits and rejects an existing output file; there
are no cached-fit resumes. The audit requires all 48 completed recipe entries,
checks source and checkpoint hashes, and freezes validation hashes before use.
A new reproduction has new checkpoint hashes; original recorded checkpoint
binaries are deliberately not published here. Nothing runs when the archive is
rendered or copied into the docs.
"""
    )
    (PUBLICATION / "README.md").write_text(readme)
    files = {
        name: ROOT / name
        for name in (
            "run.py",
            "p079.py",
            "protocol.json",
            "frozen-source.json",
            "environment.json",
            "README.txt",
            "summarize.py",
            "summary.json",
            "summary.log",
            "fresh-holdout-audit.json",
            "audit.log",
            "checkpoint-sha256.json",
            "baseline-reproduction.json",
            "proofs/reporting.py",
            "proofs/source.py",
            "build_publication.py",
        )
    }
    for seed in (7901, 7902, 7903):
        for name in (f"validation-{seed}.json", f"train-{seed}.log"):
            files[name] = ROOT / name
    files["README.md"] = PUBLICATION / "README.md"
    files["reference/group.py"] = ROOT / "snapshot/src/relflow/tensorfields/extensions/group.py"
    payload = {name: path.read_bytes() for name, path in files.items()}
    inventory = {name: {"sha256": digest(content), "bytes": len(content)} for name, content in sorted(payload.items())}
    payload["FILE_SHA256.json"] = (json.dumps(inventory, indent=2) + "\n").encode()
    archive_path = PUBLICATION / "experiments.tar.gz"
    with (
        archive_path.open("wb") as raw,
        gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed,
        tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive,
    ):
        for name, content in sorted(payload.items()):
            info = tarfile.TarInfo(PREFIX + "/" + name)
            info.size, info.mode, info.mtime = len(content), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(content))
    members = {}
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive.getmembers():
            assert member.isfile() and member.name.startswith(PREFIX + "/")
            name = member.name.removeprefix(PREFIX + "/")
            content = archive.extractfile(member).read()
            assert content == payload[name]
            members[member.name] = {
                "sha256": digest(content),
                "bytes": len(content),
                "recorded_origin": str(files[name]) if name in files else "Generated internal payload manifest",
            }
    assert len(members) == len(payload)
    manifest = {
        "schema": 1,
        "archive": {
            "filename": archive_path.name,
            "sha256": digest(archive_path.read_bytes()),
            "bytes": archive_path.stat().st_size,
        },
        "source_dependency": {
            "docs_path": "proofs/group/diagnostics/expansion-2026-10-17/experiments.tar.gz",
            "archive_sha256": SOURCE_ARCHIVE_SHA,
            "source_tree_sha256": frozen["source_tree_sha256"],
            "package_member_prefix": "group-expansion-20261017/snapshot",
        },
        "protocol": {
            "fits": 48,
            "seeds": [7901, 7902, 7903],
            "steps_per_fit": 600,
            "original_test_stream_used": False,
            "no_regime_included": False,
            "production_changed": False,
        },
        "verification": "Every compressed member was read back and compared byte-for-byte with payload; every input checkpoint and validation hash verified before packaging.",
        "members": members,
    }
    (PUBLICATION / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(
        json.dumps({"archive": manifest["archive"], "members": len(members), "publication": str(PUBLICATION)}, indent=2)
    )


if __name__ == "__main__":
    main()
