"""Summarize every predeclared run without filtering failed gates or changing selection."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEEDS = (7901, 7902, 7903)
ARMS = ("predictive", "predictive_st", "predictive_st_small", "predictive_st_small_margin1")
CASES = ("crossing_four", "imbalanced_four", "separated_six", "separated_four")


def gates(metric, shuffled):
    return {
        "ARI_at_least_.8": metric["adjusted_rand"] >= 0.8,
        "nRMSE_at_most_.35": metric["normalized_rmse"] <= 0.35,
        "exact_count": metric["occupied_groups"] == metric["generating_groups"],
        "shuffled_nRMSE_at_least_.85": shuffled["normalized_rmse"] >= 0.85,
        "shuffling_adds_at_least_.4_nRMSE": shuffled["normalized_rmse"] - metric["normalized_rmse"] >= 0.4,
    }


def main():
    validation = [row for seed in SEEDS for row in json.loads((ROOT / f"validation-{seed}.json").read_text())["runs"]]
    audit = json.loads((ROOT / "fresh-holdout-audit.json").read_text())["runs"]
    lookup = {(row["seed"], row["case"], row["arm"]): row for row in audit}
    assert len(validation) == len(audit) == 48
    result = {
        "scope": "All 48 predeclared fits; original test stream never used; development decisions are validation-only; fresh audit includes every arm without selection.",
        "limitations": [
            "This matrix excludes no-regime fits and is not a complete canonical proof panel.",
            "Gumbel-to-ST changes RNG consumption, so later masking/dropout draws differ. Compare complete training recipes, not perfectly RNG-matched routing-only causal effects.",
            "The ST, ST+small-init, and ST+small-init+margin1 arms share the same RNG draw protocol relative to each other.",
            "Validation accepts proposals and compares recipes; it is tuning data. Fresh audit rows use split10003 only after all variants and validation files freeze.",
            "No production code or default behavior changed; these are root-only numeric residual experiments.",
            "Concurrent CPU wall times are descriptive, not the separate P081 isolated cost benchmark.",
        ],
        "by_arm": {},
        "runs": [],
    }
    for arm in ARMS:
        aggregate = {
            "fits": 12,
            "execution_errors": 0,
            "validation_all_five_gates_met": 0,
            "audit_all_five_gates_met": 0,
            "validation_gates_met": {},
            "audit_gates_met": {},
        }
        for row in (row for row in validation if row["arm"] == arm):
            item = {key: row[key] for key in ("seed", "case", "arm", "outcome")}
            if row["outcome"] != "completed":
                aggregate["execution_errors"] += 1
                item["error"] = row["error"]
            else:
                heldout = lookup[(row["seed"], row["case"], arm)]
                item["validation"] = {
                    key: row["validation"][key]
                    for key in ("adjusted_rand", "normalized_rmse", "occupied_groups", "generating_groups")
                }
                item["audit"] = {
                    key: heldout["audit"][key]
                    for key in ("adjusted_rand", "normalized_rmse", "occupied_groups", "generating_groups")
                }
                for phase, metric, shuffled in (
                    ("validation", row["validation"], row["shuffled_validation"]),
                    ("audit", heldout["audit"], heldout["shuffled"]),
                ):
                    checks = gates(metric, shuffled)
                    item[phase + "_checks"] = checks
                    aggregate[phase + "_all_five_gates_met"] += int(all(checks.values()))
                    for name, passed in checks.items():
                        aggregate[phase + "_gates_met"][name] = aggregate[phase + "_gates_met"].get(name, 0) + int(
                            passed
                        )
            result["runs"].append(item)
        aggregate["per_case"] = {}
        for case in CASES:
            values = [row for row in result["runs"] if row["case"] == case and row["arm"] == arm]
            case_rates = {"fits": 3}
            for phase in ("validation", "audit"):
                completed = [row for row in values if row["outcome"] == "completed"]
                case_rates[phase] = {
                    "quality_passes": sum(
                        row[phase + "_checks"]["ARI_at_least_.8"] and row[phase + "_checks"]["nRMSE_at_most_.35"]
                        for row in completed
                    ),
                    "count_passes": sum(row[phase + "_checks"]["exact_count"] for row in completed),
                    "all_five_gates_passes": sum(all(row[phase + "_checks"].values()) for row in completed),
                    "ARI_range": [
                        min(row[phase]["adjusted_rand"] for row in completed),
                        max(row[phase]["adjusted_rand"] for row in completed),
                    ],
                    "nRMSE_range": [
                        min(row[phase]["normalized_rmse"] for row in completed),
                        max(row[phase]["normalized_rmse"] for row in completed),
                    ],
                    "occupied_counts_by_seed": {str(row["seed"]): row[phase]["occupied_groups"] for row in completed},
                }
            aggregate["per_case"][case] = case_rates
        result["by_arm"][arm] = aggregate
    (ROOT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    for arm, aggregate in result["by_arm"].items():
        print(arm, json.dumps(aggregate))
        for case in CASES:
            values = [row for row in result["runs"] if row["case"] == case and row["arm"] == arm]
            print(
                case,
                json.dumps([{key: row.get(key) for key in ("seed", "validation", "audit", "error")} for row in values]),
            )


if __name__ == "__main__":
    main()
