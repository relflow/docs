"""Run unchanged Group proofs against one frozen SDK source snapshot."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
PYTHON = Path('/Users/grantham/Desktop/relflow/.venv/bin/python')
CASES = (
    ('P065', 'proofs/vocabulary/group_pretraining_coverage.py', (7651, 7652, 7653)),
    ('P078', 'proofs/group/regime_recovery.py', (7801, 7802, 7803)),
)


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify():
    manifest = json.loads((ROOT / 'source-manifest.json').read_text())
    for name, expected in manifest['source_files'].items():
        actual = hashlib.sha256((ROOT / 'source' / name).read_bytes()).hexdigest()
        assert actual == expected, name
    for name, expected in manifest['proof_files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    return manifest


def summarize():
    path = ROOT / 'results.yaml'
    document = yaml.safe_load(path.read_text()) if path.exists() else {'proofs': {}}
    runs = []
    for identifier in ('P065', 'P078'):
        for result in document['proofs'].get(identifier, {}).get('runs', []):
            item = {
                'proof': identifier,
                'seed': result['seed'],
                'outcome': result['outcome'],
                'duration_seconds': result['duration_seconds'],
                'failed_checks': [name for name, passed in result.get('checks', {}).items() if not passed],
                'source_sha256': result.get('provenance', {}).get('relflow_source_sha256'),
                'metrics': result.get('metrics', {}),
            }
            if 'error' in result:
                item['error'] = result['error']
            runs.append(item)
    result = {'runs': runs, 'completed_invocations': len(runs), 'planned_invocations': 6}
    save('summary.json', result)
    return result


def main():
    manifest = verify()
    environment = os.environ.copy()
    environment.update({
        'PYTHONPATH': str(ROOT / 'source/src') + os.pathsep + str(ROOT / 'proofs'),
        'PYTHONUNBUFFERED': '1',
        'OMP_NUM_THREADS': '1',
        'MKL_NUM_THREADS': '1',
        'OPENBLAS_NUM_THREADS': '1',
    })
    probe = subprocess.run(
        [str(PYTHON), '-c', 'import relflow as rf; print(rf.__file__)'],
        cwd=ROOT, env=environment, capture_output=True, text=True, check=True,
    )
    assert str(ROOT / 'source/src/relflow') in probe.stdout, probe.stdout
    save('environment.json', {
        'python': str(PYTHON), 'relflow_path': probe.stdout.strip(),
        'source_sha256': manifest['source_sha256'],
        'thread_environment': {name: environment[name] for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS')},
    })
    commands = []
    for identifier, script, seeds in CASES:
        for seed in seeds:
            verify()
            existing = summarize()['runs']
            if any(item['proof'] == identifier and item['seed'] == seed for item in existing):
                continue
            command = [str(PYTHON), str(ROOT / script), '--seed', str(seed), '--accelerator', 'cpu', '--threads', '1', '--output', str(ROOT / 'results.yaml')]
            log = ROOT / f'{identifier}-{seed}.log'
            print(json.dumps({'starting': identifier, 'seed': seed, 'log': str(log)}), flush=True)
            with log.open('w') as stream:
                completed = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
            commands.append({'proof': identifier, 'seed': seed, 'command': command, 'returncode': completed.returncode})
            save('commands.json', commands)
            lines = log.read_text().splitlines()
            (ROOT / f'{identifier}-{seed}-refinement.txt').write_text('\n'.join(line for line in lines if 'refin' in line.lower()) + '\n')
            latest = summarize()
            outcome = next((item for item in latest['runs'] if item['proof'] == identifier and item['seed'] == seed), None)
            print(json.dumps({'finished': identifier, 'seed': seed, 'returncode': completed.returncode, 'outcome': None if outcome is None else outcome['outcome'], 'failed_checks': None if outcome is None else outcome['failed_checks']}), flush=True)
    verify()
    final = summarize()
    print(json.dumps({'completed_invocations': final['completed_invocations'], 'outcomes': [(item['proof'], item['seed'], item['outcome']) for item in final['runs']]}), flush=True)


if __name__ == '__main__':
    main()
