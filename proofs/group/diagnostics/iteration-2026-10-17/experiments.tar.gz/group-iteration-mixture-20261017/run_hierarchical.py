"""Validation-only normalized label mixtures; retained raw scoring is the control."""

from __future__ import annotations

import argparse
from contextlib import ExitStack
from functools import partial
import hashlib
import importlib.util
import inspect
import json
import logging
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "proofs"))

import lightning.pytorch as lit
import numpy as np
import torch

import relflow as rf
from relflow.tensorfields.extensions import group

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


P078 = load("mixture_p078", ROOT / "proofs/group/regime_recovery.py")
P065 = load("mixture_p065", ROOT / "proofs/vocabulary/group_pretraining_coverage.py")


def hard(logits, tau=1.0, hard=False, eps=1e-10, dim=-1):
    soft = (logits / tau).softmax(dim)
    onehot = torch.zeros_like(soft).scatter_(dim, soft.argmax(dim, keepdim=True), 1)
    return onehot - soft.detach() + soft


def mixture(embedder, probabilities):
    """Hard identity membership with trainable within-group label priors."""
    weights = embedder.embeddings["group"].weight[:len(embedder.vocab.master)].float()
    memberships = embedder.support(weights).detach().argmax(dim=-1)
    priors = weights.mean(dim=-1)
    columns = torch.arange(embedder.size, device=weights.device)
    conditional = priors[:,None].expand(-1,embedder.size).masked_fill(memberships[:,None] != columns, -torch.inf)
    normalizers = torch.logsumexp(conditional,dim=0)
    populated = torch.isfinite(normalizers)
    conditional = conditional - normalizers.masked_fill(~populated,0)
    selected = probabilities.float() * populated
    selected = selected / selected.sum(dim=-1,keepdim=True).clamp_min(1e-30)
    return torch.logsumexp(selected.clamp_min(1e-30).log()[:,None,:] + conditional[None,:,:],dim=-1)


def run(task, case, seed):
    lit.seed_everything(seed, workers=True)
    initial = group.Embedder.__init__
    resize = group.Embedder.resize
    scale = 0.1

    def init(self, *args, **kwargs):
        initial(self, *args, **kwargs)
        with torch.no_grad():
            weights = self.embeddings["group"].weight
            weights.zero_()
            weights[:-1].scatter_(1, (torch.arange(weights.shape[0]-1) % weights.shape[1]).unsqueeze(1), scale)

    def grow(self, size, plan):
        previous = self.embeddings["group"].weight
        resize(self, size, plan)
        with torch.no_grad():
            for old, new in plan.parameters:
                if old is previous:
                    start = old.shape[0]-1
                    stop = new.shape[0]-1
                    new[start:stop].zero_()
                    new[start:stop].scatter_(1, (torch.arange(start, stop) % new.shape[1]).unsqueeze(1), scale)

    with ExitStack() as stack:
        stack.enter_context(patch.object(group.Embedder, "__init__", init))
        stack.enter_context(patch.object(group.Embedder, "resize", grow))
        stack.enter_context(patch("torch.nn.functional.gumbel_softmax", hard))
        if case != "raw_st_small":
            stack.enter_context(patch.object(group, "vocabulary_logits", mixture))
        if case == "hierarchical_no_balance":
            source = inspect.getsource(group.loss)
            assert source.count("value=balance_loss,") == 1
            namespace = dict(vars(group))
            exec(compile(source.replace("@group.register(Component.loss)\n", "").replace("value=balance_loss,", "value=balance_loss * 0,"), "<mixture-loss-no-balance>", "exec"), namespace)
            stack.enter_context(patch.dict(group.group.components, {rf.Component.loss: namespace["loss"]}))
        proof = P078 if task == "p078" else P065
        model = proof.build()
        if task == "p078":
            args = {"partition_seed": seed * 100, "no_regime": False}
            train = list(proof.records(rows=4096, seed=seed*100+1, **args))
            valid = list(proof.records(rows=1024, seed=seed*100+2, **args))
            budget = 600
        else:
            train = list(proof.records(rows=8192, seed=seed+1))
            valid = list(proof.records(rows=1024, seed=seed+2))
            budget = 800
        data = rf.SyntheticDataModule(model=model, train=lambda: iter(train), validate=lambda: iter(valid), seed=seed)
        trainer = lit.Trainer(accelerator="cpu", devices=1, max_steps=budget, max_epochs=-1, logger=False,
                              enable_checkpointing=False, enable_progress_bar=False, enable_model_summary=False,
                              deterministic=True, num_sanity_val_steps=0)
        start = time.perf_counter()
        trainer.fit(model, datamodule=data)
        model.eval()
        elapsed = time.perf_counter()-start
        result = {"task": task, "case": case, "seed": seed, "steps": trainer.global_step, "seconds": elapsed}
        if task == "p078":
            result.update(proof.measure(model, valid, float(np.mean([r["y"] for r in train])), seed*100))
        else:
            coverage = {}
            for keep in (512, 256, 51, 0):
                selected = 0
                rows = []
                for row in valid:
                    rows.append({**row, "code": f"novel-{row['code']}" if row["hide"] and selected >= keep else row["code"]})
                    selected += int(row["hide"])
                metrics = proof.evaluate(trainer, model, rows)
                coverage[str(keep)] = {k: v if np.isfinite(v) else None for k, v in metrics.items()}
            result["coverage"] = coverage
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=["p078", "p065"], default="p078")
    parser.add_argument("--case", choices=["raw_st_small", "hierarchical", "hierarchical_no_balance"], required=True)
    parser.add_argument("--seed", type=int, default=7801)
    args = parser.parse_args()
    output = ROOT / f"{args.task}-{args.case}-balanced-{args.seed}.json"
    print("START", vars(args), flush=True)
    result = run(args.task, args.case, args.seed)
    result["provenance"] = json.loads((ROOT/"provenance.json").read_text())
    result["harness_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result["protocol"] = "Validation only; no canonical test split; deterministic ST; weak balanced index-modulo-K initialization; hard membership conditional label likelihood with trainable row-mean priors; original per-task budgets"
    output.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
    print("RESULT", json.dumps(result, allow_nan=False), flush=True)
