"""Run existing runtime probability regressions against an experimental scorer."""

import argparse
import importlib.util
from pathlib import Path
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument("--variant", choices=["run", "run_hierarchical"], required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("experimental_scoring", root / f"{args.variant}.py")
experiment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(experiment)

import pytest

test = "/Users/grantham/Desktop/relflow/tests/tensorfields/extensions/test_group_state.py"
with patch.object(experiment.group, "vocabulary_logits", experiment.mixture):
    raise SystemExit(pytest.main([
        "-q", "-o", "addopts=", "--confcutdir=/Users/grantham/Desktop/relflow",
        test + "::test_single_group_preserves_nonuniform_learned_identity_priors",
        test + "::test_bfloat16_writer_and_reconstruction_metrics_choose_the_same_identity",
    ]))
