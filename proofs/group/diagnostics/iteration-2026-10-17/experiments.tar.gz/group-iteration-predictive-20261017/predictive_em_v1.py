"""Proof-local predictive grouping references and frozen-neural reassignment.

No production source is patched. Candidate K is selected from validation data;
test data and generating partitions are consulted only after selection.
"""

# ruff: noqa: E402

import argparse
import hashlib
import importlib.util
import json
import math
import os
import platform
import sys
import time
from functools import partial
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
WORK = Path(__file__).resolve().parent
PROOFS = WORK / "proofs"
sys.path.insert(0, str(PROOFS))
sys.path.insert(0, str(WORK / "snapshot" / "src"))

import lightning.pytorch as lit
import numpy as np
import pyarrow as pa
import torch

import relflow as rf

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
spec = importlib.util.spec_from_file_location("p078_reference_source", WORK / "regime_recovery_source.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)


def truth(seed, variant):
    if variant == "imbalanced":
        return np.random.default_rng(seed * 100).permutation(np.repeat(np.arange(4), [40, 12, 8, 4]))
    return proof.partition(seed * 100)


def records(seed, split, variant):
    rows = {"train": 4096, "validate": 1024, "test": 2048}[split]
    data_seed = seed * 100 + {"train": 1, "validate": 2, "test": 3}[split]
    if variant in ("stable", "no_regime"):
        return list(
            proof.records(rows=rows, seed=data_seed, partition_seed=seed * 100, no_regime=variant == "no_regime")
        )
    rng = np.random.default_rng(data_seed)
    entities = np.resize(np.arange(64), rows)
    rng.shuffle(entities)
    groups = truth(seed, variant)[entities]
    x = rng.uniform(-1, 1, rows)
    intercepts, slopes = proof.INTERCEPTS, proof.SLOPES
    if variant == "crossing":
        intercepts, slopes = np.zeros(4), np.asarray([-6.0, -2.0, 2.0, 6.0])
    y = intercepts[groups] + slopes[groups] * x + rng.normal(0, 0.1, rows)
    return [{"entity": f"entity-{i:04d}", "x": float(a), "y": float(b)} for i, a, b in zip(entities, x, y, strict=True)]


def arrays(rows):
    return (
        np.asarray([int(row["entity"].split("-")[-1]) for row in rows]),
        np.asarray([row["x"] for row in rows]),
        np.asarray([row["y"] for row in rows]),
    )


def metrics(predicted, rows, training_mean, assignments, expected):
    target = arrays(rows)[2]
    rmse = float(np.mean((predicted - target) ** 2) ** 0.5)
    baseline = float(np.mean((training_mean - target) ** 2) ** 0.5)
    return {
        "rmse": rmse,
        "baseline_rmse": baseline,
        "normalized_rmse": rmse / baseline,
        "adjusted_rand": proof.adjusted_rand(expected, assignments),
        "occupied_groups": len(set(assignments.tolist())),
        "assignments": assignments.tolist(),
    }


def shuffled(rows, seed):
    entity = np.asarray([row["entity"] for row in rows])
    entity = entity[np.random.default_rng(seed).permutation(len(entity))]
    return [{**row, "entity": str(value)} for row, value in zip(rows, entity, strict=True)]


def neural_predict(model, rows):
    visible = pa.Table.from_pylist([{"entity": row["entity"], "x": row["x"]} for row in rows])
    original_batch_size = model.batch_size
    try:
        output = model.predict(visible, batch_size=256)["predictions"].combine_chunks().field("y").field("content")
    finally:
        model.batch_size = original_batch_size
    return output.to_numpy(zero_copy_only=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprints():
    return {
        "harness_sha256": digest(__file__),
        "source_tree_sha256": json.loads((WORK / "manifest.json").read_text())["source_tree_sha256"],
        "group_sha256": digest(WORK / "snapshot/src/relflow/tensorfields/extensions/group.py"),
        "proof_sha256": digest(WORK / "regime_recovery_source.py"),
        "proof_dependencies": {name: digest(PROOFS / name) for name in ("reporting.py", "source.py")},
    }


def intervene(model, train, validate, optimizers, mechanism):
    """Predictive residual search versus a matched margin/history-reset control."""
    started = time.perf_counter()
    embedder = model.nodes["/entity"].embedder
    vocabulary = list(rf.Group.vocabulary(model, "/entity"))
    weight = embedder.embeddings["group"].weight
    before = weight.detach().clone()
    entity_order = np.asarray([int(value.split("-")[-1]) for value in vocabulary])
    available = (~embedder.retired).nonzero(as_tuple=True)[0].tolist()
    validation_target = arrays(validate)[2]
    before_mse = float(np.mean((neural_predict(model, validate) - validation_target) ** 2))
    row_mass = before[: len(vocabulary)].logsumexp(-1, keepdim=True)
    counterfactual_seconds = 0.0
    if mechanism == "predictive":
        train_entity, _, train_target = arrays(train)
        errors = np.full((64, embedder.size), np.inf)
        tick = time.perf_counter()
        try:
            for group_id in available:
                forced = torch.full_like(before[: len(vocabulary)], math.log(1e-8))
                forced[:, group_id] = 0
                with torch.no_grad():
                    weight[: len(vocabulary)].copy_(row_mass + forced)
                predicted = neural_predict(model, train)
                errors[:, group_id] = np.bincount(train_entity, weights=(predicted - train_target) ** 2, minlength=64)
        finally:
            with torch.no_grad():
                weight.copy_(before)
        counterfactual_seconds = time.perf_counter() - tick
        proposed = errors.argmin(-1)
    else:
        proposed = np.empty(64, dtype=np.int64)
        proposed[entity_order] = embedder.support(before[: len(vocabulary)]).argmax(-1).cpu().numpy()
    forced = torch.full_like(before[: len(vocabulary)], math.log(1e-8))
    forced[torch.arange(len(vocabulary)), torch.as_tensor(proposed[entity_order])] = 0
    with torch.no_grad():
        weight[: len(vocabulary)].copy_(row_mass + forced)
    after_mse = float(np.mean((neural_predict(model, validate) - validation_target) ** 2))
    # Hardening deliberately retains existing membership, so it is always applied.
    accepted = mechanism == "harden" or after_mse < before_mse
    if accepted:
        if weight.grad is not None:
            weight.grad[: len(vocabulary)].zero_()
        for optimizer in optimizers:
            for value in optimizer.state.get(weight, {}).values():
                if isinstance(value, torch.Tensor) and value.shape == weight.shape:
                    value[: len(vocabulary)].zero_()
    else:
        with torch.no_grad():
            weight.copy_(before)
    return {
        "mechanism": mechanism,
        "event_wall_seconds": time.perf_counter() - started,
        "counterfactual_seconds": counterfactual_seconds,
        "counterfactual_training_rows_evaluated": len(train) * len(available) if mechanism == "predictive" else 0,
        "selection_validation_rows_evaluated": 2 * len(validate),
        "candidate_groups": available,
        "before_validation_mse": before_mse,
        "proposed_validation_mse": after_mse,
        "accepted_by_validation": accepted if mechanism == "predictive" else None,
        "proposed_assignments": proposed.tolist(),
    }


class Alternation(lit.Callback):
    def __init__(self, train, validate, mechanism):
        self.train_rows, self.validation_rows, self.mechanism = train, validate, mechanism
        self.events = []

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        step = trainer.global_step
        if step not in (200, 400) or any(event["step"] == step for event in self.events):
            return
        event = intervene(pl_module, self.train_rows, self.validation_rows, trainer.optimizers, self.mechanism)
        self.events.append({"step": step, **event})


def validation_run(seed, variant, mechanism, directory):
    lit.seed_everything(seed, workers=True)
    started = time.perf_counter()
    model = proof.build()
    train, validate = records(seed, "train", variant), records(seed, "validate", variant)
    data = rf.SyntheticDataModule(model=model, train=partial(iter, train), validate=partial(iter, validate), seed=seed)
    callback = Alternation(train, validate, mechanism)
    trainer = lit.Trainer(
        accelerator="cpu",
        devices=1,
        max_steps=600,
        max_epochs=-1,
        logger=False,
        enable_checkpointing=False,
        enable_progress_bar=False,
        enable_model_summary=False,
        deterministic=True,
        num_sanity_val_steps=0,
        callbacks=[callback],
    )
    tick = time.perf_counter()
    trainer.fit(model, datamodule=data)
    fit_wall_seconds = time.perf_counter() - tick
    assert trainer.global_step == 600
    model.eval()
    event = intervene(model, train, validate, trainer.optimizers, mechanism)
    callback.events.append({"step": 600, **event})
    assignment_rows = rf.Group.assignments(model, "/entity")
    assignments = np.asarray([assignment_rows[f"entity-{i:04d}"]["group"] for i in range(64)])
    mean = float(arrays(train)[2].mean())
    state = {name: value.detach().clone() for name, value in (*model.named_parameters(), *model.named_buffers())}
    measured = metrics(neural_predict(model, validate), validate, mean, assignments, truth(seed, variant))
    corrupted = shuffled(validate, seed * 100 + 4)
    corruption = metrics(neural_predict(model, corrupted), corrupted, mean, assignments, truth(seed, variant))
    assert assignment_rows == rf.Group.assignments(model, "/entity")
    assert all(torch.equal(value, state[name]) for name, value in (*model.named_parameters(), *model.named_buffers()))
    path = directory / f"{mechanism}-{variant}-{seed}.ckpt"
    model.save(path)
    return {
        "seed": seed,
        "variant": variant,
        "mechanism": mechanism,
        "provenance": fingerprints(),
        "checkpoint": str(path.relative_to(WORK)),
        "checkpoint_sha256": digest(path),
        "optimizer_updates": trainer.global_step,
        "batch_size": 128,
        "events": callback.events,
        "fit_wall_seconds_including_200_400_interventions": fit_wall_seconds,
        "total_wall_seconds_including_600_event_and_validation_audit": time.perf_counter() - started,
        "extra_intervention_wall_seconds": sum(item["event_wall_seconds"] for item in callback.events),
        "counterfactual_seconds": sum(item["counterfactual_seconds"] for item in callback.events),
        "counterfactual_training_rows_evaluated": sum(
            item["counterfactual_training_rows_evaluated"] for item in callback.events
        ),
        "selection_validation_rows_evaluated": sum(
            item["selection_validation_rows_evaluated"] for item in callback.events
        ),
        "evaluation_preserves_parameters_buffers_and_assignments": True,
        "validation": measured,
        "shuffled_validation": corruption,
        "status": rf.Group.status(model, "/entity"),
        "protocol": "600 original optimizer updates; steps200/400/600 interventions; training-residual group choice accepted only by validation MSE; no test rows loaded; known 64-identity root-only diagnostic; no production API change.",
    }


def panel_checks(runs):
    checks = {}
    for seed in (7801, 7802, 7803):
        for variant in ("stable", "no_regime"):
            found = [
                run
                for run in runs
                if run["seed"] == seed and run["variant"] == variant and run["mechanism"] == "predictive"
            ]
            checks[f"{seed}/{variant}/complete"] = len(found) == 1
            if not found:
                continue
            run = found[0]
            metric, corruption = run["validation"], run["shuffled_validation"]
            checks[f"{seed}/{variant}/600_updates"] = run["optimizer_updates"] == 600
            if variant == "stable":
                checks[f"{seed}/ARI_ge_.80"] = metric["adjusted_rand"] >= 0.80
                checks[f"{seed}/nRMSE_le_.35"] = metric["normalized_rmse"] <= 0.35
                checks[f"{seed}/shuffle_nRMSE_ge_.85"] = corruption["normalized_rmse"] >= 0.85
                checks[f"{seed}/shuffle_delta_ge_.40"] = (
                    corruption["normalized_rmse"] - metric["normalized_rmse"] >= 0.40
                )
            else:
                checks[f"{seed}/control_ARI_le_.15"] = metric["adjusted_rand"] <= 0.15
                checks[f"{seed}/control_nRMSE_ge_.85"] = metric["normalized_rmse"] >= 0.85
    return checks


def heldout_run(run):
    assert run["provenance"] == fingerprints(), "source or harness changed after validation"
    path = WORK / run["checkpoint"]
    assert digest(path) == run["checkpoint_sha256"], "validated checkpoint changed"
    model = rf.Model.load(path)
    model.eval()
    seed, variant = run["seed"], run["variant"]
    train, test = records(seed, "train", variant), records(seed, "test", variant)
    assignment_rows = rf.Group.assignments(model, "/entity")
    assignments = np.asarray([assignment_rows[f"entity-{i:04d}"]["group"] for i in range(64)])
    mean = float(arrays(train)[2].mean())
    measured = metrics(neural_predict(model, test), test, mean, assignments, truth(seed, variant))
    result = {
        "seed": seed,
        "variant": variant,
        "mechanism": run["mechanism"],
        "provenance": fingerprints(),
        "checkpoint_sha256": digest(path),
        "test": measured,
    }
    if variant == "stable":
        corrupted = records(seed, "test", "no_regime")
        result["shuffled_test"] = metrics(
            neural_predict(model, corrupted), corrupted, mean, assignments, truth(seed, variant)
        )
    assert assignment_rows == rf.Group.assignments(model, "/entity")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["validation", "heldout"])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--validation-input", type=Path)
    parser.add_argument("--seeds", nargs="+", type=int, default=[7801, 7802, 7803])
    parser.add_argument(
        "--variants",
        nargs="+",
        choices=["stable", "no_regime", "imbalanced", "crossing"],
        default=["stable", "no_regime"],
    )
    parser.add_argument("--mechanisms", nargs="+", choices=["predictive", "harden"], default=["predictive"])
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"Fresh-panel output must not exist: {args.output}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    directory = args.output.parent / f"{args.output.stem}-checkpoints"
    directory.mkdir()
    results = {
        "provenance": fingerprints(),
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "lightning": lit.__version__,
            "pyarrow": pa.__version__,
            "numpy": np.__version__,
            "torch_threads": torch.get_num_threads(),
        },
        "runs": [],
    }
    if args.mode == "validation":
        for mechanism in args.mechanisms:
            for variant in args.variants:
                for seed in args.seeds:
                    result = validation_run(seed, variant, mechanism, directory)
                    results["runs"].append(result)
                    results["checks"] = panel_checks(results["runs"])
                    args.output.write_text(json.dumps(results, indent=2) + "\n")
                    print(
                        json.dumps(
                            {
                                "seed": seed,
                                "variant": variant,
                                "mechanism": mechanism,
                                "ARI": result["validation"]["adjusted_rand"],
                                "nRMSE": result["validation"]["normalized_rmse"],
                                "extra_wall_seconds": result["extra_intervention_wall_seconds"],
                            }
                        ),
                        flush=True,
                    )
    else:
        if args.validation_input is None:
            raise ValueError("heldout requires --validation-input")
        validated = json.loads(args.validation_input.read_text())
        assert validated["provenance"] == fingerprints()
        assert all(panel_checks(validated["runs"]).values()), (
            "frozen three-seed validation panel did not meet all gates"
        )
        for run in validated["runs"]:
            if run["mechanism"] != "predictive":
                continue
            results["runs"].append(heldout_run(run))
            args.output.write_text(json.dumps(results, indent=2) + "\n")
            print(json.dumps(results["runs"][-1]), flush=True)


if __name__ == "__main__":
    main()
