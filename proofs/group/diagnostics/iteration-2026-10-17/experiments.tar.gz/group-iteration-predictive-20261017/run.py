"""Proof-local predictive grouping references and frozen-neural reassignment.

No production source is patched. Candidate K is selected from validation data;
test data and generating partitions are consulted only after selection.
"""

# ruff: noqa: E402

import argparse
import importlib.util
import json
import math
import os
import sys
import time
from functools import partial
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
WORK = Path(__file__).resolve().parent
PROOFS = Path("/Users/grantham/Desktop/docs-0.3.3/proofs")
sys.path.insert(0, str(PROOFS))
sys.path.insert(0, str(WORK / "snapshot" / "src"))

import lightning.pytorch as lit
import numpy as np
import pyarrow as pa
import torch

import relflow as rf

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
spec = importlib.util.spec_from_file_location("p078_reference_source", WORK / "regime_recovery_source.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)


def truth(seed, variant):
    if variant == "imbalanced":
        return np.random.default_rng(seed * 100).permutation(np.repeat(np.arange(4), [40, 12, 8, 4]))
    return proof.partition(seed * 100)


def records(seed, split, variant):
    rows = {"train": 4096, "validate": 1024, "test": 2048}[split]
    data_seed = seed * 100 + {"train": 1, "validate": 2, "test": 3}[split]
    if variant in ("stable", "no_regime"):
        return list(
            proof.records(rows=rows, seed=data_seed, partition_seed=seed * 100, no_regime=variant == "no_regime")
        )
    rng = np.random.default_rng(data_seed)
    entities = np.resize(np.arange(64), rows)
    rng.shuffle(entities)
    groups = truth(seed, variant)[entities]
    x = rng.uniform(-1, 1, rows)
    intercepts, slopes = proof.INTERCEPTS, proof.SLOPES
    if variant == "crossing":
        intercepts, slopes = np.zeros(4), np.asarray([-6.0, -2.0, 2.0, 6.0])
    y = intercepts[groups] + slopes[groups] * x + rng.normal(0, 0.1, rows)
    return [{"entity": f"entity-{i:04d}", "x": float(a), "y": float(b)} for i, a, b in zip(entities, x, y, strict=True)]


def arrays(rows):
    return (
        np.asarray([int(row["entity"].split("-")[-1]) for row in rows]),
        np.asarray([row["x"] for row in rows]),
        np.asarray([row["y"] for row in rows]),
    )


def sufficient(rows):
    entity, x, y = arrays(rows)
    return np.stack(
        [np.bincount(entity, weights=value, minlength=64) for value in (np.ones_like(x), x, x * x, y, x * y, y * y)],
        axis=1,
    )


def regress(statistics):
    n, sx, sx2, sy, sxy, _ = np.moveaxis(statistics, -1, 0)
    denominator = (n * sx2 - sx * sx).clip(1e-12)
    slope = (n * sxy - sx * sy) / denominator
    return np.stack([(sy - slope * sx) / n.clip(1), slope], axis=-1)


def distortion(statistics, parameters):
    n, sx, sx2, sy, sxy, sy2 = statistics.T
    a, b = parameters.T
    return (
        sy2[:, None]
        - 2 * sy[:, None] * a
        - 2 * sxy[:, None] * b
        + n[:, None] * a * a
        + 2 * sx[:, None] * a * b
        + sx2[:, None] * b * b
    ).clip(0)


def fit_grouped(statistics, k, seed):
    """Alternate pooled response-curve fits and per-identity residual assignments."""
    started = time.perf_counter()
    individual = regress(statistics)
    scale = np.asarray([1.0, math.sqrt(statistics[:, 2].sum() / statistics[:, 0].sum())])
    profiles = individual * scale
    best = None
    total_iterations = 0
    for restart in range(10):
        rng = np.random.default_rng(seed + 1009 * k + restart)
        chosen = [int(rng.integers(len(profiles)))]
        for _ in range(1, k):
            distances = ((profiles[:, None] - profiles[chosen]) ** 2).sum(-1).min(-1)
            distances[chosen] = 0
            chosen.append(int(rng.choice(len(profiles), p=distances / distances.sum())))
        assignments = ((profiles[:, None] - profiles[chosen]) ** 2).sum(-1).argmin(-1)
        for iteration in range(50):
            pooled = np.stack([statistics[assignments == g].sum(0) for g in range(k)])
            parameters = regress(pooled)
            errors = distortion(statistics, parameters)
            updated = errors.argmin(-1)
            for empty in set(range(k)) - set(updated.tolist()):
                counts = np.bincount(updated, minlength=k)
                eligible = counts[updated] > 1
                candidate = np.where(eligible, errors[np.arange(64), updated], -np.inf).argmax()
                updated[candidate] = empty
            total_iterations += 1
            if np.array_equal(updated, assignments):
                break
            assignments = updated
        parameters = regress(np.stack([statistics[assignments == g].sum(0) for g in range(k)]))
        objective = float(distortion(statistics, parameters)[np.arange(64), assignments].sum())
        if best is None or objective < best["train_sse"]:
            best = {
                "k": k,
                "assignments": assignments,
                "parameters": parameters,
                "train_sse": objective,
                "restart": restart,
            }
    best.update(fit_seconds=time.perf_counter() - started, total_iterations=total_iterations, restarts=10)
    return best


def regression_predict(fitted, rows):
    entity, x, _ = arrays(rows)
    parameters = fitted["parameters"][fitted["assignments"][entity]]
    return parameters[:, 0] + parameters[:, 1] * x


def metrics(predicted, rows, training_mean, assignments, expected):
    target = arrays(rows)[2]
    rmse = float(np.mean((predicted - target) ** 2) ** 0.5)
    baseline = float(np.mean((training_mean - target) ** 2) ** 0.5)
    return {
        "rmse": rmse,
        "baseline_rmse": baseline,
        "normalized_rmse": rmse / baseline,
        "adjusted_rand": proof.adjusted_rand(expected, assignments),
        "occupied_groups": len(set(assignments.tolist())),
        "assignments": assignments.tolist(),
    }


def shuffled(rows, seed):
    entity = np.asarray([row["entity"] for row in rows])
    entity = entity[np.random.default_rng(seed).permutation(len(entity))]
    return [{**row, "entity": str(value)} for row, value in zip(rows, entity, strict=True)]


def shuffled_evaluation(seed, variant):
    if variant == "stable":
        return records(seed, "test", "no_regime")
    return shuffled(records(seed, "test", variant), seed * 100 + 4)


def reference(seed, variant):
    started = time.perf_counter()
    train, validate = records(seed, "train", variant), records(seed, "validate", variant)
    statistics = sufficient(train)
    individual = regress(statistics)
    individual_sse = distortion(statistics, individual)[np.arange(64), np.arange(64)].sum()
    noise = float(individual_sse / (len(train) - 2 * len(statistics)))
    candidates, selection_seconds = [], 0
    for k in range(2, 9):
        fitted = fit_grouped(statistics, k, seed)
        tick = time.perf_counter()
        validation_mse = float(np.mean((regression_predict(fitted, validate) - arrays(validate)[2]) ** 2))
        # Fixed before evaluating tests: regression parameter code + entity assignment code.
        penalty = noise * (2 * k * math.log(len(train)) + 2 * len(statistics) * math.log(k)) / len(train)
        fitted.update(
            validation_mse=validation_mse, complexity_penalty=penalty, selection_score=validation_mse + penalty
        )
        selection_seconds += time.perf_counter() - tick
        candidates.append(fitted)
    selected = min(candidates, key=lambda candidate: (candidate["selection_score"], candidate["k"]))
    test = records(seed, "test", variant)
    training_mean = float(arrays(train)[2].mean())
    result = metrics(
        regression_predict(selected, test), test, training_mean, selected["assignments"], truth(seed, variant)
    )
    shuffled_test = shuffled_evaluation(seed, variant)
    shuffled_metrics = metrics(
        regression_predict(selected, shuffled_test),
        shuffled_test,
        training_mean,
        selected["assignments"],
        truth(seed, variant),
    )
    candidates_json = [
        {key: value for key, value in candidate.items() if key not in ("assignments", "parameters")}
        for candidate in candidates
    ]
    return {
        "seed": seed,
        "variant": variant,
        "selected_k": selected["k"],
        "noise_estimate_from_training_individual_residuals": noise,
        "selection_rule": "validation MSE + training noise variance * (2*K*log(n_train) + 2*n_entities*log(K))/n_train; candidate K=2..8; 10 training-only restarts",
        "candidates": candidates_json,
        "selected_parameters": selected["parameters"].tolist(),
        "test": result,
        "shuffled": shuffled_metrics,
        "wall_seconds": time.perf_counter() - started,
        "selection_evaluation_seconds": selection_seconds,
        "fit_count": 70,
        "total_alternating_iterations": sum(candidate["total_iterations"] for candidate in candidates),
    }


def neural_predict(model, rows):
    visible = pa.Table.from_pylist([{"entity": row["entity"], "x": row["x"]} for row in rows])
    original_batch_size = model.batch_size
    try:
        output = model.predict(visible, batch_size=256)["predictions"].combine_chunks().field("y").field("content")
    finally:
        model.batch_size = original_batch_size
    return output.to_numpy(zero_copy_only=False)


def reassign(model, train, validate, optimizers):
    """Choose entity membership by pooled conditional prediction error, holding other weights fixed."""
    event_started = time.perf_counter()
    embedder = model.nodes["/entity"].embedder
    vocabulary = list(rf.Group.vocabulary(model, "/entity"))
    weight = embedder.embeddings["group"].weight
    before = weight.detach().clone()
    entity_order = np.asarray([int(value.split("-")[-1]) for value in vocabulary])
    available = (~embedder.retired).nonzero(as_tuple=True)[0].tolist()
    validation_target = arrays(validate)[2]
    before_validation_mse = float(np.mean((neural_predict(model, validate) - validation_target) ** 2))
    train_entity, _, train_target = arrays(train)
    errors = np.full((64, embedder.size), np.inf)
    row_mass = before[: len(vocabulary)].logsumexp(-1, keepdim=True)
    started = time.perf_counter()
    try:
        for group_id in available:
            forced = torch.full_like(before[: len(vocabulary)], math.log(1e-8))
            forced[:, group_id] = 0
            with torch.no_grad():
                weight[: len(vocabulary)].copy_(row_mass + forced)
            predicted = neural_predict(model, train)
            errors[:, group_id] = np.bincount(train_entity, weights=(predicted - train_target) ** 2, minlength=64)
    finally:
        with torch.no_grad():
            weight.copy_(before)
    seconds = time.perf_counter() - started
    proposed = errors.argmin(-1)
    forced = torch.full_like(before[: len(vocabulary)], math.log(1e-8))
    forced[torch.arange(len(vocabulary)), torch.as_tensor(proposed[entity_order])] = 0
    with torch.no_grad():
        weight[: len(vocabulary)].copy_(row_mass + forced)
    after_validation_mse = float(np.mean((neural_predict(model, validate) - validation_target) ** 2))
    accepted = after_validation_mse < before_validation_mse
    if accepted:
        if weight.grad is not None:
            weight.grad[: len(vocabulary)].zero_()
        for optimizer in optimizers:
            for value in optimizer.state.get(weight, {}).values():
                if isinstance(value, torch.Tensor) and value.shape == weight.shape:
                    value[: len(vocabulary)].zero_()
    else:
        with torch.no_grad():
            weight.copy_(before)
    return {
        "event_wall_seconds": time.perf_counter() - event_started,
        "counterfactual_seconds": seconds,
        "counterfactual_training_rows_evaluated": len(train) * len(available),
        "selection_validation_rows_evaluated": len(validate) * 2,
        "candidate_groups": available,
        "before_validation_mse": before_validation_mse,
        "proposed_validation_mse": after_validation_mse,
        "accepted_by_validation": accepted,
        "proposed_assignments": proposed.tolist(),
    }


class Reassignment(lit.Callback):
    def __init__(self, train, validate, freeze):
        self.train_rows, self.validation_rows, self.freeze = train, validate, freeze
        self.events = []

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        step = trainer.global_step
        if step not in (200, 400) or any(event["step"] == step for event in self.events):
            return
        result = reassign(pl_module, self.train_rows, self.validation_rows, trainer.optimizers)
        result["step"] = step
        if step == 400 and self.freeze:
            pl_module.nodes["/entity"].embedder.embeddings["group"].weight.requires_grad_(False)
            result["assignments_frozen_after_event"] = True
        self.events.append(result)
        print(json.dumps({"event": "reassignment", **result}), flush=True)


def neural(seed, variant, schedule):
    """Train for exactly 600 updates. All selection and reporting are validation-only."""
    lit.seed_everything(seed, workers=True)
    model = proof.build()
    train, validate = records(seed, "train", variant), records(seed, "validate", variant)
    data = rf.SyntheticDataModule(model=model, train=partial(iter, train), validate=partial(iter, validate), seed=seed)
    callback = Reassignment(train, validate, freeze=schedule == "alternating_freeze")
    trainer = lit.Trainer(
        accelerator="cpu",
        devices=1,
        max_steps=600,
        max_epochs=-1,
        logger=False,
        enable_checkpointing=False,
        enable_progress_bar=False,
        enable_model_summary=False,
        deterministic=True,
        num_sanity_val_steps=0,
        callbacks=[callback] if schedule != "posthoc" else [],
    )
    started = time.perf_counter()
    trainer.fit(model, datamodule=data)
    training_seconds = time.perf_counter() - started
    model.eval()
    if schedule == "posthoc":
        callback.events.append({"step": 600, **reassign(model, train, validate, trainer.optimizers)})
    assignments = rf.Group.assignments(model, "/entity")
    selected_assignments = np.asarray([assignments[f"entity-{i:04d}"]["group"] for i in range(64)])
    training_mean = float(arrays(train)[2].mean())
    result = metrics(
        neural_predict(model, validate), validate, training_mean, selected_assignments, truth(seed, variant)
    )
    validation_shuffled = shuffled(validate, seed * 100 + 4)
    shuffled_metrics = metrics(
        neural_predict(model, validation_shuffled),
        validation_shuffled,
        training_mean,
        selected_assignments,
        truth(seed, variant),
    )
    model.save(WORK / f"neural-{schedule}-{variant}-{seed}.ckpt")
    return {
        "seed": seed,
        "variant": variant,
        "optimizer_updates": trainer.global_step,
        "training_seconds": training_seconds,
        "training_seconds_include_interventions": schedule != "posthoc",
        "schedule": schedule,
        "events": callback.events,
        "counterfactual_seconds": sum(event["counterfactual_seconds"] for event in callback.events),
        "counterfactual_training_rows_evaluated": sum(
            event["counterfactual_training_rows_evaluated"] for event in callback.events
        ),
        "status": rf.Group.status(model, "/entity"),
        "validation": result,
        "shuffled_validation": shuffled_metrics,
        "scope": "Validation-only, proof-local scalar-y MSE intervention. No test rows loaded. Original model, optimizer, masks and 600 update budget; replaced assignment-row moments cleared, scalar AdamW step preserved. No generic runtime API or automatic K-selection claim.",
    }


def refine(seed, variant):
    """One final accepted reassignment on saved 600-update checkpoints; no training or test visits."""
    base_path = WORK / "neural-alternating-validation.json"
    source = next(
        run for run in json.loads(base_path.read_text())["runs"] if run["seed"] == seed and run["variant"] == variant
    )
    model = rf.Model.load(WORK / f"neural-alternating-{variant}-{seed}.ckpt")
    model.eval()
    train, validate = records(seed, "train", variant), records(seed, "validate", variant)
    result = reassign(model, train, validate, [])
    assignment_rows = rf.Group.assignments(model, "/entity")
    assignments = np.asarray([assignment_rows[f"entity-{i:04d}"]["group"] for i in range(64)])
    training_mean = float(arrays(train)[2].mean())
    selected = metrics(neural_predict(model, validate), validate, training_mean, assignments, truth(seed, variant))
    corrupted = shuffled(validate, seed * 100 + 4)
    corrupted_metrics = metrics(
        neural_predict(model, corrupted), corrupted, training_mean, assignments, truth(seed, variant)
    )
    checkpoint = WORK / f"neural-alternating-final-{variant}-{seed}.ckpt"
    model.save(checkpoint)
    return {
        "seed": seed,
        "variant": variant,
        "optimizer_updates": 600,
        "source_validation_run": str(base_path),
        "source_validation": source["validation"],
        "events": [*source["events"], {"step": 600, **result}],
        "validation": selected,
        "shuffled_validation": corrupted_metrics,
        "checkpoint": str(checkpoint),
        "scope": "Final validation-accepted reassignment, with no further optimizer updates and no held-out test rows loaded.",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["reference", "neural", "refine"])
    parser.add_argument("--schedule", choices=["posthoc", "alternating", "alternating_freeze"], default="alternating")
    parser.add_argument("--seeds", nargs="+", type=int, default=[7801, 7802, 7803])
    parser.add_argument(
        "--variants",
        nargs="+",
        choices=["stable", "no_regime", "imbalanced", "crossing"],
        default=["stable", "no_regime", "imbalanced", "crossing"],
    )
    args = parser.parse_args()
    path = (
        WORK
        / {
            "reference": "reference-results.json",
            "neural": f"neural-{args.schedule}-validation.json",
            "refine": "neural-alternating-final-validation.json",
        }[args.mode]
    )
    results = (
        json.loads(path.read_text())
        if path.exists()
        else {"manifest": json.loads((WORK / "manifest.json").read_text()), "runs": []}
    )
    for variant in args.variants:
        for seed in args.seeds:
            if any(run["seed"] == seed and run["variant"] == variant for run in results["runs"]):
                continue
            if args.mode == "reference":
                result = reference(seed, variant)
            elif args.mode == "refine":
                result = refine(seed, variant)
            else:
                result = neural(seed, variant, args.schedule)
            results["runs"].append(result)
            path.write_text(json.dumps(results, indent=2) + "\n")
            print(
                json.dumps(
                    {
                        key: value
                        for key, value in result.items()
                        if key
                        in (
                            "seed",
                            "variant",
                            "selected_k",
                            "wall_seconds",
                            "training_seconds",
                            "counterfactual_seconds",
                            "accepted_by_validation",
                            "before_validation_mse",
                            "proposed_validation_mse",
                            "test",
                            "validation",
                        )
                    }
                ),
                flush=True,
            )


if __name__ == "__main__":
    main()
