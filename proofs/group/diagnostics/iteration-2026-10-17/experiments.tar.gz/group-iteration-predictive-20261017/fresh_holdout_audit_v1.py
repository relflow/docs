"""Fresh known-identity rows after freezing the predictive EM configuration."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("predictive_em_v1", WORK / "predictive_em_v1.py")
experiment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(experiment)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    validation = json.loads((WORK / "final-validation.json").read_text())
    assert validation["provenance"] == experiment.fingerprints()
    assert all(experiment.panel_checks(validation["runs"]).values())
    output = {
        "audit_harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "parent_provenance": experiment.fingerprints(),
        "scope": "Additional independent 2048-row samples for the same 64 known identities. Data seed seed*100+10003, partition seed seed*100. No training, tuning, checkpoint selection or production source changes. This is a fresh holdout audit, separate from the canonical proof test.",
        "earlier_test_visits": {
            "7801": "An earlier posthoc pilot visited canonical test rows. Subsequent method choices used validation only.",
            "7802": "First canonical test visit used frozen v1 method.",
            "7803": "First canonical test visit used frozen v1 method.",
        },
        "runs": [],
    }
    for run in validation["runs"]:
        path = WORK / run["checkpoint"]
        assert experiment.digest(path) == run["checkpoint_sha256"]
        model = experiment.rf.Model.load(path)
        model.eval()
        seed, variant = run["seed"], run["variant"]
        options = {"rows": 2048, "seed": seed * 100 + 10003, "partition_seed": seed * 100}
        rows = list(experiment.proof.records(**options, no_regime=variant == "no_regime"))
        training_mean = float(experiment.arrays(experiment.records(seed, "train", variant))[2].mean())
        assignments = experiment.rf.Group.assignments(model, "/entity")
        membership = experiment.np.asarray([assignments[f"entity-{i:04d}"]["group"] for i in range(64)])
        saved = {name: value.detach().clone() for name, value in (*model.named_parameters(), *model.named_buffers())}
        measured = experiment.metrics(
            experiment.neural_predict(model, rows), rows, training_mean, membership, experiment.truth(seed, variant)
        )
        result = {
            "seed": seed,
            "variant": variant,
            "data_seed": options["seed"],
            "rows": 2048,
            "checkpoint_sha256": run["checkpoint_sha256"],
            "audit": measured,
        }
        if variant == "stable":
            corrupted = list(experiment.proof.records(**options, no_regime=True))
            result["shuffled"] = experiment.metrics(
                experiment.neural_predict(model, corrupted),
                corrupted,
                training_mean,
                membership,
                experiment.truth(seed, variant),
            )
        assert experiment.rf.Group.assignments(model, "/entity") == assignments
        assert all(
            experiment.torch.equal(value, saved[name])
            for name, value in (*model.named_parameters(), *model.named_buffers())
        )
        result["evaluation_preserves_parameters_buffers_and_assignments"] = True
        output["runs"].append(result)
        args.output.write_text(json.dumps(output, indent=2) + "\n")
        print(seed, variant, measured["adjusted_rand"], measured["normalized_rmse"], flush=True)


if __name__ == "__main__":
    main()
