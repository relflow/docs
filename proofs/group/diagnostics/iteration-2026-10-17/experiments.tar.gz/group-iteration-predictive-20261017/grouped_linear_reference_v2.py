"""Proof-local predictive grouping references and frozen-neural reassignment.

No production source is patched. Candidate K is selected from validation data;
test data and generating partitions are consulted only after selection.
"""

# ruff: noqa: E402

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
WORK = Path(__file__).resolve().parent
PROOFS = WORK / "proofs"
sys.path.insert(0, str(PROOFS))
sys.path.insert(0, str(WORK / "snapshot" / "src"))

import numpy as np
import torch

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
spec = importlib.util.spec_from_file_location("p078_reference_source", WORK / "regime_recovery_source.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)


def truth(seed, variant):
    if variant == "imbalanced":
        return np.random.default_rng(seed * 100).permutation(np.repeat(np.arange(4), [40, 12, 8, 4]))
    return proof.partition(seed * 100)


def records(seed, split, variant):
    rows = {"train": 4096, "validate": 1024, "test": 2048}[split]
    data_seed = seed * 100 + {"train": 1, "validate": 2, "test": 3}[split]
    if variant in ("stable", "no_regime"):
        return list(
            proof.records(rows=rows, seed=data_seed, partition_seed=seed * 100, no_regime=variant == "no_regime")
        )
    rng = np.random.default_rng(data_seed)
    entities = np.resize(np.arange(64), rows)
    rng.shuffle(entities)
    groups = truth(seed, variant)[entities]
    x = rng.uniform(-1, 1, rows)
    intercepts, slopes = proof.INTERCEPTS, proof.SLOPES
    if variant == "crossing":
        intercepts, slopes = np.zeros(4), np.asarray([-6.0, -2.0, 2.0, 6.0])
    y = intercepts[groups] + slopes[groups] * x + rng.normal(0, 0.1, rows)
    return [{"entity": f"entity-{i:04d}", "x": float(a), "y": float(b)} for i, a, b in zip(entities, x, y, strict=True)]


def arrays(rows):
    return (
        np.asarray([int(row["entity"].split("-")[-1]) for row in rows]),
        np.asarray([row["x"] for row in rows]),
        np.asarray([row["y"] for row in rows]),
    )


def sufficient(rows):
    entity, x, y = arrays(rows)
    return np.stack(
        [np.bincount(entity, weights=value, minlength=64) for value in (np.ones_like(x), x, x * x, y, x * y, y * y)],
        axis=1,
    )


def regress(statistics):
    n, sx, sx2, sy, sxy, _ = np.moveaxis(statistics, -1, 0)
    denominator = (n * sx2 - sx * sx).clip(1e-12)
    slope = (n * sxy - sx * sy) / denominator
    return np.stack([(sy - slope * sx) / n.clip(1), slope], axis=-1)


def distortion(statistics, parameters):
    n, sx, sx2, sy, sxy, sy2 = statistics.T
    a, b = parameters.T
    return (
        sy2[:, None]
        - 2 * sy[:, None] * a
        - 2 * sxy[:, None] * b
        + n[:, None] * a * a
        + 2 * sx[:, None] * a * b
        + sx2[:, None] * b * b
    ).clip(0)


def fit_grouped(statistics, k, seed):
    """Alternate pooled response-curve fits and per-identity residual assignments."""
    started = time.perf_counter()
    individual = regress(statistics)
    scale = np.asarray([1.0, math.sqrt(statistics[:, 2].sum() / statistics[:, 0].sum())])
    profiles = individual * scale
    best = None
    total_iterations = 0
    for restart in range(10):
        rng = np.random.default_rng(seed + 1009 * k + restart)
        chosen = [int(rng.integers(len(profiles)))]
        for _ in range(1, k):
            distances = ((profiles[:, None] - profiles[chosen]) ** 2).sum(-1).min(-1)
            distances[chosen] = 0
            chosen.append(int(rng.choice(len(profiles), p=distances / distances.sum())))
        assignments = ((profiles[:, None] - profiles[chosen]) ** 2).sum(-1).argmin(-1)
        for iteration in range(50):
            pooled = np.stack([statistics[assignments == g].sum(0) for g in range(k)])
            parameters = regress(pooled)
            errors = distortion(statistics, parameters)
            updated = errors.argmin(-1)
            for empty in set(range(k)) - set(updated.tolist()):
                counts = np.bincount(updated, minlength=k)
                eligible = counts[updated] > 1
                candidate = np.where(eligible, errors[np.arange(64), updated], -np.inf).argmax()
                updated[candidate] = empty
            total_iterations += 1
            if np.array_equal(updated, assignments):
                break
            assignments = updated
        parameters = regress(np.stack([statistics[assignments == g].sum(0) for g in range(k)]))
        objective = float(distortion(statistics, parameters)[np.arange(64), assignments].sum())
        if best is None or objective < best["train_sse"]:
            best = {
                "k": k,
                "assignments": assignments,
                "parameters": parameters,
                "train_sse": objective,
                "restart": restart,
            }
    best.update(fit_seconds=time.perf_counter() - started, total_iterations=total_iterations, restarts=10)
    return best


def regression_predict(fitted, rows):
    entity, x, _ = arrays(rows)
    parameters = fitted["parameters"][fitted["assignments"][entity]]
    return parameters[:, 0] + parameters[:, 1] * x


def metrics(predicted, rows, training_mean, assignments, expected):
    target = arrays(rows)[2]
    rmse = float(np.mean((predicted - target) ** 2) ** 0.5)
    baseline = float(np.mean((training_mean - target) ** 2) ** 0.5)
    return {
        "rmse": rmse,
        "baseline_rmse": baseline,
        "normalized_rmse": rmse / baseline,
        "adjusted_rand": proof.adjusted_rand(expected, assignments),
        "occupied_groups": len(set(assignments.tolist())),
        "assignments": assignments.tolist(),
    }


def shuffled(rows, seed):
    entity = np.asarray([row["entity"] for row in rows])
    entity = entity[np.random.default_rng(seed).permutation(len(entity))]
    return [{**row, "entity": str(value)} for row, value in zip(rows, entity, strict=True)]


def shuffled_evaluation(seed, variant):
    if variant == "stable":
        return records(seed, "test", "no_regime")
    return shuffled(records(seed, "test", variant), seed * 100 + 4)


def reference(seed, variant):
    started = time.perf_counter()
    train, validate = records(seed, "train", variant), records(seed, "validate", variant)
    statistics = sufficient(train)
    individual = regress(statistics)
    individual_sse = distortion(statistics, individual)[np.arange(64), np.arange(64)].sum()
    noise = float(individual_sse / (len(train) - 2 * len(statistics)))
    candidates, selection_seconds = [], 0
    for k in range(2, 9):
        fitted = fit_grouped(statistics, k, seed)
        tick = time.perf_counter()
        validation_mse = float(np.mean((regression_predict(fitted, validate) - arrays(validate)[2]) ** 2))
        # Fixed before evaluating tests: regression parameter code + entity assignment code.
        penalty = noise * (2 * k * math.log(len(train)) + 2 * len(statistics) * math.log(k)) / len(train)
        fitted.update(
            validation_mse=validation_mse, complexity_penalty=penalty, selection_score=validation_mse + penalty
        )
        selection_seconds += time.perf_counter() - tick
        candidates.append(fitted)
    selected = min(candidates, key=lambda candidate: (candidate["selection_score"], candidate["k"]))
    test = records(seed, "test", variant)
    training_mean = float(arrays(train)[2].mean())
    result = metrics(
        regression_predict(selected, test), test, training_mean, selected["assignments"], truth(seed, variant)
    )
    shuffled_test = shuffled_evaluation(seed, variant)
    shuffled_metrics = metrics(
        regression_predict(selected, shuffled_test),
        shuffled_test,
        training_mean,
        selected["assignments"],
        truth(seed, variant),
    )
    candidates_json = [
        {key: value for key, value in candidate.items() if key not in ("assignments", "parameters")}
        for candidate in candidates
    ]
    return {
        "seed": seed,
        "variant": variant,
        "selected_k": selected["k"],
        "noise_estimate_from_training_individual_residuals": noise,
        "selection_rule": "validation MSE + training noise variance * (2*K*log(n_train) + 2*n_entities*log(K))/n_train; candidate K=2..8; 10 training-only restarts",
        "candidates": candidates_json,
        "selected_parameters": selected["parameters"].tolist(),
        "test": result,
        "shuffled": shuffled_metrics,
        "wall_seconds": time.perf_counter() - started,
        "selection_evaluation_seconds": selection_seconds,
        "fit_count": 70,
        "total_alternating_iterations": sum(candidate["total_iterations"] for candidate in candidates),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    fingerprint = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    output = {"harness_sha256": fingerprint, "manifest": json.loads((WORK / "manifest.json").read_text()), "runs": []}
    for variant in ("stable", "no_regime", "imbalanced", "crossing"):
        for seed in (7801, 7802, 7803):
            result = reference(seed, variant)
            result["harness_sha256"] = fingerprint
            output["runs"].append(result)
            args.output.write_text(json.dumps(output, indent=2) + "\n")
            print(
                seed,
                variant,
                result["selected_k"],
                result["test"]["adjusted_rand"],
                result["test"]["normalized_rmse"],
                flush=True,
            )


if __name__ == "__main__":
    main()
