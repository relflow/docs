"""Bounded small-initialization combinations after the isolated standard-init panel."""

from dataclasses import asdict
import json
from pathlib import Path
import traceback

from run import Arm, ROOT, append, run_p078


output = ROOT / "small-combinations.json"
for arm in (
    Arm("small_st_detach", deterministic=True, detach=True, scale=0.1),
    Arm("small_st_membership", deterministic=True, membership=True, scale=0.1),
    Arm("small_st_membership_detach", deterministic=True, membership=True, detach=True, scale=0.1),
):
    result = {"task": "p078", "arm": asdict(arm), "seed": 7801}
    print("START", arm.name, flush=True)
    try:
        measured = run_p078(arm, 7801)
        result.update(outcome="completed", metrics=measured)
    except Exception:
        result.update(outcome="error", error=traceback.format_exc())
    append(output, result)
    if result["outcome"] == "completed":
        brief = {key: measured["stable"][key] for key in ("adjusted_rand", "normalized_rmse", "occupied_groups", "seconds")}
        print("RESULT", arm.name, json.dumps(brief), flush=True)
    else:
        print(result["error"], flush=True)
