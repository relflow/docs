"""Matched, validation-only Group ablations against an immutable source snapshot."""

from __future__ import annotations

import argparse
import ast
import contextlib
import hashlib
import importlib.metadata
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys
import textwrap
import time
import traceback
from dataclasses import asdict, dataclass
from functools import partial
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
sys.path.insert(0, str(ROOT / "snapshot/src"))
sys.path.insert(0, str(ROOT / "proofs"))

import lightning.pytorch as lit
import numpy as np
import torch

import relflow as rf
from relflow.tensorfields.extensions import group

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
MANIFEST = json.loads((ROOT / "manifest.json").read_text())
ORIGINAL_GUMBEL = torch.nn.functional.gumbel_softmax
ORIGINAL_REVIVE = group.GroupReviveCallback.on_train_epoch_end
ORIGINAL_LOSS = inspect.getsource(group.loss)


@dataclass(frozen=True)
class Arm:
    name: str
    deterministic: bool = False
    membership: bool = False
    detach: bool = False
    scale: float = 1.0


ARMS = {
    arm.name: arm
    for arm in (
        Arm("baseline"),
        Arm("deterministic_st", deterministic=True),
        Arm("membership", membership=True),
        Arm("detach", detach=True),
        Arm("st_membership", deterministic=True, membership=True),
        Arm("st_detach", deterministic=True, detach=True),
        Arm("membership_detach", membership=True, detach=True),
        Arm("st_membership_detach", deterministic=True, membership=True, detach=True),
        Arm("st_small", deterministic=True, scale=0.1),
    )
}


def load_proof(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / "proofs" / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


P078 = load_proof("ablation_p078", "group/regime_recovery.py")
P065 = load_proof("ablation_p065", "vocabulary/group_pretraining_coverage.py")


@contextlib.contextmanager
def random_stream(generator):
    """Keep routing/adaptation draws out of the common model/resource RNG."""
    shared = torch.get_rng_state()
    torch.set_rng_state(generator.get_state())
    try:
        yield
    finally:
        generator.set_state(torch.get_rng_state())
        torch.set_rng_state(shared)


def detached_scores(embedder, probabilities):
    weight = embedder.embeddings["group"].weight.detach()
    available = ~embedder.retired
    return probabilities[:, available].float() @ weight[: len(embedder.vocab.master), available].float().T


def compiled_loss(arm):
    source = ORIGINAL_LOSS
    if arm.membership:
        needle = "valued_probs = valued_logits.softmax(dim=-1)"
        replacement = """valued_probs = torch.nn.functional.one_hot(
        embedder.support(embedder.embeddings[TensorKey.group.name].weight[content_targets[known]]).argmax(dim=-1),
        num_classes=embedder.size,
    ).float()"""
        assert source.count(needle) == 1
        source = source.replace(needle, replacement)
    if arm.detach:
        needle = "vocab_logits = vocabulary_logits(embedder, group_probs)"
        assert source.count(needle) == 1
        source = source.replace(needle, "vocab_logits = detached_scores(embedder, group_probs)")
    tree = ast.parse(textwrap.dedent(source))
    tree.body[0].decorator_list = []
    namespace = {**vars(group), "detached_scores": detached_scores}
    exec(compile(ast.fix_missing_locations(tree), "<matched-group-ablation>", "exec"), namespace)
    return namespace["loss"], hashlib.sha256(source.encode()).hexdigest()


@contextlib.contextmanager
def changes(arm, seed):
    route = torch.Generator().manual_seed(seed + 1000003)
    adaptation = torch.Generator().manual_seed(seed + 2000003)

    def routing(logits, tau=1.0, hard=False, eps=1e-10, dim=-1):
        if arm.deterministic:
            probabilities = (logits / tau).softmax(dim=dim)
            if not hard:
                return probabilities
            selected = torch.zeros_like(probabilities).scatter_(dim, probabilities.argmax(dim=dim, keepdim=True), 1.0)
            return selected - probabilities.detach() + probabilities
        with random_stream(route):
            return ORIGINAL_GUMBEL(logits, tau=tau, hard=hard, eps=eps, dim=dim)

    def revive(callback, trainer, model):
        with random_stream(adaptation):
            return ORIGINAL_REVIVE(callback, trainer, model)

    loss, digest = compiled_loss(arm)
    with patch("torch.nn.functional.gumbel_softmax", routing), patch.object(
        group.GroupReviveCallback, "on_train_epoch_end", revive
    ), patch.dict(group.group.components, {rf.Component.loss: loss}):
        yield digest


def weights(model, *, shared=False):
    digest = hashlib.sha256()
    for name, value in model.named_parameters():
        if shared and ".embedder.embeddings.group.weight" in name:
            continue
        digest.update(name.encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


class Audit(lit.Callback):
    def __init__(self, address):
        self.address = address
        self.batches = hashlib.sha256()
        self.masks = hashlib.sha256()
        self.core_rng = hashlib.sha256()
        self.rows = []
        self.first_weights = None
        self.first_shared_weights = None
        self.scaled = False
        self.scale = 1.0

    def on_train_batch_start(self, trainer, model, batch, batch_idx):
        if not self.scaled and self.scale != 1.0:
            with torch.no_grad():
                model.nodes[self.address].embedder.embeddings["group"].weight.mul_(self.scale)
            self.scaled = True
        if self.first_weights is None:
            self.first_weights = weights(model)
            self.first_shared_weights = weights(model, shared=True)
        self.batches.update(json.dumps(batch.source.to_pylist(), sort_keys=True, separators=(",", ":")).encode())
        self.masks.update(batch.tensors[self.address].trainable.cpu().numpy().tobytes())
        self.core_rng.update(torch.get_rng_state().numpy().tobytes())
        if trainer.global_step % 100 == 0:
            embedder = model.nodes[self.address].embedder
            self.rows.append({
                "before_step": trainer.global_step,
                "committed": int(embedder.committed.sum()),
                "information": float(embedder.information_ema),
                "usage": embedder.usage_ema.detach().cpu().tolist(),
            })

    def result(self):
        return {
            "batches_sha256": self.batches.hexdigest(),
            "masks_sha256": self.masks.hexdigest(),
            "core_rng_sha256": self.core_rng.hexdigest(),
            "first_bound_weights_sha256": self.first_weights,
            "first_shared_weights_sha256": self.first_shared_weights,
            "trajectory": self.rows,
        }


def trainer(budget, audit):
    return lit.Trainer(
        accelerator="cpu", devices=1, max_steps=budget, max_epochs=-1,
        logger=False, enable_checkpointing=False, enable_progress_bar=False,
        enable_model_summary=False, deterministic=True, num_sanity_val_steps=0,
        callbacks=[audit],
    )


def run_p078(arm, seed=7801, *, controls=False, extra_context=contextlib.nullcontext):
    results = {}
    for name, no_regime in (("stable", False), ("no_regime", True)) if controls else (("stable", False),):
        lit.seed_everything(seed, workers=True)
        with changes(arm, seed) as loss_sha, extra_context():
            model = P078.build()
            initial = weights(model)
            options = {"partition_seed": seed * 100, "no_regime": no_regime}
            data = rf.SyntheticDataModule(
                model=model,
                train=partial(P078.records, rows=4096, seed=seed * 100 + 1, **options),
                validate=partial(P078.records, rows=1024, seed=seed * 100 + 2, **options), seed=seed,
            )
            audit = Audit("/entity")
            audit.scale = arm.scale
            loop = trainer(600, audit)
            # The shared initialization/resource RNG starts identically in every arm.
            torch.manual_seed(seed + 3000003)
            started = time.perf_counter()
            loop.fit(model, datamodule=data)
            elapsed = time.perf_counter() - started
            model.eval()
            before = rf.Group.assignments(model, "/entity")
            mean = float(np.mean([row["y"] for row in P078.records(rows=4096, seed=seed * 100 + 1, **options)]))
            rows = list(P078.records(rows=1024, seed=seed * 100 + 2, **options))
            measured = P078.measure(model, rows, mean, seed * 100)
            if name == "stable":
                shuffled = list(P078.records(rows=1024, seed=seed * 100 + 2, partition_seed=seed * 100, no_regime=True))
                measured["shuffled"] = P078.measure(model, shuffled, mean, seed * 100)
            assert before == rf.Group.assignments(model, "/entity")
            assert loop.global_step == 600
            results[name] = {
                **measured, "steps": loop.global_step, "seconds": elapsed,
                "initial_weights_sha256": initial, "loss_sha256": loss_sha,
                "evaluation_assignments_frozen": True, "audit": audit.result(),
            }
    return results


def run_p065(arm, seed=7651, *, extra_context=contextlib.nullcontext):
    lit.seed_everything(seed, workers=True)
    with changes(arm, seed) as loss_sha, extra_context():
        model = P065.build()
        initial = weights(model)
        data = rf.SyntheticDataModule(
            model=model,
            train=partial(P065.records, rows=8192, seed=seed + 1),
            validate=partial(P065.records, rows=1024, seed=seed + 2), seed=seed,
        )
        audit = Audit("/code")
        audit.scale = arm.scale
        loop = trainer(800, audit)
        torch.manual_seed(seed + 3000003)
        started = time.perf_counter()
        loop.fit(model, datamodule=data)
        elapsed = time.perf_counter() - started
        model.eval()
        original = list(P065.records(rows=1024, seed=seed + 2))
        vocabulary = rf.Group.vocabulary(model, "/code")
        counts = model.nodes["/code"].embedder.counters["content"].counts.detach().clone()
        coverage = {}
        for keep in (512, 256, 51, 0):
            selected = 0
            rows = []
            for row in original:
                rows.append({**row, "code": f"novel-{row['code']}" if row["hide"] and selected >= keep else row["code"]})
                selected += int(row["hide"])
            measured = P065.evaluate(loop, model, rows)
            assert measured["targets.known"] == keep
            assert measured["targets.unavailable"] == 512 - keep
            coverage[str(keep)] = {key: value if np.isfinite(value) else None for key, value in measured.items()}
        assert vocabulary == rf.Group.vocabulary(model, "/code")
        assert torch.equal(counts, model.nodes["/code"].embedder.counters["content"].counts)
        return {
            "steps": loop.global_step, "seconds": elapsed, "coverage": coverage,
            "initial_weights_sha256": initial, "loss_sha256": loss_sha,
            "evaluation_vocabulary_frozen": True, "audit": audit.result(),
        }


def provenance():
    return {
        **MANIFEST,
        "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": sys.version,
        "packages": {name: importlib.metadata.version(name) for name in ("torch", "lightning", "relflow", "pyarrow", "numpy")},
        "relflow_path": rf.__file__,
        "scope": "validation-only; official held-out test data not generated",
        "rng": "Shared resource RNG reset after model construction; Group Gumbel and revival each use separate saved/restored CPU generators; native Arrow masks/data use operation-isolated NumPy seeds.",
    }


def append(output, result):
    document = json.loads(output.read_text()) if output.exists() else {"provenance": provenance(), "runs": []}
    document["runs"].append(result)
    temporary = output.with_suffix(".pending.json")
    temporary.write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")
    temporary.replace(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=("p078", "p065"), default="p078")
    parser.add_argument("--arms", nargs="+", default=["baseline", "deterministic_st", "membership", "detach"])
    parser.add_argument("--seeds", nargs="+", type=int)
    parser.add_argument("--controls", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "results.json")
    options = parser.parse_args()
    for name in options.arms:
        arm = ARMS[name]
        for seed in options.seeds or ([7801] if options.task == "p078" else [7651]):
            result = {"task": options.task, "arm": asdict(arm), "seed": seed}
            print("START", options.task, name, seed, flush=True)
            try:
                measured = run_p078(arm, seed, controls=options.controls) if options.task == "p078" else run_p065(arm, seed)
                result.update(outcome="completed", metrics=measured)
            except Exception:
                result.update(outcome="error", error=traceback.format_exc())
            append(options.output, result)
            if result["outcome"] == "completed":
                brief = {k: measured["stable"][k] for k in ("adjusted_rand", "normalized_rmse", "occupied_groups", "seconds")} if options.task == "p078" else {k: v["accuracy.content"] for k, v in measured["coverage"].items()}
                print("RESULT", options.task, name, seed, json.dumps(brief), flush=True)
            else:
                print(result["error"], flush=True)


if __name__ == "__main__":
    main()
