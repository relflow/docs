# Matched Group mechanism ablations

These experiments use an immutable copy of the retained raw-score package,
source SHA-256 `4f900097c5f12eb6eef07e88b7abba5c61089f52696d52ee8c08d105894a5b58`.
`manifest.json` records every copied Python file and package base commit.
Production and documentation checkouts are not edited.

Only validation data guides selection. P078 uses the original generator,
4,096 training rows, 1,024 validation rows, batch 128, and 600 updates. Promoted
validation candidates also train the no-regime arm for 600 updates and evaluate
the original shuffled-ID control on validation records. No official 2,048-row
held-out test records are generated. P065 uses the original 8,192 training rows,
batch 64, and 800 updates; its 1,024-row validation set has 512 selected targets,
with 512 / 256 / 51 / 0 known-target coverage cases. This differs from the
canonical final test's 1,024 / 512 / 102 / 0 known targets.

## Isolation

All initial arms use the same full schema, including the Group reconstruction
head and original mask, optimizer, balancing loss, raw tied identity scorer,
and inference writer. Assignment initialization remains the native standard
normal distribution. The separate `st_small` arm scales the first bound
assignment table by 0.1 and is never described as an isolated routing change.
It retains the existing random initial ordering, not a balanced ID prior.

Model constructors start from the same seed. Immediately before fitting, the
common model/resource Torch RNG is reset to `seed + 3000003`. Group Gumbel
routing uses a separate CPU generator seeded with `seed + 1000003`; the entire
revival callback uses another seeded with `seed + 2000003`. Each saves and
restores the common Torch RNG. Original Arrow masking and data ordering already
use independent NumPy generators keyed by seed, epoch, address, or operation.

This creates a **matched protocol baseline**, rather than a bit-for-bit repeat
of the native proof CLI's original global RNG consumption. The baseline keeps
the same sampling distributions and model equations. Compare ablation scores
to this baseline, not directly to earlier native-CLI scores.

Each run records initial and first-bound parameter hashes, the ordered training
batch hash, Group training-mask hash, and common Torch RNG hash across all
steps. These must agree across the first four standard-initialization arms.
Later combinations must retain the same batch/mask/shared-weight hashes.

- `baseline`: native hard Gumbel routing, decoder-derived statistics, raw scores.
- `deterministic_st`: change only training routing to deterministic hard forward
  with a softmax straight-through gradient; inference stays hard.
- `membership`: change only pending usage statistics to current known identities'
  hard argmax memberships, with zero conditional entropy. Balancing remains on
  and still operates on decoder logits.
- `detach`: detach the tied identity matrix only inside reconstruction scoring;
  encoder gradients and balancing remain unchanged. Forward scores and the
  writer retain the original raw label priors.

Combinations explicitly name which of these interventions they combine. No
compression objective, teacher loss, normalization, or capacity prior is added.

## Reproduction and evidence

Use `/Users/grantham/Desktop/relflow/.venv/bin/python` with CPU threads fixed to
one by the harness. `run_initial_v1.py` preserves the exact first four-arm
harness; its byte hash matches `results.json`. `run.py` adds dynamic scorer
dispatch for separately recorded reconstruction research and more audit fields;
the default scorer equations remain unchanged. A second baseline checks this.

```bash
/Users/grantham/Desktop/relflow/.venv/bin/python run_initial_v1.py --task p078 --arms baseline deterministic_st membership detach --output reproduced-initial.json
/Users/grantham/Desktop/relflow/.venv/bin/python run.py --task p078 --arms baseline st_membership st_detach membership_detach st_membership_detach st_small --output reproduced-combinations.json
/Users/grantham/Desktop/relflow/.venv/bin/python run.py --task p078 --arms st_small --seeds 7801 7802 7803 --controls --output reproduced-small-panel.json
/Users/grantham/Desktop/relflow/.venv/bin/python run.py --task p065 --arms baseline st_small --seeds 7651 7652 7653 --output reproduced-coverage-panel.json
/Users/grantham/Desktop/relflow/.venv/bin/python followup.py
/Users/grantham/Desktop/relflow/.venv/bin/python panel.py p078
/Users/grantham/Desktop/relflow/.venv/bin/python panel.py p065
/Users/grantham/Desktop/relflow/.venv/bin/python run.py --task p078 --arms baseline --seeds 7802 7803 --output reproduced-paired-baselines.json
```

Every result, exception, wall time, intervention, and source/harness fingerprint
is retained in JSON. Three-seed panels run every declared seed, including after
a failure. A favorable validation result remains provisional until the complete
original controls and unchanged gates are checked after configuration freeze.
The P065 diagnostic records coverage counts and all-OOV behavior but does not
repeat the canonical low-coverage rebatching check. Its validation scores must
not be described as a complete canonical proof pass.
