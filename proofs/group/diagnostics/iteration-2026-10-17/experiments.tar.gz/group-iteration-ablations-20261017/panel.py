"""Complete all seeds of the final predictive ablation, without early filtering."""

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import traceback

from run import Arm, ROOT, append, run_p065, run_p078


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("task", choices=("p065", "p078"))
options = parser.parse_args()
arm = Arm("small_st_membership_detach", deterministic=True, membership=True, detach=True, scale=0.1)
output = ROOT / f"final-candidate-{options.task}.json"
driver_sha256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
for seed in (7651, 7652, 7653) if options.task == "p065" else (7801, 7802, 7803):
    result = {"task": options.task, "arm": asdict(arm), "seed": seed, "driver_sha256": driver_sha256}
    print("START", options.task, arm.name, seed, flush=True)
    try:
        measured = run_p065(arm, seed) if options.task == "p065" else run_p078(arm, seed, controls=True)
        result.update(outcome="completed", metrics=measured)
    except Exception:
        result.update(outcome="error", error=traceback.format_exc())
    append(output, result)
    if result["outcome"] == "completed":
        brief = {k: measured["stable"][k] for k in ("adjusted_rand", "normalized_rmse", "occupied_groups", "seconds")} if options.task == "p078" else {k: v["accuracy.content"] for k, v in measured["coverage"].items()}
        print("RESULT", options.task, arm.name, seed, json.dumps(brief), flush=True)
    else:
        print(result["error"], flush=True)
