"""Validate matching/provenance and summarize every retained experimental outcome."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FILES = (
    "results.json", "combinations.json", "candidate-p078.json", "candidate-p065.json",
    "small-combinations.json", "final-candidate-p078.json", "final-candidate-p065.json",
    "paired-baselines.json",
)


def gates(run):
    if run["outcome"] != "completed":
        return {"execution": False}
    measured = run["metrics"]
    if run["task"] == "p065":
        coverage = measured["coverage"]
        return {
            "known_accuracy_above_0.95": all(row["accuracy.content"] > 0.95 for key, row in coverage.items() if key != "0"),
            "frozen_vocabulary": measured["evaluation_vocabulary_frozen"],
            "oov_accuracy_undefined": coverage["0"]["accuracy.content"] is None,
            "oov_nll_undefined": coverage["0"]["nll.content"] is None,
            "oov_all_accuracy_zero": coverage["0"]["accuracy.all"] == 0,
        }
    stable = measured["stable"]
    checks = {
        "stable_ari_at_least_0.80": stable["adjusted_rand"] >= 0.8,
        "stable_nrmse_at_most_0.35": stable["normalized_rmse"] <= 0.35,
        "all64identities": stable["assigned_entities"] == 64,
        "evaluation_frozen": stable["evaluation_assignments_frozen"],
        "shuffled_nrmse_at_least_0.85": stable["shuffled"]["normalized_rmse"] >= 0.85,
        "shuffled_nrmse_increase_at_least_0.40": stable["shuffled"]["normalized_rmse"] - stable["normalized_rmse"] >= 0.4,
    }
    if "no_regime" in measured:
        control = measured["no_regime"]
        checks.update(
            no_regime_ari_at_most_0_15=control["adjusted_rand"] <= 0.15,
            no_regime_nrmse_at_least_0_85=control["normalized_rmse"] >= 0.85,
            control_all64identities=control["assigned_entities"] == 64,
            control_evaluation_frozen=control["evaluation_assignments_frozen"],
        )
    return checks


def main():
    manifest = json.loads((ROOT / "manifest.json").read_text())
    for name, digest in manifest["files"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    harness_hashes = {hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ("run.py", "run_initial_v1.py")}
    records = []
    audit_reference = {}
    for filename in FILES:
        document = json.loads((ROOT / filename).read_text())
        assert document["provenance"]["source_sha256"] == manifest["source_sha256"], filename
        assert document["provenance"]["harness_sha256"] in harness_hashes, filename
        for run in document["runs"]:
            checks = gates(run)
            entry = {
                "file": filename, "task": run["task"], "arm": run["arm"], "seed": run["seed"],
                "execution": run["outcome"], "checks": checks,
                "validation_gates_met": all(checks.values()),
            }
            if run["outcome"] != "completed":
                entry["error"] = run["error"]
                records.append(entry)
                continue
            measured = run["metrics"]
            stages = measured.items() if run["task"] == "p078" else (("main", measured),)
            for stage, detail in stages:
                audit = detail["audit"]
                key = (run["task"], run["seed"], stage)
                reference = audit_reference.setdefault(key, audit)
                for item in ("batches_sha256", "masks_sha256", "core_rng_sha256", "first_shared_weights_sha256"):
                    assert audit[item] == reference[item], (filename, run["arm"]["name"], key, item)
            if run["task"] == "p078":
                stable = measured["stable"]
                entry.update(
                    ari=stable["adjusted_rand"], nrmse=stable["normalized_rmse"],
                    occupied=stable["occupied_groups"], committed=len(stable["status"]["committed"]),
                    seconds=sum(stage["seconds"] for stage in measured.values()),
                    no_regime_included="no_regime" in measured,
                    shuffled_nrmse=stable["shuffled"]["normalized_rmse"],
                )
            else:
                entry.update(
                    known_accuracy={key: row["accuracy.content"] for key, row in measured["coverage"].items()},
                    seconds=measured["seconds"],
                )
            records.append(entry)
    summary = {
        "scope": "Validation-only mechanism research; original test records unused; no production change promoted",
        "source_sha256": manifest["source_sha256"],
        "matching": "For every matched task/seed/stage: batch, mask, common-RNG, and shared-parameter hashes agree across arms",
        "all_snapshot_files_intact": True,
        "experiments": len(records),
        "training_fits": sum(2 if r["task"] == "p078" and r.get("no_regime_included") else 1 for r in records),
        "records": records,
        "artifacts": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (*FILES, "run.py", "run_initial_v1.py", "followup.py", "panel.py", "PROTOCOL.md")},
    }
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    for entry in records:
        print(entry["task"], entry["arm"]["name"], entry["seed"],
              "met" if entry["validation_gates_met"] else "not_met",
              (entry.get("ari"), entry.get("nrmse")) if entry["task"] == "p078" else entry.get("known_accuracy"))
    print("VERIFIED", summary["experiments"], "experiments", summary["training_fits"], "fits")


if __name__ == "__main__":
    main()
