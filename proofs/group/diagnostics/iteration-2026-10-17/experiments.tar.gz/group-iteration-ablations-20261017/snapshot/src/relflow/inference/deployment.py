"""Realtime deployment over RelFlow's Arrow prediction boundary."""

from __future__ import annotations

import asyncio
import os
from collections.abc import Callable
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Self, TypeAlias, TypeVar, cast

import fastapi
import orjson
import pyarrow as pa
import pyarrow.ipc as ipc
import pydantic
import torch
import uvicorn
from beartype import beartype
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from relflow.architecture.root import Model
from relflow.architecture.runtime import metadata
from relflow.data.arrow import Retain, mappings, retention
from relflow.data.processors import Postprocessor, PostprocessorInput, Preprocessor, PreprocessorInput
from relflow.structs.experiment import NodeAttribute, NodePredicate
from relflow.structs.tree import Node

Input: TypeAlias = dict[str, Any]
ModelSource: TypeAlias = str | Path | Model
UpdateOperation: TypeAlias = tuple[tuple[NodePredicate | NodeAttribute | Callable[[Node], bool], ...], dict[str, Any]]
DeploymentType = TypeVar("DeploymentType", bound="Deployment")
JSON_MEDIA_TYPE = "application/json"
ARROW_MEDIA_TYPE = "application/vnd.apache.arrow.stream"


class Accelerator(StrEnum):
    """Select automatic device discovery, CPU, CUDA or Apple MPS for serving."""

    auto = "auto"
    cpu = "cpu"
    cuda = "cuda"
    mps = "mps"

    @classmethod
    def _missing_(cls, value: object) -> Accelerator | None:
        if not isinstance(value, str):
            return None

        normalized = value.strip().lower()
        if normalized == "":
            raise ValueError("accelerator must not be blank")
        return cast(Accelerator | None, cls._value2member_map_.get(normalized))


class JSONBackend(StrEnum):
    """Choose the optional fast JSON encoder or Python's standard JSON encoder."""

    orjson = "orjson"
    stdlib = "stdlib"

    @classmethod
    def _missing_(cls, value: object) -> JSONBackend | None:
        if not isinstance(value, str):
            return None

        normalized = value.strip().lower()
        if normalized == "":
            raise ValueError("json_backend must not be blank")
        return cast(JSONBackend | None, cls._value2member_map_.get(normalized))


class ErrorItem(pydantic.BaseModel):
    """One request-local validation error."""

    status_code: int
    message: str


class FastAPIRuntime:
    """Load one model and predict Arrow inputs for HTTP requests."""

    def __init__(
        self,
        *,
        checkpoint: ModelSource,
        accelerator: Accelerator,
        preprocessor: PreprocessorInput = (),
        postprocessor: PostprocessorInput = (),
        retain: Retain = (),
        update_operations: list[UpdateOperation] | None = None,
        request_signature: type[pydantic.BaseModel] | None = None,
        response_signature: type[pydantic.BaseModel] | None = None,
    ) -> None:
        self.model_source = checkpoint
        self.accelerator = accelerator
        self.preprocessors = Preprocessor.normalize(preprocessor)
        self.postprocessors = Postprocessor.normalize(postprocessor)
        self.retain = retention(retain)
        self.update_operations = list(update_operations or [])
        self.request_signature = request_signature
        self.response_signature = response_signature
        self.device = torch.device("cpu")

    def setup(self) -> None:
        """Load, mutate, place, and freeze the configured model."""

        if self.accelerator == Accelerator.auto:
            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            else:
                mps = getattr(torch.backends, "mps", None)
                self.device = torch.device("mps" if mps is not None and mps.is_available() else "cpu")
        else:
            self.device = torch.device(self.accelerator.value)

        model = self.model_source if isinstance(self.model_source, Model) else Model.load(self.model_source)
        for predicates, values in self.update_operations:
            model.update(*predicates, **values)
        model.warn_unbounded()

        self.model = model.to(self.device)
        self.model.eval()

    def validate(self, payload: Any) -> Input | ErrorItem:
        """Validate one JSON object without changing its request position."""

        if not isinstance(payload, dict):
            return ErrorItem(
                status_code=422,
                message=f"each request must be a JSON object, got {type(payload).__name__}",
            )

        try:
            if self.request_signature is None:
                return cast(Input, payload)
            request = self.request_signature.model_validate(payload)
            return request.model_dump(mode="python")
        except Exception as exception:
            return ErrorItem(status_code=422, message=str(exception))

    def failure(self, error: ErrorItem) -> dict[str, Any]:
        """Encode one request-local error using the stable response envelope."""

        return {
            "predictions": None,
            "error": {
                "status_code": error.status_code,
                "message": error.message,
            },
        }

    def headers(self) -> dict[str, str]:
        """Mirror the canonical prediction metadata without repeating it in rows."""

        values = metadata(self.model)
        return {
            "X-RelFlow-Prediction-Format": values[b"relflow.prediction_format"].decode("utf-8"),
            "X-RelFlow-Model-Version": values[b"relflow.model_version"].decode("utf-8"),
        }

    def predict_table(self, data: pa.Table, *, batch_size: int | None = None) -> pa.Table:
        """Predict Arrow inputs without changing the selected output columns.

        Serving processors must preserve request identity and order, with one
        final output row per valid request. The row-count guard detects changed
        cardinality; processors remain responsible for identity and order.
        """

        if not isinstance(data, pa.Table):
            raise TypeError(f"deployment prediction input must be a pyarrow.Table, got {type(data).__name__}")

        result = self.model.predict(
            data,
            preprocess=self.preprocessors,
            postprocess=self.postprocessors,
            retain=self.retain,
            batch_size=batch_size,
        )
        if not isinstance(result, pa.Table):
            raise TypeError(f"Model.predict must return a pyarrow.Table, got {type(result).__name__}")
        if result.num_rows != data.num_rows:
            raise ValueError(
                f"Model.predict returned {result.num_rows} rows for {data.num_rows} valid deployment requests"
            )
        return result

    def predict_payloads(self, payloads: list[Any]) -> list[dict[str, Any]]:
        """Validate, predict, serialize, and scatter one request microbatch.

        Valid requests cross the Python-to-Arrow boundary together. Ordered
        preprocessing stays batchwise, ``Model.predict`` is called once, and
        ordered postprocessing receives the written batch before one terminal
        ``Table.to_pylist``. Invalid request rows retain their original slots.
        """

        outputs: list[dict[str, Any] | None] = [None] * len(payloads)
        valid: list[Input] = []
        request_positions: list[int] = []

        for position, payload in enumerate(payloads):
            item = self.validate(payload)
            if isinstance(item, ErrorItem):
                outputs[position] = self.failure(item)
            else:
                valid.append(item)
                request_positions.append(position)

        if valid:
            try:
                data = pa.Table.from_pylist(mappings(valid, context="deployment requests"))
            except (pa.ArrowException, TypeError, ValueError) as exception:
                error = self.failure(
                    ErrorItem(status_code=422, message=f"request is not Arrow-compatible: {exception}")
                )
                for position in request_positions:
                    outputs[position] = error
                return [cast(dict[str, Any], output) for output in outputs]

            result = self.predict_table(data)
            rows = result.to_pylist()
            for position, row in zip(request_positions, rows, strict=True):
                if self.response_signature is not None:
                    response = self.response_signature.model_validate(row)
                    row = response.model_dump(mode="json")
                outputs[position] = row

        return [cast(dict[str, Any], output) for output in outputs]


@dataclass(slots=True)
class QueuedRequest:
    payload: Any
    future: asyncio.Future[dict[str, Any]]


class FastAPIBatcher:
    """Gather concurrent HTTP requests into bounded model microbatches."""

    def __init__(
        self,
        runtime: FastAPIRuntime,
        *,
        max_batch_size: int,
        batch_timeout: float,
    ) -> None:
        self.runtime = runtime
        self.max_batch_size = max_batch_size
        self.batch_timeout = batch_timeout
        self.queue: asyncio.Queue[QueuedRequest] = asyncio.Queue()
        self.task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self.runtime.setup()
        self.task = asyncio.create_task(self.work())

    async def stop(self) -> None:
        if self.task is None:
            return

        self.task.cancel()
        with suppress(asyncio.CancelledError):
            await self.task
        self.task = None

    async def submit(self, payload: Any) -> dict[str, Any]:
        return (await self.submit_many([payload]))[0]

    async def submit_many(self, payloads: list[Any]) -> list[dict[str, Any]]:
        if not payloads:
            return []

        loop = asyncio.get_running_loop()
        items = [QueuedRequest(payload=payload, future=loop.create_future()) for payload in payloads]
        for item in items:
            await self.queue.put(item)
        return list(await asyncio.gather(*(item.future for item in items)))

    async def work(self) -> None:
        while True:
            first = await self.queue.get()
            batch = [first]
            self.drain(batch)

            if len(batch) < self.max_batch_size and self.batch_timeout > 0.0:
                deadline = asyncio.get_running_loop().time() + self.batch_timeout
                while len(batch) < self.max_batch_size:
                    remaining = deadline - asyncio.get_running_loop().time()
                    if remaining <= 0.0:
                        break
                    try:
                        batch.append(await asyncio.wait_for(self.queue.get(), timeout=remaining))
                    except TimeoutError:
                        break
                    self.drain(batch)

            try:
                responses = await asyncio.to_thread(
                    self.runtime.predict_payloads,
                    [item.payload for item in batch],
                )
            except Exception as exception:
                for item in batch:
                    if not item.future.cancelled():
                        item.future.set_exception(exception)
                continue

            if len(responses) != len(batch):
                exception = RuntimeError(
                    f"deployment runtime returned {len(responses)} responses for {len(batch)} requests"
                )
                for item in batch:
                    if not item.future.cancelled():
                        item.future.set_exception(exception)
                continue

            for item, response in zip(batch, responses, strict=True):
                if not item.future.cancelled():
                    item.future.set_result(response)

    def drain(self, batch: list[QueuedRequest]) -> None:
        while len(batch) < self.max_batch_size:
            try:
                batch.append(self.queue.get_nowait())
            except asyncio.QueueEmpty:
                return


class Deployment(BaseSettings):
    """Serving configuration for a checkpoint or an in-memory model.

    Pydantic request signatures validate each item before the valid rows are
    converted into one Arrow table. ``retain`` controls which processed input
    columns appear in the canonical output and are available to a Polars
    postprocessor. Model provenance is carried in Arrow metadata and HTTP
    headers. Processors must preserve request identity, order and cardinality.

    Set ``checkpoint`` to a path or provide an in-memory ``model``. Configure
    ``max_batch_size`` and ``batch_timeout`` for microbatching; ``workers`` selects
    server processes. ``accelerator`` chooses the model device. ``host``, ``port``
    and ``log_level`` configure Uvicorn. Values can also come from the documented
    ``RELFLOW_*`` environment variables. Configuration methods mutate this object
    and return it, preserving subclass methods during chaining.
    """

    model_config = SettingsConfigDict(
        extra="ignore",
        case_sensitive=False,
        validate_by_name=True,
        validate_by_alias=True,
        arbitrary_types_allowed=True,
    )

    checkpoint: ModelSource = Field(
        default="model.ckpt",
        validation_alias=AliasChoices("RELFLOW_CHECKPOINT", "CHECKPOINT"),
    )
    model: Model | None = Field(default=None, exclude=True)
    max_batch_size: int = Field(
        default=128,
        ge=1,
        validation_alias=AliasChoices("RELFLOW_MAX_BATCH_SIZE", "MAX_BATCH_SIZE"),
    )
    batch_timeout: float = Field(
        default=0.0,
        ge=0.0,
        validation_alias=AliasChoices("RELFLOW_BATCH_TIMEOUT", "BATCH_TIMEOUT"),
    )
    workers: int = Field(
        default=1,
        ge=1,
        validation_alias=AliasChoices("RELFLOW_WORKERS", "WORKERS"),
    )
    accelerator: Accelerator = Field(
        default=Accelerator.auto,
        validation_alias=AliasChoices("RELFLOW_ACCELERATOR", "ACCELERATOR"),
    )
    host: str = Field(
        default="0.0.0.0",
        validation_alias=AliasChoices("RELFLOW_HOST", "HOST"),
    )
    port: int = Field(
        default=8000,
        ge=1,
        le=65535,
        validation_alias=AliasChoices("RELFLOW_PORT", "PORT"),
    )
    log_level: str = Field(
        default="info",
        validation_alias=AliasChoices("RELFLOW_LOG_LEVEL", "LOG_LEVEL"),
    )
    json_backend: JSONBackend = Field(
        default=JSONBackend.orjson,
        validation_alias=AliasChoices("RELFLOW_JSON_BACKEND", "JSON_BACKEND"),
    )
    retain: Retain = Field(
        default=(),
        validation_alias=AliasChoices("RELFLOW_RETAIN", "RETAIN"),
    )

    _request_signature: type[pydantic.BaseModel] | None = pydantic.PrivateAttr(default=None)
    _response_signature: type[pydantic.BaseModel] | None = pydantic.PrivateAttr(default=None)
    _preprocessors: tuple[Preprocessor, ...] = pydantic.PrivateAttr(default=())
    _postprocessors: tuple[Postprocessor, ...] = pydantic.PrivateAttr(default=())
    _update_operations: list[UpdateOperation] = pydantic.PrivateAttr(default_factory=list)

    @field_validator("checkpoint", mode="before")
    @classmethod
    def check_checkpoint(cls, value: Any) -> Any:
        if isinstance(value, str):
            stripped = value.strip()
            if stripped == "":
                raise ValueError("checkpoint must not be blank")
            return stripped
        return value

    @field_validator("retain", mode="before")
    @classmethod
    def check_retain(cls, value: Any) -> Retain:
        return retention(cast(Retain, value))

    @model_validator(mode="after")
    def check_model_source(self) -> Self:
        if self.model is not None and "checkpoint" in self.model_fields_set:
            raise ValueError("pass either checkpoint or model, not both")
        return self

    @beartype
    def forge(
        self: DeploymentType,
        request: type[pydantic.BaseModel] | None = None,
        response: type[pydantic.BaseModel] | None = None,
    ) -> DeploymentType:
        """Attach optional Pydantic request and response signatures."""

        self._request_signature = request
        self._response_signature = response
        return self

    @beartype
    def preprocess(self: DeploymentType, preprocessor: PreprocessorInput) -> DeploymentType:
        """Attach an ordered eager Polars preprocessor collection."""

        self._preprocessors = Preprocessor.normalize(preprocessor)
        return self

    @beartype
    def postprocess(self: DeploymentType, postprocessor: PostprocessorInput) -> DeploymentType:
        """Attach an ordered eager Polars postprocessor collection."""

        self._postprocessors = Postprocessor.normalize(postprocessor)
        return self

    @beartype
    def update(
        self: DeploymentType,
        *predicates: NodePredicate | NodeAttribute | Callable[[Node], bool],
        strict: bool = True,
        include_root: bool = True,
        validate: bool = True,
        **values: Any,
    ) -> DeploymentType:
        """Queue declared schema changes for startup; use ``description`` for notes."""

        self._update_operations.append(
            (
                tuple(predicates),
                {
                    "strict": strict,
                    "include_root": include_root,
                    "validate": validate,
                    **values,
                },
            )
        )
        return self

    def app(self) -> fastapi.FastAPI:
        """Build a FastAPI app for the configured model."""

        runtime = FastAPIRuntime(
            checkpoint=self.model if self.model is not None else self.checkpoint,
            accelerator=self.accelerator,
            preprocessor=self._preprocessors,
            postprocessor=self._postprocessors,
            retain=self.retain,
            update_operations=self._update_operations,
            request_signature=self._request_signature,
            response_signature=self._response_signature,
        )
        batcher = FastAPIBatcher(
            runtime=runtime,
            max_batch_size=self.max_batch_size,
            batch_timeout=self.batch_timeout,
        )

        @asynccontextmanager
        async def lifespan(app: fastapi.FastAPI):
            await batcher.start()
            app.state.relflow_runtime = runtime
            app.state.relflow_batcher = batcher
            try:
                yield
            finally:
                await batcher.stop()

        app = fastapi.FastAPI(lifespan=lifespan)

        @app.get("/health")
        async def health() -> dict[str, str]:
            return {"status": "ok"}

        def json_response(
            content: Any,
            status_code: int = 200,
            headers: dict[str, str] | None = None,
        ) -> fastapi.Response:
            if self.json_backend == JSONBackend.orjson:
                return fastapi.Response(
                    content=orjson.dumps(content, option=orjson.OPT_NON_STR_KEYS),
                    status_code=status_code,
                    media_type="application/json",
                    headers=headers,
                )
            return JSONResponse(content=content, status_code=status_code, headers=headers)

        @app.post("/predict")
        async def predict(request: fastapi.Request) -> fastapi.Response:
            media_type = request.headers.get("content-type", "").partition(";")[0].strip().lower()
            if media_type == ARROW_MEDIA_TYPE:
                try:
                    table = ipc.open_stream(pa.BufferReader(await request.body())).read_all()
                except (pa.ArrowException, OSError, ValueError) as exception:
                    return json_response(
                        self.error(status_code=400, message=f"invalid Arrow IPC stream: {exception}"),
                        status_code=400,
                    )

                predicted = await asyncio.to_thread(runtime.predict_table, table, batch_size=self.max_batch_size)
                sink = pa.BufferOutputStream()
                with ipc.new_stream(sink, predicted.schema) as writer:
                    writer.write_table(predicted)
                return fastapi.Response(
                    content=memoryview(sink.getvalue()),
                    media_type=ARROW_MEDIA_TYPE,
                    headers=runtime.headers(),
                )

            if media_type != JSON_MEDIA_TYPE:
                return json_response(
                    self.error(
                        status_code=415,
                        message=(
                            f"unsupported content type {media_type or '<missing>'!r}; "
                            f"use {JSON_MEDIA_TYPE!r} or {ARROW_MEDIA_TYPE!r}"
                        ),
                    ),
                    status_code=415,
                    headers={"Accept": f"{JSON_MEDIA_TYPE}, {ARROW_MEDIA_TYPE}"},
                )

            try:
                payload = (
                    orjson.loads(await request.body())
                    if self.json_backend == JSONBackend.orjson
                    else await request.json()
                )
            except Exception as exception:
                return json_response(
                    self.error(status_code=400, message=str(exception)),
                    status_code=400,
                )

            if isinstance(payload, dict):
                return json_response(await batcher.submit(payload), headers=runtime.headers())
            if isinstance(payload, list):
                return json_response(await batcher.submit_many(payload), headers=runtime.headers())
            return json_response(
                self.error(
                    status_code=422,
                    message=(
                        f"request body must be a JSON object or an array of JSON objects, got {type(payload).__name__}"
                    ),
                ),
                status_code=422,
            )

        self.register(app)
        return app

    def error(self, *, status_code: int, message: str) -> dict[str, Any]:
        """Build a transport-level error response."""

        return {
            "predictions": None,
            "error": {
                "status_code": status_code,
                "message": message,
            },
        }

    def register(self, app: fastapi.FastAPI) -> None:
        """Register both wire formats and optional Pydantic signatures in OpenAPI."""

        def register_model(openapi_schema: dict[str, Any], model: type[pydantic.BaseModel]) -> str:
            schema = model.model_json_schema(ref_template="#/components/schemas/{model}")
            definitions = schema.pop("$defs", {})
            components = openapi_schema.setdefault("components", {}).setdefault("schemas", {})
            for name, definition in definitions.items():
                components.setdefault(name, definition)
            name = str(schema.get("title") or model.__name__)
            components.setdefault(name, schema)
            return name

        def cardinality(item: dict[str, Any]) -> dict[str, Any]:
            return {"anyOf": [item, {"type": "array", "items": item}]}

        def schema() -> dict[str, Any]:
            if app.openapi_schema is not None:
                return app.openapi_schema

            openapi_schema = get_openapi(
                title=app.title,
                version=app.version,
                openapi_version=app.openapi_version,
                summary=app.summary,
                description=app.description,
                routes=app.routes,
            )
            operation = openapi_schema["paths"]["/predict"]["post"]
            operation["summary"] = "Predict JSON or Arrow records"
            operation["description"] = (
                f"Set `Content-Type` to `{JSON_MEDIA_TYPE}` for JSON or `{ARROW_MEDIA_TYPE}` for an Arrow IPC "
                "stream. A successful response uses the same media type as the request. JSON request and response "
                "signatures apply only to the JSON representation; Arrow schemas are validated by preprocessing "
                "and the model. The response representation is not independently negotiated with `Accept`."
            )
            generic_request = {
                "anyOf": [
                    {"type": "object"},
                    {"type": "array", "items": {"type": "object"}},
                ]
            }
            if self._request_signature is not None:
                request_name = register_model(openapi_schema, self._request_signature)
                request_schema = cardinality({"$ref": f"#/components/schemas/{request_name}"})
            else:
                request_schema = generic_request
            operation["requestBody"] = {
                "required": True,
                "description": (
                    "One JSON record, an array of JSON records, or one Arrow IPC stream. "
                    "The request Content-Type selects the deserializer."
                ),
                "content": {
                    JSON_MEDIA_TYPE: {"schema": request_schema},
                    ARROW_MEDIA_TYPE: {},
                },
            }
            success = operation.setdefault("responses", {}).setdefault("200", {})
            success["description"] = (
                "Prediction output in the request's media type. JSON output preserves object/array cardinality; "
                "Arrow output is an IPC stream whose rows remain in input order. Selected canonical columns "
                "are preserved. Model provenance and the prediction format are carried in HTTP headers "
                "and Arrow schema metadata."
            )
            success["headers"] = {
                "X-RelFlow-Prediction-Format": {
                    "description": "Version of the canonical RelFlow prediction layout.",
                    "schema": {"type": "string"},
                    "example": "2",
                },
                "X-RelFlow-Model-Version": {
                    "description": (
                        "RelFlow version stored in the loaded model. This describes the package/checkpoint "
                        "version and is not a unique weights fingerprint."
                    ),
                    "schema": {"type": "string"},
                },
            }
            responses = success.setdefault("content", {})
            components = openapi_schema.setdefault("components", {}).setdefault("schemas", {})
            if self._response_signature is not None:
                response_name = register_model(openapi_schema, self._response_signature)
                item = components[response_name]
            else:
                item = {"type": "object"}
            response_schema = cardinality(item)
            responses[JSON_MEDIA_TYPE] = {"schema": response_schema}
            responses[ARROW_MEDIA_TYPE] = {}

            components.setdefault(
                "DeploymentError",
                {
                    "type": "object",
                    "required": ["predictions", "error"],
                    "properties": {
                        "predictions": {"type": "null"},
                        "error": {
                            "type": "object",
                            "required": ["status_code", "message"],
                            "properties": {
                                "status_code": {"type": "integer"},
                                "message": {"type": "string"},
                            },
                        },
                    },
                },
            )
            error = {"schema": {"$ref": "#/components/schemas/DeploymentError"}}
            operation["responses"]["400"] = {
                "description": "The declared JSON or Arrow IPC representation is malformed.",
                "content": {JSON_MEDIA_TYPE: error},
            }
            operation["responses"]["415"] = {
                "description": "The request Content-Type is missing or unsupported.",
                "headers": {
                    "Accept": {
                        "description": "Media types accepted as request content.",
                        "schema": {"type": "string"},
                        "example": f"{JSON_MEDIA_TYPE}, {ARROW_MEDIA_TYPE}",
                    }
                },
                "content": {JSON_MEDIA_TYPE: error},
            }
            operation["responses"]["422"] = {
                "description": "The JSON body is not an object or an array of objects.",
                "content": {JSON_MEDIA_TYPE: error},
            }

            app.openapi_schema = openapi_schema
            return openapi_schema

        app.openapi = schema  # type: ignore[method-assign]

    def serve(self) -> None:
        """Start the configured FastAPI server."""

        if self.workers > 1:
            if self.model is not None or isinstance(self.checkpoint, Model):
                raise ValueError("workers > 1 requires a checkpoint path, not an in-memory model")
            if any(
                (
                    self._request_signature is not None,
                    self._response_signature is not None,
                    bool(self._preprocessors),
                    bool(self._postprocessors),
                    bool(self._update_operations),
                )
            ):
                raise ValueError(
                    "workers > 1 cannot serialize in-process forge, preprocess, postprocess, or update configuration"
                )

            if self.retain not in ((), "*"):
                raise ValueError("workers > 1 does not support a tuple retain projection; use '*' or ()")

            env_updates = {
                "RELFLOW_CHECKPOINT": str(self.checkpoint),
                "RELFLOW_MAX_BATCH_SIZE": str(self.max_batch_size),
                "RELFLOW_BATCH_TIMEOUT": str(self.batch_timeout),
                "RELFLOW_ACCELERATOR": self.accelerator.value,
                "RELFLOW_JSON_BACKEND": self.json_backend.value,
            }
            if self.retain == "*":
                env_updates["RELFLOW_RETAIN"] = orjson.dumps(self.retain).decode()
            previous = {key: os.environ.get(key) for key in env_updates}
            try:
                os.environ.update(env_updates)
                uvicorn.run(
                    "relflow.inference.asgi:app",
                    workers=self.workers,
                    host=self.host,
                    port=self.port,
                    log_level=self.log_level,
                )
            finally:
                for key, value in previous.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
            return

        uvicorn.run(self.app(), host=self.host, port=self.port, log_level=self.log_level)


__all__ = [
    "Accelerator",
    "Deployment",
    "FastAPIBatcher",
    "FastAPIRuntime",
    "Input",
    "JSONBackend",
    "ModelSource",
    "Retain",
    "UpdateOperation",
]
