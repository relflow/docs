from __future__ import annotations

import enum
import math
from dataclasses import InitVar
from typing import TYPE_CHECKING, Annotated, Literal, Unpack, cast

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc
import pydantic
import torch
from beartype import beartype
from tensordict import TensorDict, tensorclass

from relflow.data.ragged import RaggedField
from relflow.distributed import all_reduce_sum
from relflow.helpers import Jitter
from relflow.logging import logger
from relflow.structs.enums import Component, Metric, Strata, TensorKey, Tokens
from relflow.structs.packages import Parcel, Prediction
from relflow.structs.tree import Address, FieldOptions
from relflow.tensorfields.base import (
    Context,
    DecoderBase,
    EmbedderBase,
    Extension,
    RequestBase,
    TensorFieldBase,
    TensorInput,
)
from relflow.tensorfields.output import array, struct
from relflow.tensorfields.shared.counter import Counter, CounterUpdateCallback, tally

if TYPE_CHECKING:
    from relflow.architecture.root import Model
    from relflow.structs.experiment import Schema
    from relflow.structs.structure import Branch


number: Extension = Extension(name="number", types=(int | float,))
number.callback(CounterUpdateCallback)

FOURIER_SAFE_MAX_ANGLE = float(1e4)


class Objective(enum.StrEnum):
    mae = "mae"
    mse = "mse"
    huber = "huber"

    def loss(self, *, input: torch.Tensor, target: torch.Tensor, reduction: str = "none") -> torch.Tensor:
        match self:
            case Objective.mae:
                return torch.nn.functional.l1_loss(input=input, target=target, reduction=reduction)
            case Objective.mse:
                return torch.nn.functional.mse_loss(input=input, target=target, reduction=reduction)
            case Objective.huber:
                return torch.nn.functional.huber_loss(input=input, target=target, reduction=reduction)


@number.register(Component.Request)
class Request(RequestBase):
    """Continuous numeric scalar with online normalization and Fourier features.

    ``objective`` selects ``"mae"``, ``"mse"``, or ``"huber"`` reconstruction
    loss in normalized units; predictions and error metrics use source units.
    ``alpha=None`` uses cumulative statistics; a value in ``(0, 1)`` uses
    exponential updates. ``n_bands`` and ``offset`` bound Fourier exponents.
    ``jitter=rf.Jitter(...)`` perturbs training inputs while retaining pristine
    targets. ``mask=True`` makes the scalar a supervised, unembedded target.
    """

    type: Literal["number"] = "number"
    jitter: Jitter = pydantic.Field(default_factory=Jitter)
    n_bands: Annotated[int, pydantic.Field(gt=0, default=8)] = 8
    offset: Annotated[int, pydantic.Field(gt=0, default=4)] = 4
    alpha: Annotated[float | None, pydantic.Field(gt=0.0, lt=1.0, default=None)] = None
    objective: Objective = Objective.mae

    if TYPE_CHECKING:

        def __init__(
            self,
            *,
            jitter: Jitter = ...,
            n_bands: int = 8,
            offset: int = 4,
            alpha: float | None = None,
            objective: Objective | Literal["mae", "mse", "huber"] = Objective.mae,
            type: Literal["number"] = "number",
            **options: Unpack[FieldOptions],
        ) -> None: ...

    @classmethod
    def normalization(
        cls,
        model: "Model",
        address: Address | str,
        /,
    ) -> dict[str, float | int | None]:
        """Return a CPU-native snapshot of one Number field's normalizer."""
        from relflow.architecture.root import Model

        if not isinstance(model, Model):
            raise TypeError(f"Number.normalization model must be a Model, got {type(model).__name__}")

        address = Address(str(address))
        if address not in model.nodes:
            raise KeyError(f"no field at address {str(address)!r}")

        embedder = getattr(model.nodes[address], "embedder", None)
        if not isinstance(embedder, Embedder):
            raise TypeError(f"address {str(address)!r} is not a Number field (got {type(embedder).__name__})")

        normalizer = embedder.normalizer
        mean = float(normalizer.mean.detach().cpu().item())
        variance = float(normalizer.var.detach().cpu().item())
        count = None if normalizer.alpha is not None else int(normalizer.count.detach().cpu().item())

        return {
            "mean": mean,
            "variance": variance,
            "std": math.sqrt(variance + normalizer.epsilon),
            "count": count,
            "alpha": normalizer.alpha,
        }


@number.register(Component.observe)
def observe(
    field: RaggedField,
    *,
    address: Address,
    schema: Schema,
    state: object | None,
    learn: bool,
) -> TensorDict | None:
    """Summarize complete pristine numeric state and content."""

    if not learn:
        return None
    values = pc.cast(field.values, pa.float32(), safe=False)
    if isinstance(values, pa.ChunkedArray):
        values = values.combine_chunks()
    content = torch.from_numpy(values.to_numpy(zero_copy_only=False).copy())
    return TensorDict(
        {
            TensorKey.state: tally(torch.from_numpy(field.dense.copy()), len(Tokens)),
            TensorKey.content: moments(content),
        },
        batch_size=[],
    )


@number.register(Component.TensorField)
@tensorclass
class TensorField(TensorFieldBase[torch.Tensor]):
    content: torch.Tensor
    state: torch.Tensor
    present: torch.Tensor
    trainable: torch.Tensor
    inferred: torch.Tensor
    targets: TensorDict

    if TYPE_CHECKING:
        # TensorClass metadata is accepted by its generated initializer.
        batch_size: InitVar[int | torch.Size | list[int] | tuple[int, ...] | None] = None
        device: InitVar[torch.device | str | int | None] = None
        names: InitVar[list[str | None] | None] = None

    @classmethod
    def new(
        cls,
        input: RaggedField,
        target: RaggedField,
        present: torch.Tensor,
        trainable: torch.Tensor,
        inferred: torch.Tensor,
        address: Address,
        schema: Schema,
        strata: Strata,
        context: Context,
    ) -> TensorField:
        def encode(field: RaggedField) -> torch.Tensor:
            values = field.values.combine_chunks() if isinstance(field.values, pa.ChunkedArray) else field.values
            if (
                pa.types.is_list(values.type)
                or pa.types.is_large_list(values.type)
                or pa.types.is_fixed_size_list(values.type)
            ):
                raise ValueError(f"number field at '{address}' expects scalar Arrow values, got {values.type}")

            encoded = pc.cast(values, pa.float64(), safe=True)
            if isinstance(encoded, pa.ChunkedArray):
                encoded = encoded.combine_chunks()
            data = field.place(encoded.to_numpy(zero_copy_only=False), fill=0.0)
            return torch.from_numpy(np.nan_to_num(data, nan=0.0)).to(dtype=torch.float32)

        state = torch.from_numpy(input.dense)

        return cls(
            content=encode(input),
            state=state,
            present=present,
            trainable=trainable,
            inferred=inferred,
            targets=TensorDict(
                {
                    TensorKey.state: torch.from_numpy(target.dense),
                    TensorKey.content: encode(target),
                }
                if address in schema.objectives
                else {},
                batch_size=input.shape,
            ),
            batch_size=input.batch_size,
        )


def moments(values: torch.Tensor) -> TensorDict:
    """Summarize finite values with an exact count and centered float32 moments."""

    finite = values.reshape(-1).to(dtype=torch.float32)
    finite = finite.masked_select(torch.isfinite(finite))
    if finite.numel():
        variance, mean = torch.var_mean(finite, correction=0)
    else:
        variance, mean = finite.new_zeros(()), finite.new_zeros(())
    return TensorDict(
        {
            "count": torch.tensor(finite.numel(), dtype=torch.int64, device=values.device),
            "mean": mean,
            "var": variance,
        },
        batch_size=[],
    )


class GlobalOnlineNormalizer(torch.nn.Module):
    def __init__(self, alpha: float | None = None, epsilon: float = 1e-5):
        super().__init__()

        self.epsilon: float = epsilon
        self.alpha: float | None = alpha

        self.register_buffer("mean", torch.zeros(1, dtype=torch.float32))
        self.register_buffer("var", torch.ones(1, dtype=torch.float32))
        self.register_buffer("count", torch.zeros(1, dtype=torch.int64))

    @torch.no_grad()
    def update(self, values: torch.Tensor):
        self.merge(moments(values))

    @torch.no_grad()
    def learn(self, observation: TensorDict) -> None:
        """Synchronize and apply one pristine numeric observation."""

        if not isinstance(observation, TensorDict):
            raise TypeError(f"normalizer observation must be a TensorDict, got {type(observation).__name__}")
        observation = observation.to(device=self.mean.device)
        local_count = cast(torch.Tensor, observation["count"])
        local_mean = cast(torch.Tensor, observation["mean"])
        local_var = cast(torch.Tensor, observation["var"])
        count = all_reduce_sum(local_count.clone())
        if not count:
            return
        weight = local_count.to(dtype=torch.float32) / count
        mean = all_reduce_sum(local_mean * weight)
        # Center on the shared mean before reducing variance. Raw squared sums
        # lose small variances at large offsets in float32; empty ranks contribute zero.
        delta = torch.where(local_count > 0, local_mean - mean, 0.0)
        variance = all_reduce_sum((local_var + delta.square()) * weight)
        self.merge(TensorDict({"count": count, "mean": mean, "var": variance}, batch_size=[]))

    @torch.no_grad()
    def merge(self, observation: TensorDict) -> None:
        """Merge centered moments into running statistics without retaining values."""

        count = cast(torch.Tensor, observation["count"])
        mean = cast(torch.Tensor, observation["mean"])
        variance = cast(torch.Tensor, observation["var"])
        if not all(torch.isfinite(value).all() for value in (count, mean, variance)):
            raise ValueError("normalizer observation must contain only finite values")
        if count < 0:
            raise ValueError("normalizer observation count cannot be negative")
        if variance < 0:
            raise ValueError("normalizer observation variance cannot be negative")

        batch_count = count.to(device=self.count.device, dtype=self.count.dtype)
        if not batch_count:
            return

        batch_mean = mean.to(self.mean)
        batch_var = variance.to(self.var)

        if self.alpha is not None:
            alpha: float = self.alpha
            new_mean = (1 - alpha) * self.mean + alpha * batch_mean
            new_var = (1 - alpha) * self.var + alpha * batch_var

            self.mean = new_mean
            self.var = new_var

            return

        new_count = self.count + batch_count
        weight = batch_count.to(dtype=self.mean.dtype) / new_count
        delta = batch_mean - self.mean
        correction = delta * torch.sqrt((self.count.to(dtype=self.mean.dtype) / new_count) * weight)
        self.mean = torch.lerp(self.mean, batch_mean, weight)
        self.var = torch.lerp(self.var, batch_var, weight) + correction.square()
        self.count = new_count

    def forward(self, inputs: torch.Tensor, mask: torch.Tensor, update=True) -> torch.Tensor:
        finite_mask = mask & torch.isfinite(inputs)
        if self.training and update:
            self.update(inputs[finite_mask])

        std = torch.sqrt(self.var + self.epsilon)
        normalized = (torch.atleast_1d(inputs) - self.mean) / std
        return torch.where(finite_mask, normalized.reshape_as(inputs), inputs)


@number.register(Component.Embedder)
class Embedder(EmbedderBase):
    def __init__(self, schema: Schema, address: Address):
        super().__init__(schema=schema, address=address)

        request: Request = cast(Request, schema.requests[address])
        self.origin: Address = address
        self.destination: Address = cast("Branch", request.parent).address

        self.embeddings = torch.nn.Embedding(num_embeddings=len(Tokens), embedding_dim=schema.d_model)
        self.counter = Counter(address=address, size=len(Tokens))

        n_bands = request.n_bands
        offset = request.offset

        weights = torch.logspace(start=-n_bands, end=offset, steps=n_bands + offset + 1, base=2)
        self.linear = torch.nn.Linear(2 * len(weights), schema.d_model)
        self.scalar = torch.nn.Linear(1, schema.d_model, bias=False)
        self.register_buffer("weights", weights.mul(math.pi).unsqueeze(dim=0))
        self.register_buffer("max_fourier_input", torch.tensor(FOURIER_SAFE_MAX_ANGLE) / self.weights.abs().max())

        self.jitter: Jitter = request.jitter
        self.weights: torch.Tensor
        self.max_fourier_input: torch.Tensor

        self.normalizer: GlobalOnlineNormalizer = GlobalOnlineNormalizer(alpha=request.alpha)

    def clamp(self, content: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
        bound = self.max_fourier_input.to(device=content.device, dtype=content.dtype)
        valued = state.eq(Tokens.valued)
        finite = torch.isfinite(content)
        out_of_range = content.abs().gt(bound)
        unsafe = ~finite | out_of_range

        if unsafe.any():
            unsafe_values = content[unsafe].detach()
            unsafe_abs = unsafe_values.abs()
            finite_abs = unsafe_abs[torch.isfinite(unsafe_abs)]
            if torch.isinf(unsafe_abs).any():
                max_abs = math.inf
            elif finite_abs.numel() > 0:
                max_abs = float(finite_abs.max().cpu().item())
            else:
                max_abs = math.nan

            logger.bind(
                component="tensorfield",
                field_type="number",
                address=str(self.origin),
                count=int(unsafe.sum().cpu().item()),
                valued_count=int((unsafe & valued).sum().cpu().item()),
                nonfinite_count=int((~torch.isfinite(unsafe_values)).sum().cpu().item()),
                max_abs_normalized=max_abs,
                bound=float(bound.detach().cpu().item()),
                safe_max_angle=FOURIER_SAFE_MAX_ANGLE,
            ).warning("number Fourier inputs exceed safe range; clamping normalized values")

        clamped = content.clamp(min=-bound, max=bound)
        return torch.where(torch.isnan(clamped), torch.zeros_like(clamped), clamped)

    @beartype
    def forward(self, inputs: TensorInput) -> Parcel:
        N, *dims = inputs.state.shape
        D = math.prod(tuple([N, *dims]))

        state = inputs.state.reshape(D)
        content = cast(torch.Tensor, inputs.content).reshape(D)
        eligible = state.eq(Tokens.valued) & torch.isfinite(content)

        if self.training and not self.jitter.normalize:
            content = self.jitter.apply(content, eligible)

        content = self.normalizer(inputs=content, mask=state.eq(Tokens.valued), update=False)

        if self.training and self.jitter.normalize:
            content = self.jitter.apply(content, eligible)

        content = self.clamp(content=content, state=state)

        weighted = content.unsqueeze(dim=1).mul(self.weights)
        fourier = torch.cat([torch.sin(weighted), torch.cos(weighted)], dim=1)

        projection = torch.nn.functional.gelu(self.linear(fourier), approximate="tanh").reshape(N, *dims, -1)

        embeddings = self.embeddings(state).reshape(N, *dims, -1)

        payload = embeddings + projection + self.scalar(content.reshape(-1, 1)).reshape(N, *dims, -1)
        # Keep one clamped monotone lane alongside the Fourier features.
        # This gives downstream additive and multiplicative interactions direct
        # access to numerical scale instead of forcing them to invert a periodic
        # basis outside the values observed during fitting.
        scalar = torch.where(
            eligible.reshape(N, *dims),
            content.reshape(N, *dims),
            embeddings[..., -1],
        )
        scalar = scalar + payload[..., -1] * 0.0
        payload = torch.cat((payload[..., :-1], scalar.unsqueeze(-1)), dim=-1)

        return Parcel(
            payload=payload,
            present=torch.ones(N, dtype=torch.bool, device=embeddings.device),
            origin=self.origin,
            destination=self.destination,
            batch_size=N,
        )


@number.register(Component.learn)
def learn(
    module: Model,
    observation: TensorDict,
    *,
    address: Address,
    strata: Strata,
) -> None:
    """Apply pristine numeric counts and normalization moments."""

    if strata != Strata.train:
        raise ValueError(f"number learner at '{address}' requires train strata, got {strata}")
    embedder: Embedder = cast(Embedder, module.nodes[address].embedder)
    embedder.counter.learn(cast(torch.Tensor, observation[TensorKey.state]))
    embedder.normalizer.learn(cast(TensorDict, observation[TensorKey.content]))


@number.register(Component.Decoder)
class Decoder(DecoderBase):
    def __init__(self, schema: Schema, address: Address):
        super().__init__(schema=schema, address=address)

        self.classification = torch.nn.Linear(in_features=schema.d_model, out_features=len(Tokens))
        self.regression = torch.nn.Linear(in_features=schema.d_model, out_features=1)

    @beartype
    def decode(self, pooled: torch.Tensor) -> TensorDict:
        return TensorDict(
            source={
                TensorKey.state: self.classification(pooled),
                TensorKey.content: self.regression(pooled),
            }
        )


@number.register(Component.loss)
def loss(
    module: Model,
    prediction: Prediction,
    batch: TensorFieldBase,
    strata: Strata,
) -> torch.Tensor:
    address: Address = prediction.address
    request: Request = cast(Request, module.schema.requests[prediction.address])

    embedder: Embedder = cast(Embedder, module.nodes[address].embedder)
    normalizer: GlobalOnlineNormalizer = embedder.normalizer

    N: int = cast(torch.Tensor, batch.targets[TensorKey.state]).numel()

    trainable: torch.Tensor = batch.trainable.reshape(N)
    state_targets = cast(torch.Tensor, batch.targets[TensorKey.state]).reshape(N)

    loss: torch.Tensor = module.track(
        (address, strata, Metric.loss, TensorKey.state),
        value=(
            torch.nn.functional.cross_entropy(
                input=cast(torch.Tensor, prediction.payload[TensorKey.state]).reshape(N, -1),
                target=state_targets,
                weight=embedder.counter.weight,
                reduction="none",
            )
            .masked_select(trainable)
            .mean()
        ),
    )

    target: torch.Tensor = cast(torch.Tensor, batch.targets[TensorKey.content]).reshape(N)
    inputs: torch.Tensor = cast(torch.Tensor, prediction.payload[TensorKey.content]).reshape(N)
    diff: torch.Tensor = inputs.subtract(target)

    loss += module.track(
        (address, strata, Metric.loss, TensorKey.content),
        value=request.objective.loss(
            input=diff / normalizer.var.sqrt().clamp_min(normalizer.epsilon),
            target=torch.zeros_like(diff),
            reduction="none",
        )
        .masked_select(trainable)
        .mean(),
    )

    diff = diff.masked_select(trainable)

    module.track(
        (address, strata, Metric.mae, TensorKey.content),
        value=diff.absolute().float().mean(),
    )

    module.track(
        (address, strata, Metric.rmse, TensorKey.content),
        value=diff.square().float().mean().sqrt(),
    )

    return loss


@number.register(Component.output)
def output(module: Model, address: Address) -> pa.StructType:
    return pa.struct([pa.field(TensorKey.content.name, pa.float64(), nullable=False)])


@number.register(Component.write)
def write(module: Model, prediction: Prediction, datatype: pa.StructType) -> pa.StructArray:
    content = array(cast(torch.Tensor, prediction.payload[TensorKey.content]), pa.float64())
    return struct({TensorKey.content.name: content}, datatype)
