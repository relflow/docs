# Matched Group ablation results

Research only. No change was promoted into the package or documentation.
All selection uses validation data; the official test records were not generated.
The immutable source, complete outcomes, audit hashes, and runnable scripts live
beside this file. See `PROTOCOL.md`, `manifest.json`, and `summary.json`.

The study completed 30 recorded experiments / 36 training fits with no execution
errors: 600 updates for each P078 fit, 800 for each P065 fit, CPU threads one.
Summed training wall time was approximately 373 seconds; some runs overlapped.

## Isolated changes at seed 7801

The native standard-normal assignment initialization and raw identity scores
are retained in every row here. Lower nRMSE is better; higher ARI is better.

| Intervention | P078 validation ARI | Validation nRMSE |
| --- | ---: | ---: |
| Matched protocol baseline | 0.2048 | 0.5924 |
| Deterministic straight-through routing only | 0.1451 | 0.6334 |
| Actual selected-ID membership statistics only | 0.1245 | 0.7397 |
| Detach tied reconstruction matrix gradient only | 0.1900 | 0.4788 |
| Routing + membership statistics | 0.1450 | 0.5930 |
| Routing + detach | 0.2415 | 0.4775 |
| Membership statistics + detach | 0.1900 | 0.4953 |
| All three | 0.2501 | 0.4523 |

Every matched first-bound parameter hash, ordered batch hash, mask hash, shared
parameter hash, and common Torch RNG hash agrees across the initial four arms.
The second harness version reproduces the baseline scores exactly. Membership
evidence changes the measured commitment subset but does not itself improve
semantic recovery in this panel. Detachment improves prediction at this seed
while missing both original quality/recovery requirements.

## Explicit small-initialization candidates

These additionally scale the first bound assignment table by 0.1. They do not
change the normal initial distribution to a balanced or ground-truth prior.
The main semantic targets remain opaque, and true group count is not supplied.

| Candidate / seed | P078 validation ARI | Validation nRMSE |
| --- | ---: | ---: |
| Baseline / 7801 | 0.2048 | 0.5924 |
| Baseline / 7802 | 0.2254 | 0.6132 |
| Baseline / 7803 | 0.2200 | 0.5720 |
| Routing + small init / 7801 | 0.8145 | 0.1587 |
| Routing + small init / 7802 | 0.2653 | 0.6339 |
| Routing + small init / 7803 | 0.3057 | 0.4319 |
| Routing + small init + membership + detach / 7801 | 0.7512 | 0.0599 |
| Routing + small init + membership + detach / 7802 | 0.5566 | 0.2588 |
| Routing + small init + membership + detach / 7803 | 0.6534 | 0.1694 |

The first candidate passes the validation quality/recovery thresholds at only
one of three seeds. The second improves prediction and ARI against each matched
baseline, and all three seeds meet nRMSE ≤ 0.35. None meets ARI ≥ 0.80; the
assignments remain fragmented across eight occupied slots in every seed. Both
three-seed candidate panels pass no-regime, shuffled-ID, identity-exposure, and
frozen-evaluation-state controls. Every declared seed was run despite failures.

Two additional single-seed combinations were retained: routing + small init +
detach scored ARI 0.6345 / nRMSE 0.1843; routing + small init + membership scored
0.3499 / 0.4099. No successful semantic-recovery claim follows from these.

## Reconstruction tradeoff

P065 full-known validation accuracy, at seeds 7651 / 7652 / 7653:

| Candidate | Accuracy by seed |
| --- | --- |
| Matched protocol baseline | 86.13% / 87.50% / 86.33% |
| Routing + small init | 73.63% / 72.07% / 100% |
| Routing + small init + membership + detach | 13.87% / 12.70% / 11.13% |

The last candidate's gain on P078 is not a general solution. P065 deliberately
uses `p_unavailable=1`, so known identity rows receive no visible-ID encoder
gradient. Detaching their reconstruction gradient leaves those random rows
without a direct learning path in this task. Their fixed codebook differs from
the deliberately balanced teacher codebook in earlier diagnostics; the result
does not establish that every fixed-codebook method must fail.

Coverage/count and all-OOV checks pass. The diagnostic does not repeat every
canonical evaluation check, and these validation scores do not replace the
canonical proof records. No candidate clears the combined learning requirements.

## Remaining hypotheses

Actual membership evidence is observable even when the reconstruction head has
uninformative context, but per-batch entropy from only ~13 selected P078 targets
also has finite-sample bias. Moving to all observed identities is a separate
intervention, not something this study silently changes.

Removing direct reconstruction pressure helps supervised prediction under weak,
stable routing, but breaks an important reconstructive task here. A coherent
objective that retains learnable identity probabilities and task-driven
membership is more promising than globally detaching the matrix. The root
research task evaluates that independently; this report does not claim its
outcome or recommend a production default.
