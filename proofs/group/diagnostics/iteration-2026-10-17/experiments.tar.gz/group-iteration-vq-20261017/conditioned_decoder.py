"""Matched-initialization Group decoder-context diagnostic; validation only."""

from experiment import ROOT, group, lit, load_proof, run_p065, run_p078, torch
import argparse
import hashlib
import json
from pathlib import Path
import resource
import time

ORIGINAL_INIT = group.Decoder.__init__
EXTRA_PARAMETERS = 0


def conditioned_init(self, schema, address):
    global EXTRA_PARAMETERS
    ORIGINAL_INIT(self, schema, address)
    # DecoderBase's conditioned path adds a context projection before creating
    # shared pool parameters. Preserve the native pool/head initialization and
    # global RNG for all common model parameters; import only the new context.
    with torch.random.fork_rng(devices=[]):
        conditioned = group.DecoderBase(schema=schema, address=address, conditioned=True)
    self.context_addresses = conditioned.context_addresses
    self.aligned_addresses = conditioned.aligned_addresses
    self.context_projection = conditioned.context_projection
    EXTRA_PARAMETERS = sum(parameter.numel() for parameter in self.context_projection.parameters()) if self.context_projection is not None else 0


def verify_initialization(task, seed):
    proof = load_proof(task)
    lit.seed_everything(seed, workers=True)
    native = proof.build()
    weights = {name: value.detach().clone() for name, value in native.named_parameters()}
    group.Decoder.__init__ = conditioned_init
    lit.seed_everything(seed, workers=True)
    candidate = proof.build()
    actual = dict(candidate.named_parameters())
    changed = [name for name, value in weights.items() if name not in actual or not torch.equal(value, actual[name])]
    if changed:
        raise AssertionError(f"Unexpected shared initialization change: {changed}")
    return {"all_common_parameters_identical": True, "common_parameter_tensors": len(weights), "additional_parameters": EXTRA_PARAMETERS}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=("p065", "p078"), required=True)
    parser.add_argument("--case", choices=("native", "conditioned"), required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    initialization = verify_initialization(args.task, args.seed)
    if args.case == "native":
        group.Decoder.__init__ = ORIGINAL_INIT
    started = time.monotonic()
    metrics, memory = (run_p065 if args.task == "p065" else run_p078)(args.seed)
    memory.update(
        fixed_codebook=None,
        persistent_extra_parameters=initialization["additional_parameters"] if args.case == "conditioned" else 0,
        persistent_extra_buffers=0,
    )
    result = {
        "task": args.task, "case": args.case, "seed": args.seed,
        "scope": "Validation-only; native Gumbel routing/raw tied scoring/original training budget. Only Group decoder sibling conditioning changes; embedder unchanged.",
        "initialization": initialization,
        "source_sha256": hashlib.sha256((ROOT / "src/relflow/tensorfields/extensions/group.py").read_bytes()).hexdigest(),
        "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "shared_harness_sha256": hashlib.sha256((ROOT / "experiment.py").read_bytes()).hexdigest(),
        "elapsed_seconds": time.monotonic() - started,
        "peak_process_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "memory": memory, "metrics": metrics,
    }
    path = ROOT / f"{args.task}-decoder-{args.case}-{args.seed}.json"
    path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("RESULT", path, flush=True)
    print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
