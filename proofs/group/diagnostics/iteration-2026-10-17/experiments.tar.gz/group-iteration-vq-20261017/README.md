# Group hard-routing / VQ validation experiment

This directory contains a frozen copy of the retained RelFlow source, original
P078/P065 proof sources, explicit runnable experimental code, and per-run JSON
and logs. Nothing here modifies production source or canonical proof results.

The frozen `group.py` SHA-256 is
`80429258fbc252530c049d1b02f31c5270b04dbcb723f60b790a8c57e7a5ae7c`.
`provenance.json` records every copied Python source hash and the checkout HEAD.
The checkout had uncommitted changes; the source hashes identify the actual
snapshot rather than implying that HEAD contains those changes.

Run using the existing environment:

```sh
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/experiment.py --task p078 --arm categorical-st --seed 7801
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/experiment.py --task p078 --arm simplex-ste --seed 7801
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/experiment.py --task p078 --arm simplex-commit --seed 7801
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/experiment.py --task p065 --arm simplex-commit --seed 7651
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/learned_vq.py --seed 7801
```

All runs use one CPU thread and their original training budgets: P078 has 600
AdamW updates, batch 128, LR .003, adaptive bounds `(2, 8)`, 10% reconstructing
identity masking, and 4096 train rows. P065 has 800 updates, batch 64, LR .002,
eight fixed groups, query-selected hidden targets and `p_unavailable=1`.

Only the original validation generators/splits are scored. P078 scores 1024
validation rows and their shuffled-ID dependency check; it does not train a
no-regime arm in this screening panel. P065's 1024 validation rows contain 512
hidden targets, so coverage subsets retain 512/256/51/0 known hidden targets
instead of the original test split's 1024/512/102/0. Accuracy thresholds are
unchanged. These are diagnostics, not full original-proof pass claims.

## First panel

`experiment.py` compares deterministic categorical straight-through routing
against a fixed-simplex quantizer in the same K-dimensional identity space.
Nearest unit-simplex prototype equals argmax; all forward assignments remain
hard. `simplex-ste` changes only the routing surrogate to identity. The separate
`simplex-commit` arm adds a fixed .25 commitment loss on exposed known identity
rows. Identity reconstruction loss, raw tied identity scores, writer, priors,
adaptive transitions and parameter storage are retained. This is a backward
geometry experiment, not a learned-codebook VQ model.

## Actual learned-codebook diagnostic

`learned_vq.py` uses K learned K-dimensional prototypes and existing V×K
identity latents, deterministic nearest prototypes, identity STE, .25
commitment, and EMA .99 centroid updates from unique exposed IDs per batch.
The prototypes start at the K unit vectors, with unit pseudo-counts, without
consuming additional RNG. No full-vocabulary regularizer or true group count
is supplied. Public assignment/occupancy reporting uses actual nearest codes.

This is explicitly a multiple-mechanism diagnostic: tied identity scores become
negative squared distances to prototypes, shared by reconstruction and writing;
the affinity is detached from identity/prototype parameters to prevent unique-ID
reconstruction from undoing task-driven sharing. State loss, vocabulary CE,
coverage/OOV rules, decoder balancing and statistics otherwise remain intact.
Legacy logit-column revival and merging are disabled because those operations
are invalid in geometric latent coordinates. The candidate has a capacity
ceiling of eight and makes no automatic-K claim. It adds no parameters but
stores 136 float32 buffer elements (544 bytes) for prototype/EMA state.

Peak RSS is process-wide macOS `ru_maxrss`, including the Python/ML framework.
It is not an isolated tensor allocator measurement or a throughput benchmark.
No failed screen is expanded to multiple seeds or promoted to production.

## Separate decoder-conditioning experiment

`conditioned_decoder.py` keeps native Gumbel routing and raw tied scoring. It
enables the shared DecoderBase sibling-context path only for the Group decoder;
the identity embedder and persistent assignments remain unchanged. Constructing
the new context projection inside a forked RNG context preserves every common
parameter and the training RNG. The harness asserts byte-identical common
parameter initialization, and reports the projection's added parameters.

```sh
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/conditioned_decoder.py --task p065 --case native --seed 7651
/Users/grantham/Desktop/relflow/.venv/bin/python /private/tmp/group-iteration-vq-20261017/conditioned_decoder.py --task p065 --case conditioned --seed 7651
```

The projection is additional model capacity; the experiment isolates its
presence from initialization drift, but does not claim equal parameter counts.
Enabling this path would intentionally change the existing Group decoder's
binding contract, which currently opts out of sibling query conditioning.
