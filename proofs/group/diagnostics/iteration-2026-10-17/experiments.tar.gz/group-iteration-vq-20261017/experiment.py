"""Validation-only hard-routing experiment on an immutable retained-source snapshot.

Run from any cwd with RelFlow's environment, for example:
  /Users/grantham/Desktop/relflow/.venv/bin/python experiment.py --task p078 --arm simplex-commit --seed 7801

Each invocation trains one model. No test split is generated or scored.
"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time
from functools import partial

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "proofs"))

import lightning.pytorch as lit
import numpy as np
import torch
import torch.nn.functional as F

import relflow as rf
from relflow.structs.enums import Component, Strata, TensorKey, Tokens
from relflow.structs.packages import Parcel
from relflow.tensorfields.extensions import group as extension_package
import importlib

group = importlib.import_module("relflow.tensorfields.extensions.group")
torch.set_num_threads(1)
torch.set_num_interop_threads(1)


def load_proof(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "proofs" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def install(arm):
    """Change only the hard-routing gradient and optional VQ commitment term."""
    original_loss = group.loss

    def forward(self, inputs):
        batch_size, *dims = inputs.state.shape
        state = inputs.state.reshape(-1)
        content = inputs.content.reshape(-1)
        valued = state.eq(Tokens.valued.value)
        if valued.any():
            selected = content.masked_select(valued)
            if ((selected < -1) | (selected >= self.capacity)).any().item():
                raise ValueError(f"Token in address {self.origin} outside [-1, {self.capacity})")
        indices = content.masked_fill(content.eq(-1), self.capacity).masked_fill(~valued, 0)
        vectors = self.embeddings[TensorKey.group.name](indices)
        scores = self.support(vectors)
        hard = F.one_hot(scores.argmax(-1), self.size).to(vectors.dtype)
        self.vq_commitment = vectors.new_zeros(())

        if self.training and arm == "categorical-st":
            soft = scores.softmax(-1)
            assignments = hard + soft - soft.detach()
        elif self.training:
            # Squared distance to each fixed unit-simplex prototype is
            # ||z||^2 + 1 - 2*z[k], so nearest-code selection equals argmax.
            # The hard forward values match categorical ST exactly. Only
            # the surrogate changes from a softmax Jacobian to identity.
            surrogate = vectors.masked_fill(self.retired, 0)
            assignments = hard + surrogate - surrogate.detach()
            exposed = valued & content.ge(0) & content.lt(self.capacity)
            if arm == "simplex-commit" and exposed.any():
                self.vq_commitment = 0.25 * F.mse_loss(
                    vectors[exposed][:, ~self.retired],
                    hard[exposed][:, ~self.retired].detach(),
                )
        else:
            assignments = hard

        assignments = assignments * valued.unsqueeze(-1)
        embeddings = (
            self.embeddings[TensorKey.state.name](state)
            + self.embeddings[TensorKey.content.name](assignments)
        ).reshape(batch_size, *dims, -1)
        return Parcel(
            payload=embeddings,
            present=torch.ones(batch_size, dtype=torch.bool, device=embeddings.device),
            origin=self.origin,
            destination=self.destination,
            batch_size=batch_size,
        )

    def loss(module, prediction, batch, strata):
        result = original_loss(module, prediction, batch, strata)
        if strata == Strata.train:
            result = result + module.nodes[prediction.address].embedder.vq_commitment
        return result

    group.Embedder.forward = forward
    group.group.components[Component.loss] = loss


def trainer(steps):
    return lit.Trainer(
        accelerator="cpu", devices=1, max_steps=steps, max_epochs=-1,
        logger=False, enable_checkpointing=False, enable_progress_bar=False,
        enable_model_summary=False, deterministic=True, num_sanity_val_steps=0,
    )


def storage(model, address):
    embedder = model.nodes[address].embedder
    weights = embedder.embeddings[TensorKey.group.name].weight
    return {
        "parameters_total": sum(p.numel() for p in model.parameters()),
        "identity_assignment_shape": list(weights.shape),
        "identity_assignment_bytes": weights.numel() * weights.element_size(),
        "persistent_extra_parameters": 0,
        "persistent_extra_buffers": 0,
        "fixed_codebook": "implicit K unit vectors; no stored codebook",
    }


def run_p078(seed):
    proof = load_proof("p078")
    lit.seed_everything(seed, workers=True)
    model = proof.build()
    options = {"partition_seed": seed * 100, "no_regime": False}
    data = rf.SyntheticDataModule(
        model=model,
        train=partial(proof.records, rows=4096, seed=seed * 100 + 1, **options),
        validate=partial(proof.records, rows=1024, seed=seed * 100 + 2, **options),
        seed=seed,
    )
    fit = trainer(600)
    fit.fit(model, datamodule=data)
    model.eval()
    before = rf.Group.assignments(model, "/entity")
    training_mean = float(np.mean([row["y"] for row in proof.records(rows=4096, seed=seed * 100 + 1, **options)]))
    rows = list(proof.records(rows=1024, seed=seed * 100 + 2, **options))
    metrics = proof.measure(model, rows, training_mean, seed * 100)
    shuffled = list(proof.records(rows=1024, seed=seed * 100 + 2, partition_seed=seed * 100, no_regime=True))
    metrics["shuffled_validation"] = proof.measure(model, shuffled, training_mean, seed * 100)
    metrics["steps"] = fit.global_step
    metrics["evaluation_frozen"] = before == rf.Group.assignments(model, "/entity")
    metrics["validation_gates"] = {
        "ARI_at_least_0.8": metrics["adjusted_rand"] >= 0.8,
        "normalized_RMSE_at_most_0.35": metrics["normalized_rmse"] <= 0.35,
        "all_64_IDs": metrics["assigned_entities"] == 64,
        "shuffled_normalized_RMSE_at_least_0.85": metrics["shuffled_validation"]["normalized_rmse"] >= 0.85,
        "shuffled_increase_at_least_0.4": metrics["shuffled_validation"]["normalized_rmse"] - metrics["normalized_rmse"] >= 0.4,
        "evaluation_frozen": metrics["evaluation_frozen"],
    }
    return metrics, storage(model, "/entity")


def run_p065(seed):
    proof = load_proof("p065")
    lit.seed_everything(seed, workers=True)
    model = proof.build()
    data = rf.SyntheticDataModule(
        model=model,
        train=partial(proof.records, rows=8192, seed=seed + 1),
        validate=partial(proof.records, rows=1024, seed=seed + 2), seed=seed,
    )
    fit = trainer(800)
    fit.fit(model, datamodule=data)
    original = list(proof.records(rows=1024, seed=seed + 2))
    vocabulary = rf.Group.vocabulary(model, "/code")
    counts = model.nodes["/code"].embedder.counters["content"].counts.clone()
    result = {"steps": fit.global_step, "split": "original 1024-row validation; 512 hidden targets"}
    for keep in (512, 256, 51, 0):
        selected = 0
        rows = []
        for row in original:
            unavailable = row["hide"] and selected >= keep
            rows.append({**row, "code": f"novel-{row['code']}" if unavailable else row["code"]})
            selected += int(row["hide"])
        measured = proof.evaluate(fit, model, rows)
        result[f"known_{keep}"] = {name: value if np.isfinite(value) else None for name, value in measured.items()}
        if keep == 51:
            permuted = [rows[index] for index in np.random.default_rng(seed + 4).permutation(len(rows))]
            regrouped = proof.evaluate(fit, model, permuted)
            names = ("targets.known", "targets.unavailable", "coverage.content", "accuracy.content", "accuracy.all", "nll.content", "loss.content")
            result["batch_partition_drift"] = max(abs(measured[name] - regrouped[name]) for name in names)
    result["evaluation_frozen"] = rf.Group.vocabulary(model, "/code") == vocabulary and torch.equal(counts, model.nodes["/code"].embedder.counters["content"].counts)
    result["validation_accuracy_gates"] = {str(keep): result[f"known_{keep}"].get("accuracy.content", -1) > 0.95 for keep in (512, 256, 51)}
    return result, storage(model, "/code")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=("p078", "p065"), required=True)
    parser.add_argument("--arm", choices=("categorical-st", "simplex-ste", "simplex-commit"), required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    install(args.arm)
    started = time.monotonic()
    metrics, memory = (run_p078 if args.task == "p078" else run_p065)(args.seed)
    result = {
        "task": args.task, "arm": args.arm, "seed": args.seed,
        "scope": "validation only; no test rows generated; original training budget/generator/configuration",
        "source_sha256": hashlib.sha256((ROOT / "src/relflow/tensorfields/extensions/group.py").read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "torch_version": torch.__version__, "python_version": sys.version,
        "threads": torch.get_num_threads(), "elapsed_seconds": time.monotonic() - started,
        "peak_process_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "memory": memory, "metrics": metrics,
    }
    output = ROOT / f"{args.task}-{args.arm}-{args.seed}.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("RESULT", output, flush=True)
    print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
