"""One conditional-query + balanced/ST/proper-mixture P065 validation probe."""

import hashlib
import importlib.util
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
BASE = Path("/private/tmp/group-iteration-mixture-20261017/run_balanced.py")
spec = importlib.util.spec_from_file_location("balanced_mixture_source", BASE)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
original_init = base.group.Decoder.__init__
extra_parameters = 0


def conditioned_init(self, schema, address):
    global extra_parameters
    original_init(self, schema, address)
    with base.torch.random.fork_rng(devices=[]):
        conditioned = base.group.DecoderBase(schema=schema, address=address, conditioned=True)
    self.context_addresses = conditioned.context_addresses
    self.aligned_addresses = conditioned.aligned_addresses
    self.context_projection = conditioned.context_projection
    extra_parameters = sum(p.numel() for p in self.context_projection.parameters()) if self.context_projection is not None else 0


if __name__ == "__main__":
    base.group.Decoder.__init__ = conditioned_init
    started = time.monotonic()
    result = base.run("p065", "mixture", 7651)
    result.update(
        case="balanced-st-mixture-conditioned",
        scope="Single validation-only combined diagnostic; no teacher loss; original 800 updates, mask/coverage rules. Root balanced .1/ST/proper-mixture harness plus Group decoder sibling conditioning, common-weight RNG preserved.",
        extra_parameters=extra_parameters,
        elapsed_total_seconds=time.monotonic() - started,
        harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        base_harness_sha256=hashlib.sha256(BASE.read_bytes()).hexdigest(),
        provenance=json.loads((BASE.parent / "provenance.json").read_text()),
    )
    path = ROOT / "p065-decoder-conditioned-balanced-mixture-7651.json"
    path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("RESULT", path, flush=True)
    print(json.dumps(result, allow_nan=False), flush=True)
