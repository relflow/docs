"""One actual EMA-codebook VQ diagnostic; validation only, no production edits.

This is explicitly a multiple-mechanism fork: deterministic nearest codes,
identity STE, commitment, EMA prototypes, detached tied ID affinities, and
disabled legacy logit-column merge/revival. It does not prove adaptive K.
"""

from experiment import (
    ROOT, Component, F, Strata, TensorKey, Tokens, Parcel,
    group, rf, run_p078, torch,
)
import argparse
import hashlib
import json
from pathlib import Path
import resource
import time


def distances(vectors, codes):
    return vectors.square().sum(-1, keepdim=True) + codes.square().sum(-1).unsqueeze(0) - 2 * vectors @ codes.T


def identity_scores(embedder, vectors):
    return embedder.support(-distances(vectors.float(), embedder.vq_codes.float()))


def install():
    original_init = group.Embedder.__init__
    original_loss = group.loss

    def init(self, schema, address):
        original_init(self, schema, address)
        # Identity initialization consumes no RNG and supplies eight candidate
        # codes, not the hidden answer of four regimes.
        self.register_buffer("vq_codes", torch.eye(self.size))
        self.register_buffer("vq_counts", torch.ones(self.size))
        self.register_buffer("vq_sums", torch.eye(self.size))

    def forward(self, inputs):
        batch_size, *dims = inputs.state.shape
        state = inputs.state.reshape(-1)
        content = inputs.content.reshape(-1)
        valued = state.eq(Tokens.valued.value)
        if valued.any():
            selected_ids = content[valued]
            if ((selected_ids < -1) | (selected_ids >= self.capacity)).any().item():
                raise ValueError(f"Token in address {self.origin} outside [-1, {self.capacity})")
        indices = content.masked_fill(content.eq(-1), self.capacity).masked_fill(~valued, 0)
        vectors = self.embeddings[TensorKey.group.name](indices)
        with torch.no_grad():
            assignments = identity_scores(self, vectors).argmax(-1)
            selected_codes = F.embedding(assignments, self.vq_codes)
        if self.training:
            quantized = vectors + (selected_codes - vectors).detach()
        else:
            quantized = selected_codes
        quantized = quantized * valued.unsqueeze(-1)
        self.vq_commitment = vectors.new_zeros(())
        exposed = valued & content.ge(0) & content.lt(self.capacity)
        if self.training and exposed.any():
            self.vq_commitment = 0.25 * F.mse_loss(vectors[exposed], selected_codes[exposed].detach())
            # Update from exposed IDs only, not a full-vocabulary scan. One
            # identity contributes once to a minibatch's centroid statistics.
            with torch.no_grad():
                unique_ids = indices[exposed].unique()
                observed = self.embeddings[TensorKey.group.name](unique_ids).detach()
                nearest = identity_scores(self, observed).argmax(-1)
                counts = F.one_hot(nearest, self.size).to(observed.dtype)
                self.vq_counts.mul_(0.99).add_(counts.sum(0), alpha=0.01)
                self.vq_sums.mul_(0.99).add_(counts.T @ observed, alpha=0.01)
                self.vq_codes.copy_(self.vq_sums / self.vq_counts[:, None].clamp_min(1e-6))
        embeddings = (
            self.embeddings[TensorKey.state.name](state)
            + self.embeddings[TensorKey.content.name](quantized)
        ).reshape(batch_size, *dims, -1)
        return Parcel(
            payload=embeddings,
            present=torch.ones(batch_size, dtype=torch.bool, device=embeddings.device),
            origin=self.origin, destination=self.destination, batch_size=batch_size,
        )

    def vocabulary_logits(embedder, probabilities):
        # Identical affinity is used by reconstruction and writing. Keep ID
        # reconstruction from repelling identities that share task behavior.
        rows = embedder.embeddings[TensorKey.group.name].weight[:len(embedder.vocab.master)]
        scores = identity_scores(embedder, rows).detach()
        available = ~embedder.retired
        return probabilities[:, available].float() @ scores[:, available].T

    def loss(module, prediction, batch, strata):
        result = original_loss(module, prediction, batch, strata)
        if strata == Strata.train:
            result = result + module.nodes[prediction.address].embedder.vq_commitment
        return result

    @classmethod
    def assignments(cls, model, address):
        embedder = group.resolve_group_embedder(model, address)
        with embedder.vocab.lock:
            vocabulary = tuple(embedder.vocab.master)
            rows = embedder.embeddings[TensorKey.group.name].weight[:len(vocabulary)].detach()
            scores = identity_scores(embedder, rows)
            probabilities = scores.softmax(-1).cpu().tolist()
            nearest = scores.argmax(-1).cpu().tolist()
        return {
            token: {"group": code, "probabilities": tuple(float(p) for p in row)}
            for token, code, row in zip(vocabulary, nearest, probabilities, strict=True)
        }

    group.Embedder.__init__ = init
    group.Embedder.forward = forward
    group.Request.assignments = assignments
    group.vocabulary_logits = vocabulary_logits
    group.group.components[Component.loss] = loss
    # These transitions edit logit columns; they do not have a coherent meaning
    # for geometric latent coordinates or EMA state. Disable, don't emulate.
    group.GroupReviveCallback.plan = staticmethod(lambda *args, **kwargs: None)
    group.GroupMergeCallback.plan = staticmethod(lambda *args, **kwargs: None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=7801)
    args = parser.parse_args()
    install()
    started = time.monotonic()
    metrics, memory = run_p078(args.seed)
    memory.update(
        persistent_extra_parameters=0,
        persistent_extra_buffers=3,
        persistent_extra_buffer_elements=8 * 8 * 2 + 8,
        persistent_extra_buffer_bytes=(8 * 8 * 2 + 8) * 4,
        fixed_codebook=None,
        learned_codebook_shape=[8, 8],
        codebook_update="EMA 0.99 over unique exposed IDs per batch; unit initial pseudo-counts",
    )
    result = {
        "task": "p078", "arm": "learned-ema-vq-detached-affinity", "seed": args.seed,
        "scope": "Validation only; 600 original updates/generator/model configuration; capacity ceiling eight; no true K supplied. No adaptive transitions or adaptive-K claim.",
        "mechanisms": ["hard nearest learned K-dimensional codes", "identity STE", "0.25 commitment", "EMA 0.99", "detached distance-based ID affinities shared by loss/writer", "legacy merge/revival disabled"],
        "source_sha256": hashlib.sha256((ROOT / "src/relflow/tensorfields/extensions/group.py").read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "shared_experiment_sha256": hashlib.sha256((ROOT / "experiment.py").read_bytes()).hexdigest(),
        "elapsed_seconds": time.monotonic() - started,
        "peak_process_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "memory": memory, "metrics": metrics,
    }
    output = ROOT / f"p078-learned-ema-vq-{args.seed}.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("RESULT", output, flush=True)
    print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
