"""One frozen prior-mixture plus predictive-reassignment arm; no old test rows."""

# ruff: noqa: E402

import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
import platform
import sys
import time
from functools import partial
from pathlib import Path
from unittest.mock import patch

for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[name] = "1"
ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / "snapshot/src"), str(ROOT / "shared")]

import lightning.pytorch as lit
import numpy as np
import torch

import relflow as rf
from relflow.tensorfields.extensions import group

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


P079, P080 = load("p079"), load("p080")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def provenance():
    source = hashlib.sha256()
    package = ROOT / "snapshot/src/relflow"
    for path in sorted(package.rglob("*.py")):
        source.update(("src/relflow/" + path.relative_to(package).as_posix()).encode())
        source.update(path.read_bytes())
    return {
        "harness_sha256": digest(__file__),
        "protocol_sha256": digest(ROOT / "protocol.json"),
        "p079_sha256": digest(ROOT / "p079.py"),
        "p080_sha256": digest(ROOT / "p080.py"),
        "source_tree_sha256": source.hexdigest(),
        "prior_source_sha256": digest(ROOT / "run_balanced_original.py"),
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "threads": torch.get_num_threads(),
    }


def hard(logits, tau=1.0, hard=False, eps=1e-10, dim=-1):
    soft = (logits / tau).softmax(dim)
    onehot = torch.zeros_like(soft).scatter_(dim, soft.argmax(dim, keepdim=True), 1)
    return onehot - soft.detach() + soft


def mixture(embedder, probabilities):
    """P(identity|context) sums normalized P(identity|group) over predicted groups."""
    available = ~embedder.retired
    weights = embedder.embeddings["group"].weight[: len(embedder.vocab.master), available].float()
    conditional = weights.log_softmax(dim=0)
    predicted = probabilities[:, available].float().clamp_min(1e-30).log()
    return torch.logsumexp(predicted[:, None, :] + conditional[None, :, :], dim=-1)


@contextlib.contextmanager
def changes():
    # Exact init/grow mathematics from the previous run_balanced.py.
    initial = group.Embedder.__init__
    resize = group.Embedder.resize
    scale = 0.1

    def init(self, *args, **kwargs):
        initial(self, *args, **kwargs)
        with torch.no_grad():
            weights = self.embeddings["group"].weight
            weights.zero_()
            weights[:-1].scatter_(1, (torch.arange(weights.shape[0] - 1) % weights.shape[1]).unsqueeze(1), scale)

    def grow(self, size, plan):
        previous = self.embeddings["group"].weight
        resize(self, size, plan)
        with torch.no_grad():
            for old, new in plan.parameters:
                if old is previous:
                    start = old.shape[0] - 1
                    stop = new.shape[0] - 1
                    new[start:stop].zero_()
                    new[start:stop].scatter_(1, (torch.arange(start, stop) % new.shape[1]).unsqueeze(1), scale)

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(group.Embedder, "__init__", init))
        stack.enter_context(patch.object(group.Embedder, "resize", grow))
        stack.enter_context(patch("torch.nn.functional.gumbel_softmax", hard))
        stack.enter_context(patch.object(group, "vocabulary_logits", mixture))
        yield


def state(model):
    return {name: value.detach().clone() for name, value in (*model.named_parameters(), *model.named_buffers())}


def frozen(model, before):
    return all(torch.equal(value, before[name]) for name, value in (*model.named_parameters(), *model.named_buffers()))


def evaluate_numeric(model, rows, mean, seed, case):
    assignments = rf.Group.assignments(model, "/entity")
    membership = np.asarray([assignments[f"entity-{i:04d}"]["group"] for i in range(64)])
    measured = P079.measure(P079.predict(model, rows), rows, mean)
    measured.update(
        adjusted_rand=P079.adjusted_rand(P079.partition(seed, case), membership),
        occupied_groups=len(np.unique(membership)),
        assigned_ids=len(assignments),
        assignments=membership.tolist(),
    )
    return measured


def gates(kind, case, measured, shuffled=None):
    checks = {"ARI_at_least_0.8": measured["adjusted_rand"] >= 0.8}
    if kind == "numeric":
        checks.update(
            normalized_RMSE_at_most_0_35=measured["normalized_rmse"] <= 0.35,
            exact_occupied_groups=measured["occupied_groups"] == len(P079.CASES[case]["populations"]),
            all_known_IDs=measured["assigned_ids"] == 64,
            finite=bool(np.isfinite([measured["normalized_rmse"], measured["adjusted_rand"]]).all()),
        )
        if shuffled is not None:
            checks.update(
                shuffled_nRMSE_at_least_0_85=shuffled["normalized_rmse"] >= 0.85,
                shuffled_error_increase_at_least_0_4=shuffled["normalized_rmse"] - measured["normalized_rmse"] >= 0.4,
            )
    else:
        checks.update(
            accuracy_at_least_0_9=measured["accuracy"] >= 0.9,
            exact_occupied_groups=measured["occupied_groups"] == 5,
            all_known_IDs=measured["assigned_ids"] == 50,
            all_target_classes=measured["known_target_classes"] == 5,
            finite=bool(np.isfinite([measured["accuracy"], measured["nll"], measured["adjusted_rand"]]).all()),
        )
        if shuffled is not None:
            checks.update(
                shuffled_accuracy_at_most_0_3=shuffled["accuracy"] <= 0.3,
                shuffled_accuracy_drop_at_least_0_5=measured["accuracy"] - shuffled["accuracy"] >= 0.5,
            )
    return checks


def train_one(kind, case, seed):
    lit.seed_everything(seed, workers=True)
    proof = P079 if kind == "numeric" else P080
    if kind == "numeric":
        train, _ = proof.generate(seed, case, 1, 4096)
        validate, _ = proof.generate(seed, case, 2, 1024)
    else:
        train = list(proof.records(rows=5000, seed=seed * 100 + 1, partition_seed=seed * 100))
        validate = list(proof.records(rows=2000, seed=seed * 100 + 2, partition_seed=seed * 100))
    with changes():
        model = proof.build()
        callback = (
            proof.PredictiveGrouping(train, validate)
            if kind == "numeric"
            else proof.Reassignment(train, validate, search=True)
        )
        data = rf.SyntheticDataModule(
            model=model, train=partial(iter, train), validate=partial(iter, validate), seed=seed
        )
        trainer = lit.Trainer(
            accelerator="cpu",
            devices=1,
            max_steps=600,
            max_epochs=-1,
            callbacks=[callback],
            logger=False,
            enable_checkpointing=False,
            enable_progress_bar=False,
            enable_model_summary=False,
            deterministic=True,
            num_sanity_val_steps=0,
        )
        tick = time.perf_counter()
        trainer.fit(model, datamodule=data)
        model.eval()
        event = (
            proof.reassignment(model, train, validate, trainer.optimizers)
            if kind == "numeric"
            else proof.intervene(model, train, validate, trainer.optimizers, search=True)
        )
        callback.events.append({"step": 600, **event})
        fit_seconds = time.perf_counter() - tick
        assert trainer.global_step == 600
        mean = float(np.mean([row["y"] for row in train])) if kind == "numeric" else None
        majority = (
            None
            if kind == "numeric"
            else max((f"class-{i}" for i in range(5)), key=lambda value: sum(row["outcome"] == value for row in train))
        )
        before = state(model)
        address = "/entity" if kind == "numeric" else "/merchant_id"
        assigned = rf.Group.assignments(model, address)
        vocabulary = rf.Group.vocabulary(model, address)
        measured = (
            evaluate_numeric(model, validate, mean, seed, case)
            if kind == "numeric"
            else proof.measure(model, validate, proof.partition(seed * 100), majority)
        )
        assert frozen(model, before)
        assert assigned == rf.Group.assignments(model, address)
        assert vocabulary == rf.Group.vocabulary(model, address)
        checkpoint = ROOT / "checkpoints" / f"{kind}-{case}-{seed}.ckpt"
        checkpoint.parent.mkdir(exist_ok=True)
        model.save(checkpoint)
        return {
            "kind": kind,
            "case": case,
            "seed": seed,
            "optimizer_updates": trainer.global_step,
            "training_and_intervention_wall_seconds": fit_seconds,
            "events": callback.events,
            "training_mean": mean,
            "majority_label": majority,
            "checkpoint": str(checkpoint.relative_to(ROOT)),
            "checkpoint_sha256": digest(checkpoint),
            "validation": measured,
            "validation_gates": gates(kind, case, measured),
            "evaluation_frozen": True,
        }


def train():
    output = ROOT / "validation.json"
    if output.exists():
        raise FileExistsError(output)
    result = {"phase": "validation only; no old or fresh test rows generated", "provenance": provenance(), "runs": []}
    tasks = [("numeric", case, seed) for seed in (7901, 7902, 7903) for case in ("crossing_four", "separated_six")]
    tasks += [("categorical", "contextual_labels", seed) for seed in (8001, 8002, 8003)]
    for task in tasks:
        row = train_one(*task)
        result["runs"].append(row)
        output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        print(
            "VALIDATION",
            json.dumps({"task": task, "metrics": row["validation"], "gates": row["validation_gates"]}),
            flush=True,
        )


def audit():
    output = ROOT / "fresh-audit.json"
    if output.exists():
        raise FileExistsError(output)
    validated = json.loads((ROOT / "validation.json").read_text())
    assert validated["provenance"] == provenance()
    assert len(validated["runs"]) == 9 and all(row["optimizer_updates"] == 600 for row in validated["runs"])
    result = {
        "phase": "fresh holdout after all nine original-budget development fits",
        "provenance": provenance(),
        "validation_sha256": digest(ROOT / "validation.json"),
        "runs": [],
    }
    for row in validated["runs"]:
        kind, case, seed = row["kind"], row["case"], row["seed"]
        checkpoint = ROOT / row["checkpoint"]
        assert digest(checkpoint) == row["checkpoint_sha256"]
        with changes():
            model = rf.Model.load(checkpoint)
            model.eval()
            address = "/entity" if kind == "numeric" else "/merchant_id"
            before = state(model)
            assigned = rf.Group.assignments(model, address)
            vocabulary = rf.Group.vocabulary(model, address)
            if kind == "numeric":
                rows, _ = P079.generate(seed, case, 10003, 2048)
                shuffled, _ = P079.generate(seed, case, 10003, 2048, shuffle=True)
                measured = evaluate_numeric(model, rows, row["training_mean"], seed, case)
                corrupted = P079.measure(P079.predict(model, shuffled), shuffled, row["training_mean"])
            else:
                rows = list(P080.records(rows=2500, seed=seed * 100 + 503, partition_seed=seed * 100))
                shuffled = list(
                    P080.records(rows=2500, seed=seed * 100 + 503, partition_seed=seed * 100, no_regime=True)
                )
                measured = P080.measure(model, rows, P080.partition(seed * 100), row["majority_label"])
                corrupted = P080.measure(model, shuffled, P080.partition(seed * 100), row["majority_label"])
            checks = gates(kind, case, measured, corrupted)
            checks["evaluation_parameters_buffers_vocabulary_assignments_frozen"] = (
                frozen(model, before)
                and assigned == rf.Group.assignments(model, address)
                and vocabulary == rf.Group.vocabulary(model, address)
            )
            item = {**row, "fresh_holdout": measured, "fresh_shuffled": corrupted, "fresh_gates": checks}
            result["runs"].append(item)
            output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
            print(
                "FRESH",
                json.dumps({"kind": kind, "case": case, "seed": seed, "metrics": measured, "gates": checks}),
                flush=True,
            )


def regression():
    import pytest

    test = "/Users/grantham/Desktop/relflow/tests/tensorfields/extensions/test_group_state.py"
    with patch.object(group, "vocabulary_logits", mixture):
        status = pytest.main(
            [
                "-q",
                "-o",
                "addopts=",
                "--confcutdir=/Users/grantham/Desktop/relflow",
                test + "::test_single_group_preserves_nonuniform_learned_identity_priors",
                test + "::test_bfloat16_writer_and_reconstruction_metrics_choose_the_same_identity",
            ]
        )
    assert status == 0
    (ROOT / "regression.json").write_text(
        json.dumps(
            {
                "provenance": provenance(),
                "checks": "Existing one-group90/10learned-prior and bf16writer/loss consistency tests passed",
                "exit_code": int(status),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("regression", "train", "audit"))
    options = parser.parse_args()
    {"regression": regression, "train": train, "audit": audit}[options.phase]()
