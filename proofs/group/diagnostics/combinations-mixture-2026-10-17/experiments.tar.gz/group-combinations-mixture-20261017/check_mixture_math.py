"""Independent direct-path checks; does not change the frozen training harness."""

import hashlib
import importlib.util
import json
import math
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("frozen_mixture_addon", ROOT / "run.py")
experiment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(experiment)
torch = experiment.torch

rows = []
for dtype in (torch.float32, torch.bfloat16):
    weights = torch.tensor([[math.log(.9)], [math.log(.1)]], dtype=dtype, requires_grad=True)
    probabilities = torch.ones((3, 1), dtype=dtype)
    embedder = SimpleNamespace(
        retired=torch.zeros(1, dtype=torch.bool),
        embeddings={"group": SimpleNamespace(weight=weights)},
        vocab=SimpleNamespace(master=("common", "rare")),
    )
    logits = experiment.mixture(embedder, probabilities)
    analytic = weights.float().log_softmax(dim=0).T.expand(3, 2)
    posterior = logits.softmax(-1)
    nll = torch.nn.functional.cross_entropy(logits, torch.zeros(3, dtype=torch.int64))
    assert logits.dtype == torch.float32
    assert torch.equal(logits, analytic)
    tolerance = 1e-6 if dtype == torch.float32 else .003
    assert torch.allclose(posterior, torch.tensor([[.9, .1]]).expand(3, 2), atol=tolerance, rtol=0)
    assert abs(float(nll.detach()) + math.log(.9)) < tolerance
    assert logits.argmax(-1).eq(0).all() and posterior.argmax(-1).eq(0).all()
    nll.backward()
    assert torch.isfinite(weights.grad).all()
    rows.append({
        "input_dtype": str(dtype),
        "scorer_output_dtype": str(logits.dtype),
        "posterior": posterior.detach()[0].tolist(),
        "target_nll": float(nll.detach()),
        "analytical_column_normalized_log_likelihood_exactly_matches": True,
        "argmax_and_probability_readout_agree": True,
        "finite_gradient": True,
    })

frozen = json.loads((ROOT / "freeze.json").read_text())
assert hashlib.sha256((ROOT / "run.py").read_bytes()).hexdigest() == frozen["harness_sha256"]
assert hashlib.sha256((ROOT / "protocol.json").read_bytes()).hexdigest() == frozen["protocol_sha256"]
result = {
    "scope": "Direct calls to the exact frozen experimental mixture function, not baseline raw scoring",
    "checks": rows,
    "separate_existing_regressions": {
        "method": "run.py regression() calls pytest.main inside patch.object(group, vocabulary_logits, mixture)",
        "count": 2,
        "log_sha256": hashlib.sha256((ROOT / "regression.log").read_bytes()).hexdigest(),
    },
    "harness_and_protocol_unchanged": True,
}
(ROOT / "mixture-path-check.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
