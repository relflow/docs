# Matched predictive-EM CPU timing

No timed run begins until the parent explicitly confirms training is idle in
every other agent. The driver requires an explicit isolation flag. The package
is frozen at source SHA
`4f900097c5f12eb6eef07e88b7abba5c61089f52696d52ee8c08d105894a5b58`.

`cost/proofs/group/reassignment_cost.py` is a self-contained canonical-layout
P081 proof with ordinary `run(seed, steps, accelerator)` and shared `report`.
Its `arrays`, `neural_predict`, and `intervene` functions are copied directly
from `predictive_em_v1_original.py` with no numerical edits. The original file
and all source are retained beside the protocol. No runtime source is patched.

Three paired seeds 7801/7802/7803 run six measured fits, with arm order
native/candidate, candidate/native, native/candidate. Two excluded two-update
warmup fits use seed 7799, one per arm. Every measured fit resets the original
native seed before model construction. No isolated substitute RNG or modified
initialization is used. CPU Torch intra-op and inter-op thread counts are one.
Matching audit callbacks hash initial and first-bound parameters, input rows,
all ordered batches and masks, and the native Torch random state before every
one of the first 200 updates. Regular validation row counts, batch counts, and
update positions must match. Native retains normal extension callbacks but no
experimental reassignment callback. The audit overhead is identical in both.

Each arm trains 600 batches of 128 (76,800 rows), with original 4,096 train /
1,024 validation observations, adaptive bounds (2,8), AdamW lr .003, and the
P078 reconstruction mask. Candidate interventions occur at updates 200/400/600.
Each tests every currently available group on all train rows, then accepts
only a lower validation MSE; it preserves the raw per-identity log row mass and
resets matching optimizer history when accepted. The complete method, including
the final intervention after Trainer.fit, is timed. Expected extra work is
98,304 training counterfactual forward rows + 6,144 selection-validation forward
rows if all eight groups remain available. Actual available groups and counts
are recorded, not inferred. Ordinary validation is counted independently.

Construction, fit (including 200/400 events), terminal reassignment at 600, and
final assignment/validation readout have separate wall timers. Primary wall
time is `fit + terminal_reassignment`. No checkpoint saving or result I/O occurs
inside these timers. Event wall time is measured inside the unchanged v1
intervention and excludes result writing. Ratios are reported as both a
fraction for the docs percentage formatter and a human percentage:

    increase = candidate_wall / native_wall - 1
    percent = 100 * increase

Also record `events / candidate_wall` and
`events / (candidate_wall - events)` with distinct names. Neither is the matched
native comparison. This is wall time on this CPU, not an exact FLOP, GPU-cost,
or universal throughput estimate. The forward-row counts do not equate a
forward pass to a training forward/backward update. Validation quality and ARI
are reported as diagnostics; correctness gates cover matched workload,
initialization, randomness, finite timings/values, exact budgets and frozen
evaluation. No arbitrary speed threshold is imposed. No test rows are created.

After isolation approval, run from the package checkout:

```bash
.venv/bin/python /private/tmp/group-expansion-20261017/run_cost_panel.py \
  --timing-isolation-confirmed \
  --output /private/tmp/group-expansion-20261017/matched-cost.json \
  > /private/tmp/group-expansion-20261017/matched-cost.log 2>&1
```

Full reporter rows append only to the local staging registry
`cost/proofs/results.yaml`. Parent integrates the P081 script and rows into the
review docs checkout after audit. No commits, pushes, or publication occur here.
