"""Information boundaries and transactional updates in the experimental P079 callback."""

import importlib.util
import sys
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "proofs"))


def load():
    spec = importlib.util.spec_from_file_location("predictive_regimes", ROOT / "proofs/group/predictive_regimes.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize(
    "case", ("separated_four", "crossing_four", "imbalanced_four", "separated_three", "separated_six")
)
def test_generating_partition_stays_outside_inputs_and_shuffling_preserves_numeric_pairs(case):
    proof = load()
    rows, groups = proof.generate(7901, case, 1, 4096)
    shuffled, shuffled_groups = proof.generate(7901, case, 1, 4096, shuffle=True)
    validation, _ = proof.generate(7901, case, 2, 4096)
    assert rows == proof.generate(7901, case, 1, 4096)[0]
    assert rows != validation
    assert all(set(row) == {"entity", "x", "y"} for row in rows)
    assert Counter(proof.partition(7901, case)) == dict(enumerate(proof.CASES[case]["populations"]))
    assert Counter(row["entity"] for row in rows) == Counter(row["entity"] for row in shuffled)
    assert [(row["x"], row["y"]) for row in rows] == [(row["x"], row["y"]) for row in shuffled]
    np.testing.assert_array_equal(groups, shuffled_groups)
    assert rows != shuffled


def fixture(proof, monkeypatch):
    """A two-group decoder with opposite slopes and exactly equal response means."""
    weight = torch.nn.Parameter(torch.tensor([[2.0, 0.0], [2.0, 0.0], [-3.0, -4.0]]))
    embedder = SimpleNamespace(
        embeddings={"group": SimpleNamespace(weight=weight)}, retired=torch.zeros(2, dtype=torch.bool), size=2
    )
    model = SimpleNamespace(nodes={"/entity": SimpleNamespace(embedder=embedder)})
    optimizer = torch.optim.AdamW([weight])
    optimizer.state[weight] = {
        "step": torch.tensor(4.0),
        "exp_avg": torch.ones_like(weight),
        "exp_avg_sq": torch.ones_like(weight),
    }
    vocabulary = ["opaque-a", "opaque-b"]
    monkeypatch.setattr(proof.rf.Group, "vocabulary", lambda model, address: vocabulary)

    def predict(model, rows):
        group = weight.detach().argmax(-1).numpy()
        return np.asarray([(1.0 if group[vocabulary.index(row["entity"])] == 0 else -1.0) * row["x"] for row in rows])

    monkeypatch.setattr(proof, "predict", predict)
    train = [
        {"entity": entity, "x": x, "y": slope * x}
        for entity, slope in zip(vocabulary, (1.0, -1.0), strict=True)
        for x in (-1.0, 1.0)
    ]
    validation = [{"entity": row["entity"], "x": row["x"] / 2, "y": row["y"] / 2} for row in train]
    return model, optimizer, weight, train, validation


def test_reassignment_uses_conditional_errors_and_preserves_unreplaced_optimizer_state(monkeypatch):
    proof = load()
    model, optimizer, weight, train, validation = fixture(proof, monkeypatch)
    previous = weight.detach().clone()
    assert all(
        np.mean([row["y"] for row in train if row["entity"] == entity]) == 0 for entity in ("opaque-a", "opaque-b")
    )
    event = proof.reassignment(model, train, validation, [optimizer])
    assert event["accepted"]
    assert event["proposed_validation_mse"] == 0.0
    assert weight[:2].argmax(-1).tolist() == [0, 1]
    torch.testing.assert_close(weight[:2].logsumexp(-1), previous[:2].logsumexp(-1))
    assert torch.equal(weight[2], previous[2])
    assert optimizer.state[weight]["step"].item() == 4
    for name in ("exp_avg", "exp_avg_sq"):
        assert not optimizer.state[weight][name][:2].any()
        assert optimizer.state[weight][name][2].tolist() == [1.0, 1.0]
    assert event["training_rows_evaluated"] == 2 * len(train)
    assert event["validation_rows_evaluated"] == 2 * len(validation)


def test_validation_rejection_preserves_assignment_and_optimizer_history(monkeypatch):
    proof = load()
    model, optimizer, weight, train, validation = fixture(proof, monkeypatch)
    validation = [{**row, "y": row["x"]} for row in validation]
    previous = weight.detach().clone()
    history = {name: value.clone() for name, value in optimizer.state[weight].items()}
    event = proof.reassignment(model, train, validation, [optimizer])
    assert not event["accepted"]
    assert event["before_validation_mse"] == 0.0
    assert event["proposed_validation_mse"] > 0.0
    assert torch.equal(weight, previous)
    assert all(torch.equal(value, history[name]) for name, value in optimizer.state[weight].items())
