# Predictive-EM matched CPU wall-time result

Predictive EM added **28.60% wall time** across three paired seeds on this machine. Native averaged 10.070s and EM 12.950s for 600 updates plus all three reassignment events. This is a wall-time measurement, not an exact FLOP estimate.

| Seed | Arm order | Native seconds | EM seconds | Increase | EM validation ARI | EM validation nRMSE |
|---|---|---:|---:|---:|---:|---:|
| 7801 | native then predictive | 10.043 | 12.926 | 28.702% | 1.000 | 0.061612 |
| 7802 | predictive then native | 10.048 | 12.909 | 28.473% | 1.000 | 0.042496 |
| 7803 | native then predictive | 10.118 | 13.015 | 28.640% | 1.000 | 0.160962 |

The ratio of summed candidate time 38.8500357093s to summed native time 30.2088103746s gives 28.6049838692% increase. The individual increases span 28.473–28.702%, a 0.229 percentage-point range. No additional repeats were triggered because this first panel had little timing spread. This does not supply a confidence interval across hardware or workloads.

Each arm has exactly 600 updates and 76,800 training rows, plus 18 ordinary validation events / 144 batches / 18,432 rows. Candidate adds 98,304 counterfactual-training forward rows and 6,144 selection-validation forward rows (104,448 total). Final diagnostic prediction adds 1,024 rows to each arm outside the primary timer. Two seed 7799 two-update warmup fits are excluded.

All initial/first-bound weight hashes, input-row hashes, all ordered batch hashes, masks, native RNG hashes before the first intervention, and regular validation events match within each pair. All finite, exact-budget and frozen-evaluation checks pass; all 64 identities have assignments in both arms. All 9 candidate interventions were accepted by validation. No test rows were generated. The assignment quality above is validation-only diagnostic evidence.

| Seed | Construction native / EM | Fit native / EM | Final EM event | Readout native / EM | All EM events | Events / EM total | Events / EM non-event |
|---|---:|---:|---:|---:|---:|---:|---:|
| 7801 | 0.0122 / 0.0143 | 10.043 / 12.006 | 0.919 | 0.0411 / 0.0306 | 2.807 | 21.71% | 27.74% |
| 7802 | 0.0123 / 0.0138 | 10.048 / 11.981 | 0.928 | 0.0337 / 0.0298 | 2.809 | 21.76% | 27.81% |
| 7803 | 0.0136 / 0.0120 | 10.118 / 12.099 | 0.917 | 0.0313 / 0.0303 | 2.925 | 22.47% | 28.99% |

Fit includes update 200 and 400 interventions; the separate final event is update 600. Event time excludes result/checkpoint I/O. Construction and final readout are excluded from the primary training comparison. The native arm has no experimental reassignment callback; identical audit instrumentation is present in both arms. The last two columns are two internal event-time denominators and are **not** the paired native percentage.

Frozen package source SHA: `4f900097c5f12eb6eef07e88b7abba5c61089f52696d52ee8c08d105894a5b58`. CPU 1 intra-op and 1 inter-op thread; original XS model, batch size 128, bounds (2, 8), learning rate .003, data and masking protocol. Source, original v1 numerical implementation, full reporter rows, JSON, stdout/stderr log and runnable driver are retained beside this report. No production source, dependencies, published docs, or official proof thresholds changed.

Reproduction: see `TIMING_PROTOCOL.md`. Canonical staged script: `cost/proofs/group/reassignment_cost.py`; results: `cost/proofs/results.yaml`; full panel JSON: `matched-cost.json`.
