"""Install frozen proof sources and append new measured records without rewriting old ones."""

import hashlib
import shutil
from pathlib import Path

import yaml

BASE = Path('/private/tmp/group-expansion-20261017')
ROOT = Path('/Users/grantham/Desktop/docs-0.3.3')
sources = {
    'predictive_regimes.py': BASE / 'numeric/proofs/group/predictive_regimes.py',
    'predictive_labels.py': BASE / 'categorical/proofs/group/predictive_labels.py',
    'reassignment_cost.py': BASE / 'cost/proofs/group/reassignment_cost.py',
}
for name, source in sources.items():
    target = ROOT / 'proofs/group' / name
    assert not target.exists(), target
    shutil.copyfile(source, target)
    assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(target.read_bytes()).digest()

entries = {}
for identifier, location, slug in (
    ('P079', 'numeric/p079-results.yaml', 'predictive-regimes'),
    ('P080', 'categorical/results.yaml', 'predictive-labels'),
    ('P081', 'cost/proofs/results.yaml', 'reassignment-cost'),
):
    entry = yaml.safe_load((BASE / location).read_text())['proofs'][identifier]
    assert len(entry['runs']) == 3
    entry['runs'].sort(key=lambda run: run['seed'])
    entry['page'] = f'docs/proofs/group/{slug}.py'
    entry.pop('title', None)
    entries[identifier] = entry

entries['P079']['historical'] = {
    'status': 'Partial',
    'source_revision': None,
    'sources': [],
    'summary': 'The fixed three-seed panel passes prediction and partition gates in 14 of 15 positive fits, but exact group count in only 10 of 15. All three complete runs retain failed gates.',
    'insights': 'Predictive reassignment can recover response rules that cannot be separated by outcome means alone. It remains vulnerable to merged and fragmented groups: all six-group cases recover five occupied groups, and the unequal case can merge a small group. Good prediction and a high partition score do not establish the correct number of groups. This proof-local callback is not ordinary Model.fit behavior.',
    'evidence': '''Seeds 7901, 7902, and 7903 each receive all six predefined cases and 600 optimizer updates per case. Each fit uses 4,096 training, 1,024 validation, and 2,048 test rows of the same 64 known identities, with independent inputs and noise. Bounds remain (2, 8).

| Case | Prediction and ARI gates | Exact occupied count |
| --- | --- | --- |
| Four separated curves | 3/3 | 3/3 |
| Four crossing curves | 3/3 | 2/3 |
| Unequal four groups | 3/3 | 2/3 |
| Three separated groups | 3/3 | 3/3 |
| Six separated groups | 2/3 | 0/3 |

All no-regime and shuffled-identity controls pass. Every vocabulary, frozen-state, group-permutation, and unknown-identity invariant passes. Every run is still marked not met because at least one predeclared group-count gate fails. The test split is never used for acceptance. Timings here were collected under shared CPU load; P081 separately measures isolated matched overhead.''',
}
entries['P080']['historical'] = {
    'status': 'Partial',
    'source_revision': None,
    'sources': [],
    'summary': 'Predictive reassignment clears every categorical gate in two of three fresh seeds. The third seed merges true groups and fragments others.',
    'insights': 'The approach extends beyond squared-error regression: it can use the true-label probabilities in public categorical predictions. Improvements are substantial compared with native training and hardening alone, but one of three seeds still fails both partition and prediction gates. The label depends on identity group and channel jointly; marginal label frequencies alone cannot solve this process.',
    'evidence': '''Five thousand training rows, 2,000 validation rows, and 2,500 test rows describe 50 known merchant identities, five hidden groups, and five channel contexts. Labels follow (group + channel) modulo 5 with 2% corruption. All four arms receive 600 optimizer updates; reassignment proposals use training true-label negative log likelihood and validation-only acceptance.

| Seed | Native accuracy | Hardening accuracy | Predictive accuracy | Predictive ARI | Occupied groups |
| --- | --- | --- | --- | --- | --- |
| 8001 | 20.40% | 39.56% | 97.80% | 1.0000 | 5 |
| 8002 | 25.04% | 36.56% | 78.00% | 0.6986 | 6 |
| 8003 | 23.12% | 32.52% | 93.24% | 1.0000 | 5 |

The fixed gates require accuracy at least 90%, ARI at least 0.80, and exactly five occupied groups. Seed 8002 remains failed: it merges true groups 0 and 4 and fragments other groups. No-regime and shuffled-ID controls stay near the 20% chance level. All finite-score, vocabulary-coverage, and frozen-resource checks pass. This is same-identity observation generalization, not cold-start identity discovery.''',
}
entries['P081']['historical'] = {
    'status': 'Limited',
    'source_revision': None,
    'sources': [],
    'summary': 'Six isolated matched CPU fits measure a 28.60% wall-time increase for predictive reassignment. All matching and workload checks pass.',
    'insights': 'The additional training-row and validation-row predictions have a measurable cost. On this CPU the original predictive method costs about 29% more elapsed training time, including the terminal reassignment. This is a hardware-specific wall-time comparison, not a FLOP percentage or a GPU result; it does not measure later combinations.',
    'evidence': '''After two excluded warmups, three paired seeds run in alternating native/candidate order on one CPU thread, with no concurrent model processes. Both arms have matching initial weights, observation order, masks, pre-intervention Torch state, 600 AdamW updates, and 18 ordinary validation events totaling 18,432 rows. Checkpoint and result I/O remain outside the timers.

| Seed | Native wall time | Predictive wall time | Increase |
| --- | --- | --- | --- |
| 7801 | 10.043 s | 12.926 s | 28.70% |
| 7802 | 10.048 s | 12.909 s | 28.47% |
| 7803 | 10.118 s | 13.015 s | 28.64% |

The ratio of total times is 38.850 / 30.209, giving **28.60%** additional wall time. Predictive reassignment adds 98,304 counterfactual training forward rows and 6,144 validation-selection forward rows to 76,800 training rows, without adding backward passes or optimizer updates. Validation ARI is 1.0 in all three candidate fits; normalized RMSE is 0.06161, 0.04250, and 0.16096. No test split is inspected. The complete component timers and audit hashes are retained in the run records.''',
}

registry = ROOT / 'proofs/results.yaml'
original = registry.read_bytes()
assert set(yaml.safe_load(original)['proofs']).isdisjoint(entries)
addition = yaml.safe_dump(entries, sort_keys=False, allow_unicode=True, width=110)
registry.write_bytes(original + b'\n' + ''.join('  ' + line if line.strip() else line for line in addition.splitlines(keepends=True)).encode())
assert registry.read_bytes().startswith(original)
assert len(yaml.safe_load(registry.read_bytes())['proofs']) == 81
(BASE / 'integration/preserved-registry-prefix.sha256').write_text(hashlib.sha256(original).hexdigest() + '\n')

for name, target in (
    ('group.qmd', 'docs/data-types/group.qmd'),
    ('SPEC.md', 'proofs/SPEC.md'),
    ('test_group_reassignment_proofs.py', 'tests/proofs/test_group_reassignment_proofs.py'),
):
    shutil.copyfile(BASE / 'integration' / name, ROOT / target)
print('Installed three frozen proofs, all nine measured records, and coordinated static documentation.')
