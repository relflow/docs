"""Run P081 against its immutable package snapshot, after timing isolation approval."""

# ruff: noqa: E402

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[name] = "1"

WORK = Path(__file__).resolve().parent
PROOFS = WORK / "cost/proofs"
sys.path.insert(0, str(PROOFS))
sys.path.insert(0, str(WORK / "snapshot/src"))

import torch
from reporting import plain, provenance, save

torch.set_num_threads(1)
torch.set_num_interop_threads(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--timing-isolation-confirmed", action="store_true", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[7801, 7802, 7803])
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    spec = importlib.util.spec_from_file_location("p081_reassignment_cost", PROOFS / "group/reassignment_cost.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    package = WORK / "snapshot/src/relflow"
    digest = hashlib.sha256()
    for path in sorted(package.rglob("*.py")):
        digest.update(("src/relflow/" + path.relative_to(package).as_posix()).encode())
        digest.update(path.read_bytes())
    assert digest.hexdigest() == json.loads((WORK / "manifest.json").read_text())["source_tree_sha256"]
    result = {
        "source_tree_sha256": digest.hexdigest(),
        "timing_isolation_confirmed": True,
        "environment": {
            "python": sys.version,
            "executable": sys.executable,
            "platform": platform.platform(),
            "host": platform.node(),
            "cpu": platform.processor(),
            "torch_threads": torch.get_num_threads(),
            "torch_interop_threads": torch.get_num_interop_threads(),
            "packages": {
                name: importlib.metadata.version(name)
                for name in ("relflow", "torch", "lightning", "numpy", "pyarrow", "polars")
            },
        },
        "runs": [],
    }
    for seed in args.seeds:
        started = time.perf_counter()
        row = {
            "started_at": datetime.now(timezone.utc).isoformat(),
            "mode": "full",
            "seed": seed,
            "steps_override": None,
            "accelerator": "cpu",
            "threads": 1,
            "provenance": provenance(PROOFS / "group/reassignment_cost.py"),
        }
        metrics, checks = module.run(seed, None, "cpu")
        row.update(
            metrics=plain(metrics),
            checks=checks,
            outcome="met" if all(checks.values()) else "not_met",
            duration_seconds=time.perf_counter() - started,
        )
        save("P081", row, PROOFS / "results.yaml")
        result["runs"].append(row)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "seed": seed,
                    "order": metrics["run_order"],
                    "native_seconds": metrics["native"]["training_and_reassignment_wall_seconds"],
                    "candidate_seconds": metrics["predictive"]["training_and_reassignment_wall_seconds"],
                    "increase_percent": metrics["wall_time_increase_percent"],
                    "candidate_validation": metrics["predictive"]["validation"],
                    "failed_checks": [key for key, value in checks.items() if not value],
                }
            ),
            flush=True,
        )
    base = sum(row["metrics"]["native"]["training_and_reassignment_wall_seconds"] for row in result["runs"])
    candidate = sum(row["metrics"]["predictive"]["training_and_reassignment_wall_seconds"] for row in result["runs"])
    result["aggregate"] = {
        "timed_training_fits": 2 * len(result["runs"]),
        "excluded_warmup_training_fits": sum(len(row["metrics"]["excluded_warmups"]) for row in result["runs"]),
        "native_wall_seconds_sum": base,
        "candidate_wall_seconds_sum": candidate,
        "wall_time_increase_fraction_ratio_of_sums": candidate / base - 1,
        "wall_time_increase_percent_ratio_of_sums": (candidate / base - 1) * 100,
        "not_a_flops_measurement": True,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["aggregate"], indent=2), flush=True)


if __name__ == "__main__":
    main()
